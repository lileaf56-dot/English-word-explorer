/**
 * 词域探险家 (Word Explorer) - 离线独立核心包 v4.0
 * 规范简体中文 | 三大沉浸动态大世界 | 朗读 3 遍跟读过关 | 学习足迹与家长全景汇报
 */

(function () {
  'use strict';

  // 移动端/微信/华为手机环境保护
  try {
    if (!window.speechSynthesis) {
      window.speechSynthesis = { speak: function(){}, cancel: function(){}, getVoices: function(){ return []; } };
    }
  } catch(e) {}


  // ================= 1. 小学 1~6 年级核心考纲词库 (规范简体中文) =================
  const GD_VOCABULARY = [{"id": "gd_001", "word": "cat", "phonetic": "/kæt/", "syllables": ["cat"], "chinese": "猫", "grade": 1, "unit": "动物天地", "example": "The cat catches mice.", "gradeName": "一年级", "meaning": "猫", "pos": "n."}, {"id": "gd_002", "word": "dog", "phonetic": "/dɒɡ/", "syllables": ["dog"], "chinese": "狗", "grade": 1, "unit": "动物天地", "example": "The dog barks joyfully.", "gradeName": "一年级", "meaning": "狗", "pos": "n."}, {"id": "gd_003", "word": "duck", "phonetic": "/dʌk/", "syllables": ["duck"], "chinese": "鸭子", "grade": 1, "unit": "动物天地", "example": "Ducks swim in the pond.", "gradeName": "一年级", "meaning": "鸭子", "pos": "n."}, {"id": "gd_004", "word": "bear", "phonetic": "/beə(r)/", "syllables": ["bear"], "chinese": "熊", "grade": 1, "unit": "动物天地", "example": "A big brown bear sleeps.", "gradeName": "一年级", "meaning": "熊", "pos": "n."}, {"id": "gd_005", "word": "panda", "phonetic": "/ˈpændə/", "syllables": ["pan", "da"], "chinese": "大熊猫", "grade": 1, "unit": "动物天地", "example": "Pandas love fresh bamboo.", "gradeName": "一年级", "meaning": "大熊猫", "pos": "adj."}, {"id": "gd_006", "word": "monkey", "phonetic": "/ˈmʌŋki/", "syllables": ["mon", "key"], "chinese": "猴子", "grade": 1, "unit": "动物天地", "example": "Monkeys climb tall trees.", "gradeName": "一年级", "meaning": "猴子", "pos": "n."}, {"id": "gd_007", "word": "rabbit", "phonetic": "/ˈræbɪt/", "syllables": ["rab", "bit"], "chinese": "兔子", "grade": 1, "unit": "动物天地", "example": "The white rabbit has red eyes.", "gradeName": "一年级", "meaning": "兔子", "pos": "n."}, {"id": "gd_008", "word": "tiger", "phonetic": "/ˈtaɪɡə(r)/", "syllables": ["ti", "ger"], "chinese": "老虎", "grade": 1, "unit": "动物天地", "example": "Tigers are strong and brave.", "gradeName": "一年级", "meaning": "老虎", "pos": "n."}, {"id": "gd_009", "word": "lion", "phonetic": "/ˈlaɪən/", "syllables": ["li", "on"], "chinese": "狮子", "grade": 1, "unit": "动物天地", "example": "The lion is the king of beasts.", "gradeName": "一年级", "meaning": "狮子", "pos": "n."}, {"id": "gd_010", "word": "elephant", "phonetic": "/ˈelɪfənt/", "syllables": ["el", "e", "phant"], "chinese": "大象", "grade": 1, "unit": "动物天地", "example": "The elephant has a long nose.", "gradeName": "一年级", "meaning": "大象", "pos": "adj."}, {"id": "gd_011", "word": "bird", "phonetic": "/bɜːd/", "syllables": ["bird"], "chinese": "小鸟", "grade": 1, "unit": "动物天地", "example": "Birds sing in the morning.", "gradeName": "一年级", "meaning": "小鸟", "pos": "adj."}, {"id": "gd_012", "word": "fish", "phonetic": "/fɪʃ/", "syllables": ["fish"], "chinese": "鱼", "grade": 1, "unit": "动物天地", "example": "Fish swim in clean water.", "gradeName": "一年级", "meaning": "鱼", "pos": "n."}, {"id": "gd_013", "word": "pig", "phonetic": "/pɪɡ/", "syllables": ["pig"], "chinese": "猪", "grade": 1, "unit": "动物天地", "example": "The little pig is sleeping.", "gradeName": "一年级", "meaning": "猪", "pos": "n."}, {"id": "gd_014", "word": "mouse", "phonetic": "/maʊs/", "syllables": ["mouse"], "chinese": "老鼠", "grade": 1, "unit": "动物天地", "example": "The tiny mouse is eating cheese.", "gradeName": "一年级", "meaning": "老鼠", "pos": "n."}, {"id": "gd_015", "word": "frog", "phonetic": "/frɒɡ/", "syllables": ["frog"], "chinese": "青蛙", "grade": 1, "unit": "动物天地", "example": "Green frogs jump into the lake.", "gradeName": "一年级", "meaning": "青蛙", "pos": "n."}, {"id": "gd_016", "word": "horse", "phonetic": "/hɔːs/", "syllables": ["horse"], "chinese": "马", "grade": 2, "unit": "动物天地", "example": "A white horse gallops across fields.", "gradeName": "二年级", "meaning": "马", "pos": "n."}, {"id": "gd_017", "word": "cow", "phonetic": "/kaʊ/", "syllables": ["cow"], "chinese": "奶牛；母牛", "grade": 2, "unit": "动物天地", "example": "Cows give us healthy milk.", "gradeName": "二年级", "meaning": "奶牛；母牛", "pos": "n."}, {"id": "gd_018", "word": "sheep", "phonetic": "/ʃiːp/", "syllables": ["sheep"], "chinese": "绵羊", "grade": 2, "unit": "动物天地", "example": "Flock of white sheep on green hill.", "gradeName": "二年级", "meaning": "绵羊", "pos": "n."}, {"id": "gd_019", "word": "goat", "phonetic": "/ɡəʊt/", "syllables": ["goat"], "chinese": "山羊", "grade": 2, "unit": "动物天地", "example": "Mountain goats climb steep rocks.", "gradeName": "二年级", "meaning": "山羊", "pos": "n."}, {"id": "gd_020", "word": "hen", "phonetic": "/hen/", "syllables": ["hen"], "chinese": "母鸡", "grade": 2, "unit": "动物天地", "example": "The hen laid a fresh brown egg.", "gradeName": "二年级", "meaning": "母鸡", "pos": "n."}, {"id": "gd_021", "word": "rooster", "phonetic": "/ˈruːstə(r)/", "syllables": ["roos", "ter"], "chinese": "公鸡", "grade": 2, "unit": "动物天地", "example": "The rooster crows at dawn.", "gradeName": "二年级", "meaning": "公鸡", "pos": "n."}, {"id": "gd_022", "word": "chick", "phonetic": "/tʃɪk/", "syllables": ["chick"], "chinese": "小鸡", "grade": 2, "unit": "动物天地", "example": "Yellow chicks follow their mother.", "gradeName": "二年级", "meaning": "小鸡", "pos": "adj."}, {"id": "gd_023", "word": "goose", "phonetic": "/ɡuːs/", "syllables": ["goose"], "chinese": "鹅", "grade": 2, "unit": "动物天地", "example": "The white goose swims gracefully.", "gradeName": "二年级", "meaning": "鹅", "pos": "n."}, {"id": "gd_024", "word": "snake", "phonetic": "/sneɪk/", "syllables": ["snake"], "chinese": "蛇", "grade": 2, "unit": "动物天地", "example": "The long snake glides through grass.", "gradeName": "二年级", "meaning": "蛇", "pos": "n."}, {"id": "gd_025", "word": "giraffe", "phonetic": "/dʒəˈrɑːf/", "syllables": ["gi", "raffe"], "chinese": "长颈鹿", "grade": 3, "unit": "动物天地", "example": "Giraffes have very long necks.", "gradeName": "三年级", "meaning": "长颈鹿", "pos": "adj."}, {"id": "gd_026", "word": "deer", "phonetic": "/dɪə(r)/", "syllables": ["deer"], "chinese": "鹿", "grade": 3, "unit": "动物天地", "example": "Gentle deer drink at the spring.", "gradeName": "三年级", "meaning": "鹿", "pos": "n."}, {"id": "gd_027", "word": "zebra", "phonetic": "/ˈzebrə/", "syllables": ["ze", "bra"], "chinese": "斑马", "grade": 3, "unit": "动物天地", "example": "Zebras have black and white stripes.", "gradeName": "三年级", "meaning": "斑马", "pos": "n."}, {"id": "gd_028", "word": "kangaroo", "phonetic": "/ˌkæŋɡəˈruː/", "syllables": ["kan", "ga", "roo"], "chinese": "袋鼠", "grade": 3, "unit": "动物天地", "example": "Kangaroos hop across Australia.", "gradeName": "三年级", "meaning": "袋鼠", "pos": "n."}, {"id": "gd_029", "word": "fox", "phonetic": "/fɒks/", "syllables": ["fox"], "chinese": "狐狸", "grade": 3, "unit": "动物天地", "example": "The clever fox has a bushy tail.", "gradeName": "三年级", "meaning": "狐狸", "pos": "n."}, {"id": "gd_030", "word": "wolf", "phonetic": "/wʊlf/", "syllables": ["wolf"], "chinese": "狼", "grade": 3, "unit": "动物天地", "example": "Wolves live together in a pack.", "gradeName": "三年级", "meaning": "狼", "pos": "n."}, {"id": "gd_031", "word": "butterfly", "phonetic": "/ˈbʌtəflaɪ/", "syllables": ["but", "ter", "fly"], "chinese": "蝴蝶", "grade": 3, "unit": "动物天地", "example": "Colorful butterflies flutter around roses.", "gradeName": "三年级", "meaning": "蝴蝶", "pos": "n."}, {"id": "gd_032", "word": "bee", "phonetic": "/biː/", "syllables": ["bee"], "chinese": "蜜蜂", "grade": 3, "unit": "动物天地", "example": "Busy bees collect sweet nectar.", "gradeName": "三年级", "meaning": "蜜蜂", "pos": "n."}, {"id": "gd_033", "word": "ant", "phonetic": "/ænt/", "syllables": ["ant"], "chinese": "蚂蚁", "grade": 3, "unit": "动物天地", "example": "Tiny ants work together diligently.", "gradeName": "三年级", "meaning": "蚂蚁", "pos": "n."}, {"id": "gd_034", "word": "whale", "phonetic": "/weɪl/", "syllables": ["whale"], "chinese": "鲸鱼", "grade": 4, "unit": "动物天地", "example": "Blue whales are oceanic giants.", "gradeName": "四年级", "meaning": "鲸鱼", "pos": "n."}, {"id": "gd_035", "word": "dolphin", "phonetic": "/ˈdɒlfɪn/", "syllables": ["dol", "phin"], "chinese": "海豚", "grade": 4, "unit": "动物天地", "example": "Dolphins leap joyfully over waves.", "gradeName": "四年级", "meaning": "海豚", "pos": "n."}, {"id": "gd_036", "word": "shark", "phonetic": "/ʃɑːk/", "syllables": ["shark"], "chinese": "鲨鱼", "grade": 4, "unit": "动物天地", "example": "Sharks swim fast in deep ocean.", "gradeName": "四年级", "meaning": "鲨鱼", "pos": "n."}, {"id": "gd_037", "word": "dinosaur", "phonetic": "/ˈdaɪnəsɔː(r)/", "syllables": ["di", "no", "saur"], "chinese": "恐龙", "grade": 4, "unit": "动物天地", "example": "Huge dinosaurs lived long ago.", "gradeName": "四年级", "meaning": "恐龙", "pos": "n."}, {"id": "gd_038", "word": "insect", "phonetic": "/ˈɪnsekt/", "syllables": ["in", "sect"], "chinese": "昆虫", "grade": 4, "unit": "动物天地", "example": "Learn about insects in science class.", "gradeName": "四年级", "meaning": "昆虫", "pos": "n."}, {"id": "gd_039", "word": "pet", "phonetic": "/pet/", "syllables": ["pet"], "chinese": "宠物", "grade": 2, "unit": "动物天地", "example": "Take good care of your home pet.", "gradeName": "二年级", "meaning": "宠物", "pos": "n."}, {"id": "gd_040", "word": "tail", "phonetic": "/teɪl/", "syllables": ["tail"], "chinese": "尾巴", "grade": 2, "unit": "动物天地", "example": "The dog wags its fluffy tail.", "gradeName": "二年级", "meaning": "尾巴", "pos": "n."}, {"id": "gd_041", "word": "red", "phonetic": "/red/", "syllables": ["red"], "chinese": "红色；红色的", "grade": 1, "unit": "绚丽色彩", "example": "I like red roses.", "gradeName": "一年级", "meaning": "红色；红色的", "pos": "adj."}, {"id": "gd_042", "word": "yellow", "phonetic": "/ˈjeləʊ/", "syllables": ["yel", "low"], "chinese": "黄色；黄色的", "grade": 1, "unit": "绚丽色彩", "example": "The sun is bright yellow.", "gradeName": "一年级", "meaning": "黄色；黄色的", "pos": "adj."}, {"id": "gd_043", "word": "green", "phonetic": "/ɡriːn/", "syllables": ["green"], "chinese": "绿色；绿色的", "grade": 1, "unit": "绚丽色彩", "example": "Look at the green grass.", "gradeName": "一年级", "meaning": "绿色；绿色的", "pos": "adj."}, {"id": "gd_044", "word": "blue", "phonetic": "/bluː/", "syllables": ["blue"], "chinese": "蓝色；蓝色的", "grade": 1, "unit": "绚丽色彩", "example": "The sea is beautiful blue.", "gradeName": "一年级", "meaning": "蓝色；蓝色的", "pos": "adj."}, {"id": "gd_045", "word": "black", "phonetic": "/blæk/", "syllables": ["black"], "chinese": "黑色；黑色的", "grade": 1, "unit": "绚丽色彩", "example": "A black cat runs fast.", "gradeName": "一年级", "meaning": "黑色；黑色的", "pos": "adj."}, {"id": "gd_046", "word": "white", "phonetic": "/waɪt/", "syllables": ["white"], "chinese": "白色；白色的", "grade": 1, "unit": "绚丽色彩", "example": "Snow is pure white.", "gradeName": "一年级", "meaning": "白色；白色的", "pos": "adj."}, {"id": "gd_047", "word": "orange", "phonetic": "/ˈɒrɪndʒ/", "syllables": ["or", "ange"], "chinese": "橙色；橙色的", "grade": 1, "unit": "绚丽色彩", "example": "I want an orange juice.", "gradeName": "一年级", "meaning": "橙色；橙色的", "pos": "adj."}, {"id": "gd_048", "word": "brown", "phonetic": "/braʊn/", "syllables": ["brown"], "chinese": "棕色；棕色的", "grade": 1, "unit": "绚丽色彩", "example": "The bear has brown fur.", "gradeName": "一年级", "meaning": "棕色；棕色的", "pos": "adj."}, {"id": "gd_049", "word": "pink", "phonetic": "/pɪŋk/", "syllables": ["pink"], "chinese": "粉色；粉红色的", "grade": 1, "unit": "绚丽色彩", "example": "She wears a pink ribbon.", "gradeName": "一年级", "meaning": "粉色；粉红色的", "pos": "adj."}, {"id": "gd_050", "word": "purple", "phonetic": "/ˈpɜːpl/", "syllables": ["pur", "ple"], "chinese": "紫色；紫色的", "grade": 1, "unit": "绚丽色彩", "example": "Grapes are sweet and purple.", "gradeName": "一年级", "meaning": "紫色；紫色的", "pos": "adj."}, {"id": "gd_051", "word": "grey", "phonetic": "/ɡreɪ/", "syllables": ["grey"], "chinese": "灰色；灰色的", "grade": 1, "unit": "绚丽色彩", "example": "Rain clouds are dark grey.", "gradeName": "一年级", "meaning": "灰色；灰色的", "pos": "adj."}, {"id": "gd_052", "word": "gold", "phonetic": "/ɡəʊld/", "syllables": ["gold"], "chinese": "金色；黄金", "grade": 3, "unit": "绚丽色彩", "example": "The queen wore a gold crown.", "gradeName": "三年级", "meaning": "金色；黄金", "pos": "n."}, {"id": "gd_053", "word": "silver", "phonetic": "/ˈsɪlvə(r)/", "syllables": ["sil", "ver"], "chinese": "银色；白银", "grade": 3, "unit": "绚丽色彩", "example": "The moon shines like silver.", "gradeName": "三年级", "meaning": "银色；白银", "pos": "n."}, {"id": "gd_054", "word": "bright", "phonetic": "/braɪt/", "syllables": ["bright"], "chinese": "明亮的；鲜艳的", "grade": 3, "unit": "绚丽色彩", "example": "Bright stars fill night sky.", "gradeName": "三年级", "meaning": "明亮的；鲜艳的", "pos": "n."}, {"id": "gd_055", "word": "colour", "phonetic": "/ˈkʌlə(r)/", "syllables": ["col", "our"], "chinese": "颜色", "grade": 1, "unit": "绚丽色彩", "example": "What colour is the rainbow?", "gradeName": "一年级", "meaning": "颜色", "pos": "n."}, {"id": "gd_056", "word": "one", "phonetic": "/wʌn/", "syllables": ["one"], "chinese": "一", "grade": 1, "unit": "数字与计数", "example": "I have one apple.", "gradeName": "一年级", "meaning": "一", "pos": "n."}, {"id": "gd_057", "word": "two", "phonetic": "/tuː/", "syllables": ["two"], "chinese": "二", "grade": 1, "unit": "数字与计数", "example": "Two birds are flying.", "gradeName": "一年级", "meaning": "二", "pos": "n."}, {"id": "gd_058", "word": "three", "phonetic": "/θriː/", "syllables": ["three"], "chinese": "三", "grade": 1, "unit": "数字与计数", "example": "There are three pens.", "gradeName": "一年级", "meaning": "三", "pos": "n."}, {"id": "gd_059", "word": "four", "phonetic": "/fɔː(r)/", "syllables": ["four"], "chinese": "四", "grade": 1, "unit": "数字与计数", "example": "Four students are reading.", "gradeName": "一年级", "meaning": "四", "pos": "n."}, {"id": "gd_060", "word": "five", "phonetic": "/faɪv/", "syllables": ["five"], "chinese": "五", "grade": 1, "unit": "数字与计数", "example": "Give me high five!", "gradeName": "一年级", "meaning": "五", "pos": "n."}, {"id": "gd_061", "word": "six", "phonetic": "/sɪks/", "syllables": ["six"], "chinese": "六", "grade": 1, "unit": "数字与计数", "example": "She is six years old.", "gradeName": "一年级", "meaning": "六", "pos": "n."}, {"id": "gd_062", "word": "seven", "phonetic": "/ˈsevn/", "syllables": ["sev", "en"], "chinese": "七", "grade": 1, "unit": "数字与计数", "example": "A week has seven days.", "gradeName": "一年级", "meaning": "七", "pos": "n."}, {"id": "gd_063", "word": "eight", "phonetic": "/eɪt/", "syllables": ["eight"], "chinese": "八", "grade": 1, "unit": "数字与计数", "example": "Eight desks are in a row.", "gradeName": "一年级", "meaning": "八", "pos": "n."}, {"id": "gd_064", "word": "nine", "phonetic": "/naɪn/", "syllables": ["nine"], "chinese": "九", "grade": 1, "unit": "数字与计数", "example": "Nine stars shine in the night.", "gradeName": "一年级", "meaning": "九", "pos": "n."}, {"id": "gd_065", "word": "ten", "phonetic": "/ten/", "syllables": ["ten"], "chinese": "十", "grade": 1, "unit": "数字与计数", "example": "Count from one to ten.", "gradeName": "一年级", "meaning": "十", "pos": "n."}, {"id": "gd_066", "word": "eleven", "phonetic": "/ɪˈlevn/", "syllables": ["e", "lev", "en"], "chinese": "十一", "grade": 2, "unit": "数字与计数", "example": "There are eleven football players.", "gradeName": "二年级", "meaning": "十一", "pos": "n."}, {"id": "gd_067", "word": "twelve", "phonetic": "/twelv/", "syllables": ["twelve"], "chinese": "十二", "grade": 2, "unit": "数字与计数", "example": "A year has twelve months.", "gradeName": "二年级", "meaning": "十二", "pos": "n."}, {"id": "gd_068", "word": "thirteen", "phonetic": "/ˌθɜːˈtiːn/", "syllables": ["thir", "teen"], "chinese": "十三", "grade": 2, "unit": "数字与计数", "example": "Thirteen is an interesting number.", "gradeName": "二年级", "meaning": "十三", "pos": "n."}, {"id": "gd_069", "word": "fourteen", "phonetic": "/ˌfɔːˈtiːn/", "syllables": ["four", "teen"], "chinese": "十四", "grade": 2, "unit": "数字与计数", "example": "Count to fourteen carefully.", "gradeName": "二年级", "meaning": "十四", "pos": "n."}, {"id": "gd_070", "word": "fifteen", "phonetic": "/ˌfɪfˈtiːn/", "syllables": ["fif", "teen"], "chinese": "十五", "grade": 2, "unit": "数字与计数", "example": "Fifteen minutes makes a quarter.", "gradeName": "二年级", "meaning": "十五", "pos": "n."}, {"id": "gd_071", "word": "sixteen", "phonetic": "/ˌsɪksˈtiːn/", "syllables": ["six", "teen"], "chinese": "十六", "grade": 2, "unit": "数字与计数", "example": "She is sixteen years old.", "gradeName": "二年级", "meaning": "十六", "pos": "n."}, {"id": "gd_072", "word": "seventeen", "phonetic": "/ˌsevnˈtiːn/", "syllables": ["sev", "en", "teen"], "chinese": "十七", "grade": 2, "unit": "数字与计数", "example": "Seventeen flowers bloom.", "gradeName": "二年级", "meaning": "十七", "pos": "n."}, {"id": "gd_073", "word": "eighteen", "phonetic": "/ˌeɪˈtiːn/", "syllables": ["eigh", "teen"], "chinese": "十八", "grade": 2, "unit": "数字与计数", "example": "Eighteen students passed.", "gradeName": "二年级", "meaning": "十八", "pos": "n."}, {"id": "gd_074", "word": "nineteen", "phonetic": "/ˌnaɪnˈtiːn/", "syllables": ["nine", "teen"], "chinese": "十九", "grade": 2, "unit": "数字与计数", "example": "Nineteen apples in the basket.", "gradeName": "二年级", "meaning": "十九", "pos": "n."}, {"id": "gd_075", "word": "twenty", "phonetic": "/ˈtwenti/", "syllables": ["twen", "ty"], "chinese": "二十", "grade": 2, "unit": "数字与计数", "example": "Twenty birds fly south.", "gradeName": "二年级", "meaning": "二十", "pos": "n."}, {"id": "gd_076", "word": "thirty", "phonetic": "/ˈθɜːti/", "syllables": ["thir", "ty"], "chinese": "三十", "grade": 2, "unit": "数字与计数", "example": "Thirty days has September.", "gradeName": "二年级", "meaning": "三十", "pos": "n."}, {"id": "gd_077", "word": "forty", "phonetic": "/ˈfɔːti/", "syllables": ["for", "ty"], "chinese": "四十", "grade": 2, "unit": "数字与计数", "example": "Forty minutes per class.", "gradeName": "二年级", "meaning": "四十", "pos": "n."}, {"id": "gd_078", "word": "fifty", "phonetic": "/ˈfɪfti/", "syllables": ["fif", "ty"], "chinese": "五十", "grade": 2, "unit": "数字与计数", "example": "Fifty stars on the flag.", "gradeName": "二年级", "meaning": "五十", "pos": "n."}, {"id": "gd_079", "word": "sixty", "phonetic": "/ˈsɪksti/", "syllables": ["six", "ty"], "chinese": "六十", "grade": 2, "unit": "数字与计数", "example": "Sixty seconds make a minute.", "gradeName": "二年级", "meaning": "六十", "pos": "n."}, {"id": "gd_080", "word": "seventy", "phonetic": "/ˈsevnti/", "syllables": ["sev", "en", "ty"], "chinese": "七十", "grade": 2, "unit": "数字与计数", "example": "Seventy pages in this book.", "gradeName": "二年级", "meaning": "七十", "pos": "n."}, {"id": "gd_081", "word": "eighty", "phonetic": "/ˈeɪti/", "syllables": ["eigh", "ty"], "chinese": "八十", "grade": 2, "unit": "数字与计数", "example": "Eighty meters broad river.", "gradeName": "二年级", "meaning": "八十", "pos": "n."}, {"id": "gd_082", "word": "ninety", "phonetic": "/ˈnaɪnti/", "syllables": ["nine", "ty"], "chinese": "九十", "grade": 2, "unit": "数字与计数", "example": "Score ninety points in test.", "gradeName": "二年级", "meaning": "九十", "pos": "n."}, {"id": "gd_083", "word": "hundred", "phonetic": "/ˈhʌndrəd/", "syllables": ["hun", "dred"], "chinese": "一百", "grade": 2, "unit": "数字与计数", "example": "A hundred percent effort.", "gradeName": "二年级", "meaning": "一百", "pos": "n."}, {"id": "gd_084", "word": "thousand", "phonetic": "/ˈθaʊznd/", "syllables": ["thou", "sand"], "chinese": "一千", "grade": 4, "unit": "数字与计数", "example": "A journey of a thousand miles begins with a single step.", "gradeName": "四年级", "meaning": "一千", "pos": "n."}, {"id": "gd_085", "word": "first", "phonetic": "/fɜːst/", "syllables": ["first"], "chinese": "第一", "grade": 3, "unit": "数字与计数", "example": "Safety comes first.", "gradeName": "三年级", "meaning": "第一", "pos": "n."}, {"id": "gd_086", "word": "second", "phonetic": "/ˈsekənd/", "syllables": ["sec", "ond"], "chinese": "第二；秒", "grade": 3, "unit": "数字与计数", "example": "He won the second prize.", "gradeName": "三年级", "meaning": "第二；秒", "pos": "n."}, {"id": "gd_087", "word": "third", "phonetic": "/θɜːd/", "syllables": ["third"], "chinese": "第三", "grade": 3, "unit": "数字与计数", "example": "The classroom is on the third floor.", "gradeName": "三年级", "meaning": "第三", "pos": "n."}, {"id": "gd_088", "word": "fourth", "phonetic": "/fɔːθ/", "syllables": ["fourth"], "chinese": "第四", "grade": 3, "unit": "数字与计数", "example": "Today is the fourth of July.", "gradeName": "三年级", "meaning": "第四", "pos": "n."}, {"id": "gd_089", "word": "fifth", "phonetic": "/fɪfθ/", "syllables": ["fifth"], "chinese": "第五", "grade": 3, "unit": "数字与计数", "example": "She came in fifth place.", "gradeName": "三年级", "meaning": "第五", "pos": "n."}, {"id": "gd_090", "word": "number", "phonetic": "/ˈnʌmbə(r)/", "syllables": ["num", "ber"], "chinese": "数字；号码", "grade": 2, "unit": "数字与计数", "example": "What is your telephone number?", "gradeName": "二年级", "meaning": "数字；号码", "pos": "n."}, {"id": "gd_091", "word": "eye", "phonetic": "/aɪ/", "syllables": ["eye"], "chinese": "眼睛", "grade": 1, "unit": "身体与健康", "example": "Open your eyes.", "gradeName": "一年级", "meaning": "眼睛", "pos": "n."}, {"id": "gd_092", "word": "nose", "phonetic": "/nəʊz/", "syllables": ["nose"], "chinese": "鼻子", "grade": 1, "unit": "身体与健康", "example": "Touch your nose.", "gradeName": "一年级", "meaning": "鼻子", "pos": "n."}, {"id": "gd_093", "word": "mouth", "phonetic": "/maʊθ/", "syllables": ["mouth"], "chinese": "嘴巴", "grade": 1, "unit": "身体与健康", "example": "Open your mouth wide.", "gradeName": "一年级", "meaning": "嘴巴", "pos": "n."}, {"id": "gd_094", "word": "ear", "phonetic": "/ɪə(r)/", "syllables": ["ear"], "chinese": "耳朵", "grade": 1, "unit": "身体与健康", "example": "Listen with your ears.", "gradeName": "一年级", "meaning": "耳朵", "pos": "n."}, {"id": "gd_095", "word": "face", "phonetic": "/feɪs/", "syllables": ["face"], "chinese": "脸庞；面孔", "grade": 1, "unit": "身体与健康", "example": "Wash your face every morning.", "gradeName": "一年级", "meaning": "脸庞；面孔", "pos": "n."}, {"id": "gd_096", "word": "head", "phonetic": "/hed/", "syllables": ["head"], "chinese": "头；头部", "grade": 1, "unit": "身体与健康", "example": "Nod your head.", "gradeName": "一年级", "meaning": "头；头部", "pos": "n."}, {"id": "gd_097", "word": "hair", "phonetic": "/heə(r)/", "syllables": ["hair"], "chinese": "头发", "grade": 1, "unit": "身体与健康", "example": "Comb your black hair.", "gradeName": "一年级", "meaning": "头发", "pos": "n."}, {"id": "gd_098", "word": "arm", "phonetic": "/ɑːm/", "syllables": ["arm"], "chinese": "胳膊；手臂", "grade": 1, "unit": "身体与健康", "example": "Wave your arms.", "gradeName": "一年级", "meaning": "胳膊；手臂", "pos": "n."}, {"id": "gd_099", "word": "hand", "phonetic": "/hænd/", "syllables": ["hand"], "chinese": "手", "grade": 1, "unit": "身体与健康", "example": "Clap your hands.", "gradeName": "一年级", "meaning": "手", "pos": "n."}, {"id": "gd_100", "word": "leg", "phonetic": "/leɡ/", "syllables": ["leg"], "chinese": "腿", "grade": 1, "unit": "身体与健康", "example": "Shake your legs.", "gradeName": "一年级", "meaning": "腿", "pos": "n."}, {"id": "gd_101", "word": "foot", "phonetic": "/fʊt/", "syllables": ["foot"], "chinese": "脚（单数）", "grade": 1, "unit": "身体与健康", "example": "Stamp your foot.", "gradeName": "一年级", "meaning": "脚（单数）", "pos": "n."}, {"id": "gd_102", "word": "feet", "phonetic": "/fiːt/", "syllables": ["feet"], "chinese": "双脚（复数）", "grade": 1, "unit": "身体与健康", "example": "Wash your feet.", "gradeName": "一年级", "meaning": "双脚（复数）", "pos": "n."}, {"id": "gd_103", "word": "body", "phonetic": "/ˈbɒdi/", "syllables": ["bod", "y"], "chinese": "身体", "grade": 1, "unit": "身体与健康", "example": "Exercise makes a strong body.", "gradeName": "一年级", "meaning": "身体", "pos": "n."}, {"id": "gd_104", "word": "finger", "phonetic": "/ˈfɪŋɡə(r)/", "syllables": ["fin", "ger"], "chinese": "手指", "grade": 1, "unit": "身体与健康", "example": "Count on your fingers.", "gradeName": "一年级", "meaning": "手指", "pos": "n."}, {"id": "gd_105", "word": "toe", "phonetic": "/təʊ/", "syllables": ["toe"], "chinese": "脚趾", "grade": 1, "unit": "身体与健康", "example": "Wiggle your toes.", "gradeName": "一年级", "meaning": "脚趾", "pos": "n."}, {"id": "gd_106", "word": "knee", "phonetic": "/niː/", "syllables": ["knee"], "chinese": "膝盖", "grade": 1, "unit": "身体与健康", "example": "Bend your knees.", "gradeName": "一年级", "meaning": "膝盖", "pos": "n."}, {"id": "gd_107", "word": "shoulder", "phonetic": "/ˈʃəʊldə(r)/", "syllables": ["shoul", "der"], "chinese": "肩膀", "grade": 2, "unit": "身体与健康", "example": "Touch your shoulders.", "gradeName": "二年级", "meaning": "肩膀", "pos": "n."}, {"id": "gd_108", "word": "tooth", "phonetic": "/tuːθ/", "syllables": ["tooth"], "chinese": "牙齿（单数）", "grade": 2, "unit": "身体与健康", "example": "Brush every single tooth.", "gradeName": "二年级", "meaning": "牙齿（单数）", "pos": "n."}, {"id": "gd_109", "word": "teeth", "phonetic": "/tiːθ/", "syllables": ["teeth"], "chinese": "牙齿（复数）", "grade": 2, "unit": "身体与健康", "example": "Keep your teeth clean.", "gradeName": "二年级", "meaning": "牙齿（复数）", "pos": "n."}, {"id": "gd_110", "word": "neck", "phonetic": "/nek/", "syllables": ["neck"], "chinese": "脖子；颈部", "grade": 2, "unit": "身体与健康", "example": "Giraffes have a long neck.", "gradeName": "二年级", "meaning": "脖子；颈部", "pos": "n."}, {"id": "gd_111", "word": "back", "phonetic": "/bæk/", "syllables": ["back"], "chinese": "背部；后面", "grade": 3, "unit": "身体与健康", "example": "Sit with your back straight.", "gradeName": "三年级", "meaning": "背部；后面", "pos": "n."}, {"id": "gd_112", "word": "stomach", "phonetic": "/ˈstʌmək/", "syllables": ["stom", "ach"], "chinese": "胃；腹部", "grade": 4, "unit": "身体与健康", "example": "My stomach feels full.", "gradeName": "四年级", "meaning": "胃；腹部", "pos": "n."}, {"id": "gd_113", "word": "heart", "phonetic": "/hɑːt/", "syllables": ["heart"], "chinese": "心脏；心愿", "grade": 4, "unit": "身体与健康", "example": "A kind and generous heart.", "gradeName": "四年级", "meaning": "心脏；心愿", "pos": "n."}, {"id": "gd_114", "word": "cold", "phonetic": "/kəʊld/", "syllables": ["cold"], "chinese": "感冒；寒冷", "grade": 3, "unit": "身体与健康", "example": "He caught a bad cold.", "gradeName": "三年级", "meaning": "感冒；寒冷", "pos": "n."}, {"id": "gd_115", "word": "fever", "phonetic": "/ˈfiːvə(r)/", "syllables": ["fe", "ver"], "chinese": "发烧；发热", "grade": 4, "unit": "身体与健康", "example": "Take medicine when you have a fever.", "gradeName": "四年级", "meaning": "发烧；发热", "pos": "n."}, {"id": "gd_116", "word": "father", "phonetic": "/ˈfɑːðə(r)/", "syllables": ["fa", "ther"], "chinese": "父亲；爸爸", "grade": 1, "unit": "温馨家庭", "example": "My father is very strong.", "gradeName": "一年级", "meaning": "父亲；爸爸", "pos": "n."}, {"id": "gd_117", "word": "mother", "phonetic": "/ˈmʌðə(r)/", "syllables": ["moth", "er"], "chinese": "母亲；妈妈", "grade": 1, "unit": "温馨家庭", "example": "My mother cooks delicious food.", "gradeName": "一年级", "meaning": "母亲；妈妈", "pos": "n."}, {"id": "gd_118", "word": "dad", "phonetic": "/dæd/", "syllables": ["dad"], "chinese": "爸爸（口语）", "grade": 1, "unit": "温馨家庭", "example": "Dad, let's play catch!", "gradeName": "一年级", "meaning": "爸爸（口语）", "pos": "n."}, {"id": "gd_119", "word": "mum", "phonetic": "/mʌm/", "syllables": ["mum"], "chinese": "妈妈（口语）", "grade": 1, "unit": "温馨家庭", "example": "Mum helps me learn English.", "gradeName": "一年级", "meaning": "妈妈（口语）", "pos": "n."}, {"id": "gd_120", "word": "brother", "phonetic": "/ˈbrʌðə(r)/", "syllables": ["broth", "er"], "chinese": "哥哥；弟弟", "grade": 1, "unit": "温馨家庭", "example": "My brother plays soccer.", "gradeName": "一年级", "meaning": "哥哥；弟弟", "pos": "n."}, {"id": "gd_121", "word": "sister", "phonetic": "/ˈsɪstə(r)/", "syllables": ["sis", "ter"], "chinese": "姐姐；妹妹", "grade": 1, "unit": "温馨家庭", "example": "My sister likes drawing.", "gradeName": "一年级", "meaning": "姐姐；妹妹", "pos": "n."}, {"id": "gd_122", "word": "grandfather", "phonetic": "/ˈɡrænfɑːðə(r)/", "syllables": ["grand", "fa", "ther"], "chinese": "祖父；外公", "grade": 1, "unit": "温馨家庭", "example": "My grandfather tells stories.", "gradeName": "一年级", "meaning": "祖父；外公", "pos": "n."}, {"id": "gd_123", "word": "grandmother", "phonetic": "/ˈɡrænmʌðə(r)/", "syllables": ["grand", "moth", "er"], "chinese": "祖母；外婆", "grade": 1, "unit": "温馨家庭", "example": "My grandmother bakes pies.", "gradeName": "一年级", "meaning": "祖母；外婆", "pos": "n."}, {"id": "gd_124", "word": "grandpa", "phonetic": "/ˈɡrænpɑː/", "syllables": ["grand", "pa"], "chinese": "爷爷；外公", "grade": 1, "unit": "温馨家庭", "example": "Grandpa waters flowers.", "gradeName": "一年级", "meaning": "爷爷；外公", "pos": "n."}, {"id": "gd_125", "word": "grandma", "phonetic": "/ˈɡrænmɑː/", "syllables": ["grand", "ma"], "chinese": "奶奶；外婆", "grade": 1, "unit": "温馨家庭", "example": "Grandma knits warm gloves.", "gradeName": "一年级", "meaning": "奶奶；外婆", "pos": "n."}, {"id": "gd_126", "word": "parent", "phonetic": "/ˈpeərənt/", "syllables": ["par", "ent"], "chinese": "父亲或母亲", "grade": 3, "unit": "温馨家庭", "example": "Respect your parents.", "gradeName": "三年级", "meaning": "父亲或母亲", "pos": "n."}, {"id": "gd_127", "word": "parents", "phonetic": "/ˈpeərənts/", "syllables": ["par", "ents"], "chinese": "父母亲", "grade": 3, "unit": "温馨家庭", "example": "My parents encourage me.", "gradeName": "三年级", "meaning": "父母亲", "pos": "n."}, {"id": "gd_128", "word": "uncle", "phonetic": "/ˈʌŋkl/", "syllables": ["un", "cle"], "chinese": "叔叔；伯伯；舅舅", "grade": 2, "unit": "温馨家庭", "example": "My uncle lives in Beijing.", "gradeName": "二年级", "meaning": "叔叔；伯伯；舅舅", "pos": "n."}, {"id": "gd_129", "word": "aunt", "phonetic": "/ɑːnt/", "syllables": ["aunt"], "chinese": "姑姑；阿姨；婶婶", "grade": 2, "unit": "温馨家庭", "example": "Aunt Mary brings gifts.", "gradeName": "二年级", "meaning": "姑姑；阿姨；婶婶", "pos": "n."}, {"id": "gd_130", "word": "cousin", "phonetic": "/ˈkʌzn/", "syllables": ["cous", "in"], "chinese": "堂（表）兄弟姐妹", "grade": 3, "unit": "温馨家庭", "example": "Play chess with my cousin.", "gradeName": "三年级", "meaning": "堂（表）兄弟姐妹", "pos": "n."}, {"id": "gd_131", "word": "baby", "phonetic": "/ˈbeɪbi/", "syllables": ["ba", "by"], "chinese": "婴儿；幼崽", "grade": 2, "unit": "温馨家庭", "example": "The baby is fast asleep.", "gradeName": "二年级", "meaning": "婴儿；幼崽", "pos": "n."}, {"id": "gd_132", "word": "son", "phonetic": "/sʌn/", "syllables": ["son"], "chinese": "儿子", "grade": 4, "unit": "温馨家庭", "example": "He is proud of his son.", "gradeName": "四年级", "meaning": "儿子", "pos": "n."}, {"id": "gd_133", "word": "daughter", "phonetic": "/ˈdɔːtə(r)/", "syllables": ["daugh", "ter"], "chinese": "女儿", "grade": 4, "unit": "温馨家庭", "example": "Their daughter plays violin.", "gradeName": "四年级", "meaning": "女儿", "pos": "n."}, {"id": "gd_134", "word": "boy", "phonetic": "/bɔɪ/", "syllables": ["boy"], "chinese": "男孩", "grade": 1, "unit": "温馨家庭", "example": "The boy is running fast.", "gradeName": "一年级", "meaning": "男孩", "pos": "n."}, {"id": "gd_135", "word": "girl", "phonetic": "/ɡɜːl/", "syllables": ["girl"], "chinese": "女孩", "grade": 1, "unit": "温馨家庭", "example": "The girl dances gracefully.", "gradeName": "一年级", "meaning": "女孩", "pos": "n."}, {"id": "gd_136", "word": "man", "phonetic": "/mæn/", "syllables": ["man"], "chinese": "男人；成年男子", "grade": 1, "unit": "温馨家庭", "example": "The man carries a heavy box.", "gradeName": "一年级", "meaning": "男人；成年男子", "pos": "n."}, {"id": "gd_137", "word": "men", "phonetic": "/men/", "syllables": ["men"], "chinese": "男人（复数）", "grade": 3, "unit": "温馨家庭", "example": "Three men working together.", "gradeName": "三年级", "meaning": "男人（复数）", "pos": "n."}, {"id": "gd_138", "word": "woman", "phonetic": "/ˈwʊmən/", "syllables": ["wom", "an"], "chinese": "女人；成年女子", "grade": 1, "unit": "温馨家庭", "example": "The woman is our teacher.", "gradeName": "一年级", "meaning": "女人；成年女子", "pos": "n."}, {"id": "gd_139", "word": "women", "phonetic": "/ˈwɪmɪn/", "syllables": ["wom", "en"], "chinese": "女人（复数）", "grade": 3, "unit": "温馨家庭", "example": "Smart women leaders.", "gradeName": "三年级", "meaning": "女人（复数）", "pos": "n."}, {"id": "gd_140", "word": "child", "phonetic": "/tʃaɪld/", "syllables": ["child"], "chinese": "儿童；孩子（单数）", "grade": 3, "unit": "温馨家庭", "example": "Every child is unique.", "gradeName": "三年级", "meaning": "儿童；孩子（单数）", "pos": "n."}, {"id": "gd_141", "word": "children", "phonetic": "/ˈtʃɪldrən/", "syllables": ["chil", "dren"], "chinese": "孩子们（复数）", "grade": 3, "unit": "温馨家庭", "example": "Children laugh happily.", "gradeName": "三年级", "meaning": "孩子们（复数）", "pos": "n."}, {"id": "gd_142", "word": "kid", "phonetic": "/kɪd/", "syllables": ["kid"], "chinese": "小孩子", "grade": 2, "unit": "温馨家庭", "example": "Kids play on swings.", "gradeName": "二年级", "meaning": "小孩子", "pos": "adj."}, {"id": "gd_143", "word": "people", "phonetic": "/ˈpiːpl/", "syllables": ["peo", "ple"], "chinese": "人；人们", "grade": 3, "unit": "温馨家庭", "example": "Many people visit the park.", "gradeName": "三年级", "meaning": "人；人们", "pos": "n."}, {"id": "gd_144", "word": "friend", "phonetic": "/frend/", "syllables": ["friend"], "chinese": "朋友", "grade": 1, "unit": "温馨家庭", "example": "A loyal friend is a treasure.", "gradeName": "一年级", "meaning": "朋友", "pos": "n."}, {"id": "gd_145", "word": "classmate", "phonetic": "/ˈklɑːsmeɪt/", "syllables": ["class", "mate"], "chinese": "同班同学", "grade": 2, "unit": "温馨家庭", "example": "Help your classmates cheerfully.", "gradeName": "二年级", "meaning": "同班同学", "pos": "adj."}, {"id": "gd_146", "word": "book", "phonetic": "/bʊk/", "syllables": ["book"], "chinese": "书；书籍", "grade": 1, "unit": "校园文具", "example": "Open your book, please.", "gradeName": "一年级", "meaning": "书；书籍", "pos": "n."}, {"id": "gd_147", "word": "ruler", "phonetic": "/ˈruːlə(r)/", "syllables": ["ru", "ler"], "chinese": "尺子", "grade": 1, "unit": "校园文具", "example": "I have a green ruler.", "gradeName": "一年级", "meaning": "尺子", "pos": "n."}, {"id": "gd_148", "word": "pencil", "phonetic": "/ˈpensl/", "syllables": ["pen", "cil"], "chinese": "铅笔", "grade": 1, "unit": "校园文具", "example": "Sharpen your pencil.", "gradeName": "一年级", "meaning": "铅笔", "pos": "n."}, {"id": "gd_149", "word": "eraser", "phonetic": "/ɪˈreɪzə(r)/", "syllables": ["e", "ra", "ser"], "chinese": "橡皮擦", "grade": 1, "unit": "校园文具", "example": "Use an eraser to fix it.", "gradeName": "一年级", "meaning": "橡皮擦", "pos": "n."}, {"id": "gd_150", "word": "pen", "phonetic": "/pen/", "syllables": ["pen"], "chinese": "钢笔；圆珠笔", "grade": 1, "unit": "校园文具", "example": "Write with a blue pen.", "gradeName": "一年级", "meaning": "钢笔；圆珠笔", "pos": "n."}, {"id": "gd_151", "word": "bag", "phonetic": "/bæɡ/", "syllables": ["bag"], "chinese": "书包；袋子", "grade": 1, "unit": "校园文具", "example": "Put the book into the bag.", "gradeName": "一年级", "meaning": "书包；袋子", "pos": "n."}, {"id": "gd_152", "word": "schoolbag", "phonetic": "/ˈskuːlbæɡ/", "syllables": ["school", "bag"], "chinese": "书包", "grade": 1, "unit": "校园文具", "example": "My schoolbag is heavy.", "gradeName": "一年级", "meaning": "书包", "pos": "n."}, {"id": "gd_153", "word": "crayon", "phonetic": "/ˈkreɪən/", "syllables": ["cray", "on"], "chinese": "蜡笔", "grade": 1, "unit": "校园文具", "example": "Draw flowers with crayons.", "gradeName": "一年级", "meaning": "蜡笔", "pos": "n."}, {"id": "gd_154", "word": "sharpener", "phonetic": "/ˈʃɑːpnə(r)/", "syllables": ["sharp", "en", "er"], "chinese": "卷笔刀", "grade": 1, "unit": "校园文具", "example": "May I borrow your sharpener?", "gradeName": "一年级", "meaning": "卷笔刀", "pos": "n."}, {"id": "gd_155", "word": "pencil-box", "phonetic": "/ˈpensl bɒks/", "syllables": ["pen", "cil", "box"], "chinese": "铅笔盒", "grade": 1, "unit": "校园文具", "example": "My pencil-box is on the desk.", "gradeName": "一年级", "meaning": "铅笔盒", "pos": "n."}, {"id": "gd_156", "word": "desk", "phonetic": "/desk/", "syllables": ["desk"], "chinese": "书桌", "grade": 1, "unit": "校园文具", "example": "Clean your desk.", "gradeName": "一年级", "meaning": "书桌", "pos": "n."}, {"id": "gd_157", "word": "chair", "phonetic": "/tʃeə(r)/", "syllables": ["chair"], "chinese": "椅子", "grade": 1, "unit": "校园文具", "example": "Sit on the chair.", "gradeName": "一年级", "meaning": "椅子", "pos": "n."}, {"id": "gd_158", "word": "blackboard", "phonetic": "/ˈblækbɔːd/", "syllables": ["black", "board"], "chinese": "黑板", "grade": 1, "unit": "校园文具", "example": "Look at the blackboard.", "gradeName": "一年级", "meaning": "黑板", "pos": "adj."}, {"id": "gd_159", "word": "paper", "phonetic": "/ˈpeɪpə(r)/", "syllables": ["pa", "per"], "chinese": "纸张", "grade": 1, "unit": "校园文具", "example": "Write on clean white paper.", "gradeName": "一年级", "meaning": "纸张", "pos": "n."}, {"id": "gd_160", "word": "scissors", "phonetic": "/ˈsɪzəz/", "syllables": ["scis", "sors"], "chinese": "剪刀", "grade": 2, "unit": "校园文具", "example": "Be careful with sharp scissors.", "gradeName": "二年级", "meaning": "剪刀", "pos": "n."}, {"id": "gd_161", "word": "glue", "phonetic": "/ɡluː/", "syllables": ["glue"], "chinese": "胶水", "grade": 2, "unit": "校园文具", "example": "Paste paper with glue.", "gradeName": "二年级", "meaning": "胶水", "pos": "n."}, {"id": "gd_162", "word": "notebook", "phonetic": "/ˈnəʊtbʊk/", "syllables": ["note", "book"], "chinese": "笔记本", "grade": 2, "unit": "校园文具", "example": "Take notes in your notebook.", "gradeName": "二年级", "meaning": "笔记本", "pos": "n."}, {"id": "gd_163", "word": "marker", "phonetic": "/ˈmɑːkə(r)/", "syllables": ["mar", "ker"], "chinese": "马克笔", "grade": 2, "unit": "校园文具", "example": "Color posters with markers.", "gradeName": "二年级", "meaning": "马克笔", "pos": "n."}, {"id": "gd_164", "word": "school", "phonetic": "/skuːl/", "syllables": ["school"], "chinese": "学校", "grade": 1, "unit": "校园文具", "example": "Walk to school every day.", "gradeName": "一年级", "meaning": "学校", "pos": "v."}, {"id": "gd_165", "word": "classroom", "phonetic": "/ˈklɑːsruːm/", "syllables": ["class", "room"], "chinese": "教室", "grade": 1, "unit": "校园文具", "example": "Keep the classroom quiet.", "gradeName": "一年级", "meaning": "教室", "pos": "v."}, {"id": "gd_166", "word": "teacher", "phonetic": "/ˈtiːtʃə(r)/", "syllables": ["teach", "er"], "chinese": "老师", "grade": 1, "unit": "校园文具", "example": "Respect your teacher.", "gradeName": "一年级", "meaning": "老师", "pos": "n."}, {"id": "gd_167", "word": "student", "phonetic": "/ˈstjuːdnt/", "syllables": ["stu", "dent"], "chinese": "学生", "grade": 1, "unit": "校园文具", "example": "Diligent students learn fast.", "gradeName": "一年级", "meaning": "学生", "pos": "v."}, {"id": "gd_168", "word": "class", "phonetic": "/klɑːs/", "syllables": ["class"], "chinese": "班级；课程", "grade": 1, "unit": "校园文具", "example": "Class begins at eight.", "gradeName": "一年级", "meaning": "班级；课程", "pos": "n."}, {"id": "gd_169", "word": "lesson", "phonetic": "/ˈlesn/", "syllables": ["les", "son"], "chinese": "功课；课", "grade": 2, "unit": "校园文具", "example": "Review your lesson carefully.", "gradeName": "二年级", "meaning": "功课；课", "pos": "n."}, {"id": "gd_170", "word": "homework", "phonetic": "/ˈhəʊmwɜːk/", "syllables": ["home", "work"], "chinese": "家庭作业", "grade": 2, "unit": "校园文具", "example": "Finish your homework on time.", "gradeName": "二年级", "meaning": "家庭作业", "pos": "n."}, {"id": "gd_171", "word": "English", "phonetic": "/ˈɪŋɡlɪʃ/", "syllables": ["Eng", "lish"], "chinese": "英语；英文", "grade": 3, "unit": "校园课程", "example": "Practice English every day.", "gradeName": "三年级", "meaning": "英语；英文", "pos": "n."}, {"id": "gd_172", "word": "Chinese", "phonetic": "/ˌtʃaɪˈniːz/", "syllables": ["Chi", "nese"], "chinese": "语文；中文", "grade": 3, "unit": "校园课程", "example": "Chinese culture is profound.", "gradeName": "三年级", "meaning": "语文；中文", "pos": "n."}, {"id": "gd_173", "word": "maths", "phonetic": "/mæθs/", "syllables": ["maths"], "chinese": "数学", "grade": 3, "unit": "校园课程", "example": "Maths trains logical thinking.", "gradeName": "三年级", "meaning": "数学", "pos": "n."}, {"id": "gd_174", "word": "science", "phonetic": "/ˈsaɪəns/", "syllables": ["sci", "ence"], "chinese": "科学", "grade": 3, "unit": "校园课程", "example": "Science unlocks world wonders.", "gradeName": "三年级", "meaning": "科学", "pos": "n."}, {"id": "gd_175", "word": "music", "phonetic": "/ˈmjuːzɪk/", "syllables": ["mu", "sic"], "chinese": "音乐", "grade": 3, "unit": "校园课程", "example": "Music calms restless minds.", "gradeName": "三年级", "meaning": "音乐", "pos": "n."}, {"id": "gd_176", "word": "art", "phonetic": "/ɑːt/", "syllables": ["art"], "chinese": "美术；艺术", "grade": 3, "unit": "校园课程", "example": "Paint vivid landscapes in art.", "gradeName": "三年级", "meaning": "美术；艺术", "pos": "adj."}, {"id": "gd_177", "word": "PE", "phonetic": "/ˌpiː ˈiː/", "syllables": ["P", "E"], "chinese": "体育课", "grade": 3, "unit": "校园课程", "example": "We play basketball in PE.", "gradeName": "三年级", "meaning": "体育课", "pos": "n."}, {"id": "gd_178", "word": "history", "phonetic": "/ˈhɪstri/", "syllables": ["his", "to", "ry"], "chinese": "历史", "grade": 5, "unit": "校园课程", "example": "Learn lessons from history.", "gradeName": "五年级", "meaning": "历史", "pos": "n."}, {"id": "gd_179", "word": "subject", "phonetic": "/ˈsʌbdʒɪkt/", "syllables": ["sub", "ject"], "chinese": "学科；科目", "grade": 3, "unit": "校园课程", "example": "What is your favorite subject?", "gradeName": "三年级", "meaning": "学科；科目", "pos": "v."}, {"id": "gd_180", "word": "library", "phonetic": "/ˈlaɪbrəri/", "syllables": ["li", "brar", "y"], "chinese": "图书馆", "grade": 2, "unit": "校园设施", "example": "Read quiet books in the library.", "gradeName": "二年级", "meaning": "图书馆", "pos": "n."}, {"id": "gd_181", "word": "playground", "phonetic": "/ˈpleɪɡraʊnd/", "syllables": ["play", "ground"], "chinese": "操场", "grade": 2, "unit": "校园设施", "example": "Run freely on the playground.", "gradeName": "二年级", "meaning": "操场", "pos": "n."}, {"id": "gd_182", "word": "gym", "phonetic": "/dʒɪm/", "syllables": ["gym"], "chinese": "体育馆；健身房", "grade": 3, "unit": "校园设施", "example": "Play badminton in gym.", "gradeName": "三年级", "meaning": "体育馆；健身房", "pos": "n."}, {"id": "gd_183", "word": "canteen", "phonetic": "/kænˈtiːn/", "syllables": ["can", "teen"], "chinese": "食堂", "grade": 2, "unit": "校园设施", "example": "Line up for lunch at canteen.", "gradeName": "二年级", "meaning": "食堂", "pos": "n."}, {"id": "gd_184", "word": "office", "phonetic": "/ˈɒfɪs/", "syllables": ["of", "fice"], "chinese": "办公室", "grade": 3, "unit": "校园设施", "example": "Teachers work in the office.", "gradeName": "三年级", "meaning": "办公室", "pos": "n."}, {"id": "gd_185", "word": "hall", "phonetic": "/hɔːl/", "syllables": ["hall"], "chinese": "礼堂；大厅", "grade": 4, "unit": "校园设施", "example": "School assembly in the hall.", "gradeName": "四年级", "meaning": "礼堂；大厅", "pos": "adj."}, {"id": "gd_186", "word": "lab", "phonetic": "/læb/", "syllables": ["lab"], "chinese": "实验室", "grade": 5, "unit": "校园设施", "example": "Chemistry experiment in lab.", "gradeName": "五年级", "meaning": "实验室", "pos": "n."}, {"id": "gd_187", "word": "grade", "phonetic": "/ɡreɪd/", "syllables": ["grade"], "chinese": "年级；成绩", "grade": 2, "unit": "校园生活", "example": "I am in third grade.", "gradeName": "二年级", "meaning": "年级；成绩", "pos": "adj."}, {"id": "gd_188", "word": "term", "phonetic": "/tɜːm/", "syllables": ["term"], "chinese": "学期", "grade": 4, "unit": "校园生活", "example": "A brand new school term.", "gradeName": "四年级", "meaning": "学期", "pos": "v."}, {"id": "gd_189", "word": "exam", "phonetic": "/ɪɡˈzæm/", "syllables": ["ex", "am"], "chinese": "考试", "grade": 4, "unit": "校园生活", "example": "Prepare well for the exam.", "gradeName": "四年级", "meaning": "考试", "pos": "n."}, {"id": "gd_190", "word": "test", "phonetic": "/test/", "syllables": ["test"], "chinese": "测验；测试", "grade": 3, "unit": "校园生活", "example": "Score full marks in test.", "gradeName": "三年级", "meaning": "测验；测试", "pos": "n."}, {"id": "gd_191", "word": "rule", "phonetic": "/ruːl/", "syllables": ["rule"], "chinese": "规则；校规", "grade": 3, "unit": "校园生活", "example": "Follow school safety rules.", "gradeName": "三年级", "meaning": "规则；校规", "pos": "n."}, {"id": "gd_192", "word": "bell", "phonetic": "/bel/", "syllables": ["bell"], "chinese": "铃声；钟", "grade": 2, "unit": "校园生活", "example": "The class bell rings.", "gradeName": "二年级", "meaning": "铃声；钟", "pos": "n."}, {"id": "gd_193", "word": "song", "phonetic": "/sɒŋ/", "syllables": ["song"], "chinese": "歌曲", "grade": 2, "unit": "校园生活", "example": "Sing a cheerful English song.", "gradeName": "二年级", "meaning": "歌曲", "pos": "n."}, {"id": "gd_194", "word": "story", "phonetic": "/ˈstɔːri/", "syllables": ["sto", "ry"], "chinese": "故事", "grade": 2, "unit": "校园生活", "example": "Listen to an inspiring story.", "gradeName": "二年级", "meaning": "故事", "pos": "n."}, {"id": "gd_195", "word": "question", "phonetic": "/ˈkwestʃən/", "syllables": ["ques", "tion"], "chinese": "问题", "grade": 3, "unit": "校园生活", "example": "Raise your hand to ask a question.", "gradeName": "三年级", "meaning": "问题", "pos": "n."}, {"id": "gd_196", "word": "apple", "phonetic": "/ˈæpl/", "syllables": ["ap", "ple"], "chinese": "苹果", "grade": 2, "unit": "美味饮食", "example": "An apple a day keeps the doctor away.", "gradeName": "二年级", "meaning": "苹果", "pos": "n."}, {"id": "gd_197", "word": "banana", "phonetic": "/bəˈnɑːnə/", "syllables": ["ba", "nan", "a"], "chinese": "香蕉", "grade": 2, "unit": "美味饮食", "example": "Monkeys like yellow bananas.", "gradeName": "二年级", "meaning": "香蕉", "pos": "n."}, {"id": "gd_198", "word": "pear", "phonetic": "/peə(r)/", "syllables": ["pear"], "chinese": "梨", "grade": 2, "unit": "美味饮食", "example": "The pear is juicy and sweet.", "gradeName": "二年级", "meaning": "梨", "pos": "n."}, {"id": "gd_199", "word": "watermelon", "phonetic": "/ˈwɔːtəmelən/", "syllables": ["wa", "ter", "mel", "on"], "chinese": "西瓜", "grade": 2, "unit": "美味饮食", "example": "Watermelon is my summer treat.", "gradeName": "二年级", "meaning": "西瓜", "pos": "n."}, {"id": "gd_200", "word": "grape", "phonetic": "/ɡreɪp/", "syllables": ["grape"], "chinese": "葡萄", "grade": 2, "unit": "美味饮食", "example": "Sweet purple grapes grow on vines.", "gradeName": "二年级", "meaning": "葡萄", "pos": "n."}, {"id": "gd_201", "word": "strawberry", "phonetic": "/ˈstrɔːbəri/", "syllables": ["straw", "ber", "ry"], "chinese": "草莓", "grade": 2, "unit": "美味饮食", "example": "Fresh strawberries are red.", "gradeName": "二年级", "meaning": "草莓", "pos": "n."}, {"id": "gd_202", "word": "peach", "phonetic": "/piːtʃ/", "syllables": ["peach"], "chinese": "桃子", "grade": 2, "unit": "美味饮食", "example": "The peach smells very nice.", "gradeName": "二年级", "meaning": "桃子", "pos": "n."}, {"id": "gd_203", "word": "fruit", "phonetic": "/fruːt/", "syllables": ["fruit"], "chinese": "水果", "grade": 2, "unit": "美味饮食", "example": "Eat more fruit to stay healthy.", "gradeName": "二年级", "meaning": "水果", "pos": "n."}, {"id": "gd_204", "word": "lemon", "phonetic": "/ˈlemən/", "syllables": ["lem", "on"], "chinese": "柠檬", "grade": 2, "unit": "美味饮食", "example": "Lemons taste fresh and sour.", "gradeName": "二年级", "meaning": "柠檬", "pos": "n."}, {"id": "gd_205", "word": "mango", "phonetic": "/ˈmæŋɡəʊ/", "syllables": ["man", "go"], "chinese": "芒果", "grade": 2, "unit": "美味饮食", "example": "Sweet tropical mango slices.", "gradeName": "二年级", "meaning": "芒果", "pos": "n."}, {"id": "gd_206", "word": "pineapple", "phonetic": "/ˈpaɪnæpl/", "syllables": ["pine", "ap", "ple"], "chinese": "菠萝", "grade": 2, "unit": "美味饮食", "example": "Pineapple on sweet pizza.", "gradeName": "二年级", "meaning": "菠萝", "pos": "n."}, {"id": "gd_207", "word": "cherry", "phonetic": "/ˈtʃeri/", "syllables": ["cher", "ry"], "chinese": "樱桃", "grade": 2, "unit": "美味饮食", "example": "Bright red ripe cherries.", "gradeName": "二年级", "meaning": "樱桃", "pos": "n."}, {"id": "gd_208", "word": "tomato", "phonetic": "/təˈmɑːtəʊ/", "syllables": ["to", "ma", "to"], "chinese": "西红柿；番茄", "grade": 3, "unit": "美味饮食", "example": "Ripe tomatoes in garden.", "gradeName": "三年级", "meaning": "西红柿；番茄", "pos": "n."}, {"id": "gd_209", "word": "potato", "phonetic": "/pəˈteɪtəʊ/", "syllables": ["po", "ta", "to"], "chinese": "土豆；马铃薯", "grade": 3, "unit": "美味饮食", "example": "Mashed potatoes with butter.", "gradeName": "三年级", "meaning": "土豆；马铃薯", "pos": "n."}, {"id": "gd_210", "word": "carrot", "phonetic": "/ˈkærət/", "syllables": ["car", "rot"], "chinese": "胡萝卜", "grade": 2, "unit": "美味饮食", "example": "Rabbits crunch crunchy carrots.", "gradeName": "二年级", "meaning": "胡萝卜", "pos": "n."}, {"id": "gd_211", "word": "onion", "phonetic": "/ˈʌnjən/", "syllables": ["on", "ion"], "chinese": "洋葱", "grade": 3, "unit": "美味饮食", "example": "Chop onions for beef stew.", "gradeName": "三年级", "meaning": "洋葱", "pos": "n."}, {"id": "gd_212", "word": "cucumber", "phonetic": "/ˈkjuːkʌmbə(r)/", "syllables": ["cu", "cum", "ber"], "chinese": "黄瓜", "grade": 3, "unit": "美味饮食", "example": "Cool and fresh cucumbers.", "gradeName": "三年级", "meaning": "黄瓜", "pos": "adj."}, {"id": "gd_213", "word": "mushroom", "phonetic": "/ˈmʌʃrʊm/", "syllables": ["mush", "room"], "chinese": "蘑菇", "grade": 3, "unit": "美味饮食", "example": "Wild mushrooms in forest.", "gradeName": "三年级", "meaning": "蘑菇", "pos": "n."}, {"id": "gd_214", "word": "bean", "phonetic": "/biːn/", "syllables": ["bean"], "chinese": "豆子；豆类", "grade": 3, "unit": "美味饮食", "example": "Green beans are nutritious.", "gradeName": "三年级", "meaning": "豆子；豆类", "pos": "n."}, {"id": "gd_215", "word": "cabbage", "phonetic": "/ˈkæbɪdʒ/", "syllables": ["cab", "bage"], "chinese": "卷心菜", "grade": 3, "unit": "美味饮食", "example": "Crispy shredded cabbage.", "gradeName": "三年级", "meaning": "卷心菜", "pos": "n."}, {"id": "gd_216", "word": "rice", "phonetic": "/raɪs/", "syllables": ["rice"], "chinese": "米饭；水稻", "grade": 2, "unit": "美味饮食", "example": "Chinese people eat white rice.", "gradeName": "二年级", "meaning": "米饭；水稻", "pos": "n."}, {"id": "gd_217", "word": "noodle", "phonetic": "/ˈnuːdl/", "syllables": ["noo", "dle"], "chinese": "面条", "grade": 2, "unit": "美味饮食", "example": "I like beef noodles for lunch.", "gradeName": "二年级", "meaning": "面条", "pos": "n."}, {"id": "gd_218", "word": "bread", "phonetic": "/bred/", "syllables": ["bread"], "chinese": "面包", "grade": 2, "unit": "美味饮食", "example": "Bake fresh bread every day.", "gradeName": "二年级", "meaning": "面包", "pos": "n."}, {"id": "gd_219", "word": "egg", "phonetic": "/eɡ/", "syllables": ["egg"], "chinese": "鸡蛋；卵", "grade": 2, "unit": "美味饮食", "example": "Boil an egg for breakfast.", "gradeName": "二年级", "meaning": "鸡蛋；卵", "pos": "n."}, {"id": "gd_220", "word": "milk", "phonetic": "/mɪlk/", "syllables": ["milk"], "chinese": "牛奶", "grade": 2, "unit": "美味饮食", "example": "Drink warm milk before bed.", "gradeName": "二年级", "meaning": "牛奶", "pos": "n."}, {"id": "gd_221", "word": "water", "phonetic": "/ˈwɔːtə(r)/", "syllables": ["wa", "ter"], "chinese": "水", "grade": 2, "unit": "美味饮食", "example": "Drink plenty of water.", "gradeName": "二年级", "meaning": "水", "pos": "n."}, {"id": "gd_222", "word": "juice", "phonetic": "/dʒuːs/", "syllables": ["juice"], "chinese": "果汁", "grade": 2, "unit": "美味饮食", "example": "Would you like some orange juice?", "gradeName": "二年级", "meaning": "果汁", "pos": "n."}, {"id": "gd_223", "word": "tea", "phonetic": "/tiː/", "syllables": ["tea"], "chinese": "茶", "grade": 2, "unit": "美味饮食", "example": "Grandfather loves green tea.", "gradeName": "二年级", "meaning": "茶", "pos": "n."}, {"id": "gd_224", "word": "coffee", "phonetic": "/ˈkɒfi/", "syllables": ["cof", "fee"], "chinese": "咖啡", "grade": 2, "unit": "美味饮食", "example": "Coffee gives energy in the morning.", "gradeName": "二年级", "meaning": "咖啡", "pos": "n."}, {"id": "gd_225", "word": "soup", "phonetic": "/suːp/", "syllables": ["soup"], "chinese": "汤", "grade": 2, "unit": "美味饮食", "example": "The tomato soup is delicious.", "gradeName": "二年级", "meaning": "汤", "pos": "n."}, {"id": "gd_226", "word": "cake", "phonetic": "/keɪk/", "syllables": ["cake"], "chinese": "蛋糕", "grade": 2, "unit": "美味饮食", "example": "Cut the birthday cake together.", "gradeName": "二年级", "meaning": "蛋糕", "pos": "n."}, {"id": "gd_227", "word": "candy", "phonetic": "/ˈkændi/", "syllables": ["can", "dy"], "chinese": "糖果", "grade": 2, "unit": "美味饮食", "example": "Do not eat too much candy.", "gradeName": "二年级", "meaning": "糖果", "pos": "n."}, {"id": "gd_228", "word": "chicken", "phonetic": "/ˈtʃɪkɪn/", "syllables": ["chick", "en"], "chinese": "鸡肉；小鸡", "grade": 2, "unit": "美味饮食", "example": "We have roast chicken tonight.", "gradeName": "二年级", "meaning": "鸡肉；小鸡", "pos": "n."}, {"id": "gd_229", "word": "meat", "phonetic": "/miːt/", "syllables": ["meat"], "chinese": "肉类", "grade": 2, "unit": "美味饮食", "example": "Fresh meat provides protein.", "gradeName": "二年级", "meaning": "肉类", "pos": "n."}, {"id": "gd_230", "word": "beef", "phonetic": "/biːf/", "syllables": ["beef"], "chinese": "牛肉", "grade": 2, "unit": "美味饮食", "example": "Steak is tender beef.", "gradeName": "二年级", "meaning": "牛肉", "pos": "n."}, {"id": "gd_231", "word": "pork", "phonetic": "/pɔːk/", "syllables": ["pork"], "chinese": "猪肉", "grade": 2, "unit": "美味饮食", "example": "Sweet and sour pork ribs.", "gradeName": "二年级", "meaning": "猪肉", "pos": "n."}, {"id": "gd_232", "word": "cheese", "phonetic": "/tʃiːz/", "syllables": ["cheese"], "chinese": "奶酪；芝士", "grade": 2, "unit": "美味饮食", "example": "Melted cheese tastes rich.", "gradeName": "二年级", "meaning": "奶酪；芝士", "pos": "n."}, {"id": "gd_233", "word": "cookie", "phonetic": "/ˈkʊki/", "syllables": ["cook", "ie"], "chinese": "曲奇饼干", "grade": 2, "unit": "美味饮食", "example": "Chocolate chip cookies.", "gradeName": "二年级", "meaning": "曲奇饼干", "pos": "n."}, {"id": "gd_234", "word": "sandwich", "phonetic": "/ˈsænwɪtʃ/", "syllables": ["sand", "wich"], "chinese": "三明治", "grade": 2, "unit": "美味饮食", "example": "A ham and lettuce sandwich.", "gradeName": "二年级", "meaning": "三明治", "pos": "n."}, {"id": "gd_235", "word": "hamburger", "phonetic": "/ˈhæmbɜːɡə(r)/", "syllables": ["ham", "bur", "ger"], "chinese": "汉堡包", "grade": 2, "unit": "美味饮食", "example": "Juicy homemade hamburger.", "gradeName": "二年级", "meaning": "汉堡包", "pos": "n."}, {"id": "gd_236", "word": "salad", "phonetic": "/ˈsæləd/", "syllables": ["sal", "ad"], "chinese": "沙拉", "grade": 2, "unit": "美味饮食", "example": "Crispy garden vegetable salad.", "gradeName": "二年级", "meaning": "沙拉", "pos": "n."}, {"id": "gd_237", "word": "pizza", "phonetic": "/ˈpiːtsə/", "syllables": ["piz", "za"], "chinese": "披萨", "grade": 3, "unit": "美味饮食", "example": "Share a large cheese pizza.", "gradeName": "三年级", "meaning": "披萨", "pos": "n."}, {"id": "gd_238", "word": "dumpling", "phonetic": "/ˈdʌmplɪŋ/", "syllables": ["dump", "ling"], "chinese": "饺子", "grade": 3, "unit": "美味饮食", "example": "Eat dumplings at Spring Festival.", "gradeName": "三年级", "meaning": "饺子", "pos": "n."}, {"id": "gd_239", "word": "snack", "phonetic": "/snæk/", "syllables": ["snack"], "chinese": "零食；点心", "grade": 3, "unit": "美味饮食", "example": "Healthy fruit snacks.", "gradeName": "三年级", "meaning": "零食；点心", "pos": "n."}, {"id": "gd_240", "word": "ice-cream", "phonetic": "/ˌaɪs ˈkriːm/", "syllables": ["ice", "cream"], "chinese": "冰淇淋", "grade": 2, "unit": "美味饮食", "example": "Vanilla ice-cream cone.", "gradeName": "二年级", "meaning": "冰淇淋", "pos": "n."}, {"id": "gd_241", "word": "chocolate", "phonetic": "/ˈtʃɒklət/", "syllables": ["choc", "o", "late"], "chinese": "巧克力", "grade": 3, "unit": "美味饮食", "example": "Dark sweet chocolate bar.", "gradeName": "三年级", "meaning": "巧克力", "pos": "n."}, {"id": "gd_242", "word": "sugar", "phonetic": "/ˈʃʊɡə(r)/", "syllables": ["su", "gar"], "chinese": "糖", "grade": 3, "unit": "美味饮食", "example": "Do not add too much sugar.", "gradeName": "三年级", "meaning": "糖", "pos": "n."}, {"id": "gd_243", "word": "salt", "phonetic": "/sɔːlt/", "syllables": ["salt"], "chinese": "盐", "grade": 3, "unit": "美味饮食", "example": "A pinch of salt in cooking.", "gradeName": "三年级", "meaning": "盐", "pos": "n."}, {"id": "gd_244", "word": "butter", "phonetic": "/ˈbʌtə(r)/", "syllables": ["but", "ter"], "chinese": "黄油", "grade": 3, "unit": "美味饮食", "example": "Spread butter on toast.", "gradeName": "三年级", "meaning": "黄油", "pos": "adj."}, {"id": "gd_245", "word": "honey", "phonetic": "/ˈhʌni/", "syllables": ["hon", "ey"], "chinese": "蜂蜜", "grade": 3, "unit": "美味饮食", "example": "Golden sweet bee honey.", "gradeName": "三年级", "meaning": "蜂蜜", "pos": "n."}, {"id": "gd_246", "word": "hungry", "phonetic": "/ˈhʌŋɡri/", "syllables": ["hun", "gry"], "chinese": "饥饿的", "grade": 2, "unit": "美味饮食", "example": "I am so hungry after sports.", "gradeName": "二年级", "meaning": "饥饿的", "pos": "n."}, {"id": "gd_247", "word": "thirsty", "phonetic": "/ˈθɜːsti/", "syllables": ["thirs", "ty"], "chinese": "口渴的", "grade": 2, "unit": "美味饮食", "example": "Drink water when you are thirsty.", "gradeName": "二年级", "meaning": "口渴的", "pos": "n."}, {"id": "gd_248", "word": "full", "phonetic": "/fʊl/", "syllables": ["full"], "chinese": "饱的；充满的", "grade": 3, "unit": "美味饮食", "example": "I am full after dinner.", "gradeName": "三年级", "meaning": "饱的；充满的", "pos": "n."}, {"id": "gd_249", "word": "delicious", "phonetic": "/dɪˈlɪʃəs/", "syllables": ["de", "li", "cious"], "chinese": "美味的；可口的", "grade": 3, "unit": "美味饮食", "example": "Mom's dishes are delicious.", "gradeName": "三年级", "meaning": "美味的；可口的", "pos": "adj."}, {"id": "gd_250", "word": "sweet", "phonetic": "/swiːt/", "syllables": ["sweet"], "chinese": "甜的；芳香的", "grade": 2, "unit": "美味饮食", "example": "Honey is sweet and healthy.", "gradeName": "二年级", "meaning": "甜的；芳香的", "pos": "n."}, {"id": "gd_251", "word": "sour", "phonetic": "/ˈsaʊə(r)/", "syllables": ["sour"], "chinese": "酸的", "grade": 3, "unit": "美味饮食", "example": "Green apples taste slightly sour.", "gradeName": "三年级", "meaning": "酸的", "pos": "n."}, {"id": "gd_252", "word": "breakfast", "phonetic": "/ˈbrekfəst/", "syllables": ["break", "fast"], "chinese": "早餐", "grade": 3, "unit": "美味饮食", "example": "Never skip nutritious breakfast.", "gradeName": "三年级", "meaning": "早餐", "pos": "n."}, {"id": "gd_253", "word": "lunch", "phonetic": "/lʌntʃ/", "syllables": ["lunch"], "chinese": "午餐", "grade": 3, "unit": "美味饮食", "example": "Have a healthy lunch at noon.", "gradeName": "三年级", "meaning": "午餐", "pos": "n."}, {"id": "gd_254", "word": "dinner", "phonetic": "/ˈdɪnə(r)/", "syllables": ["din", "ner"], "chinese": "正餐；晚餐", "grade": 3, "unit": "美味饮食", "example": "Family gathers for dinner.", "gradeName": "三年级", "meaning": "正餐；晚餐", "pos": "n."}, {"id": "gd_255", "word": "meal", "phonetic": "/miːl/", "syllables": ["meal"], "chinese": "一餐；饭食", "grade": 3, "unit": "美味饮食", "example": "Enjoy three square meals.", "gradeName": "三年级", "meaning": "一餐；饭食", "pos": "n."}, {"id": "gd_256", "word": "shirt", "phonetic": "/ʃɜːt/", "syllables": ["shirt"], "chinese": "衬衫（男士）", "grade": 2, "unit": "服饰穿搭", "example": "Iron your white shirt.", "gradeName": "二年级", "meaning": "衬衫（男士）", "pos": "n."}, {"id": "gd_257", "word": "T-shirt", "phonetic": "/ˈtiː ʃɜːt/", "syllables": ["T", "shirt"], "chinese": "T恤衫", "grade": 2, "unit": "服饰穿搭", "example": "I wear a cool T-shirt in summer.", "gradeName": "二年级", "meaning": "T恤衫", "pos": "n."}, {"id": "gd_258", "word": "skirt", "phonetic": "/skɜːt/", "syllables": ["skirt"], "chinese": "半身裙", "grade": 2, "unit": "服饰穿搭", "example": "She wears a lovely floral skirt.", "gradeName": "二年级", "meaning": "半身裙", "pos": "n."}, {"id": "gd_259", "word": "dress", "phonetic": "/dres/", "syllables": ["dress"], "chinese": "连衣裙", "grade": 2, "unit": "服饰穿搭", "example": "The princess wore a golden dress.", "gradeName": "二年级", "meaning": "连衣裙", "pos": "n."}, {"id": "gd_260", "word": "coat", "phonetic": "/kəʊt/", "syllables": ["coat"], "chinese": "外套；大衣", "grade": 2, "unit": "服饰穿搭", "example": "Put on your warm coat.", "gradeName": "二年级", "meaning": "外套；大衣", "pos": "n."}, {"id": "gd_261", "word": "jacket", "phonetic": "/ˈdʒækɪt/", "syllables": ["jack", "et"], "chinese": "夹克衫", "grade": 2, "unit": "服饰穿搭", "example": "Zip up your denim jacket.", "gradeName": "二年级", "meaning": "夹克衫", "pos": "n."}, {"id": "gd_262", "word": "sweater", "phonetic": "/ˈswetə(r)/", "syllables": ["sweat", "er"], "chinese": "毛衣", "grade": 2, "unit": "服饰穿搭", "example": "Knitted sweater keeps you warm.", "gradeName": "二年级", "meaning": "毛衣", "pos": "n."}, {"id": "gd_263", "word": "pants", "phonetic": "/pænts/", "syllables": ["pants"], "chinese": "裤子", "grade": 2, "unit": "服饰穿搭", "example": "These blue pants fit well.", "gradeName": "二年级", "meaning": "裤子", "pos": "n."}, {"id": "gd_264", "word": "shorts", "phonetic": "/ʃɔːts/", "syllables": ["shorts"], "chinese": "短裤", "grade": 2, "unit": "服饰穿搭", "example": "Put on your sports shorts.", "gradeName": "二年级", "meaning": "短裤", "pos": "adj."}, {"id": "gd_265", "word": "jeans", "phonetic": "/dʒiːnz/", "syllables": ["jeans"], "chinese": "牛仔裤", "grade": 2, "unit": "服饰穿搭", "example": "Classic blue cotton jeans.", "gradeName": "二年级", "meaning": "牛仔裤", "pos": "n."}, {"id": "gd_266", "word": "shoes", "phonetic": "/ʃuːz/", "syllables": ["shoes"], "chinese": "鞋子", "grade": 2, "unit": "服饰穿搭", "example": "Tie the shoelaces on your shoes.", "gradeName": "二年级", "meaning": "鞋子", "pos": "n."}, {"id": "gd_267", "word": "socks", "phonetic": "/sɒks/", "syllables": ["socks"], "chinese": "袜子", "grade": 2, "unit": "服饰穿搭", "example": "Cotton socks protect your feet.", "gradeName": "二年级", "meaning": "袜子", "pos": "n."}, {"id": "gd_268", "word": "hat", "phonetic": "/hæt/", "syllables": ["hat"], "chinese": "帽子（有檐）", "grade": 2, "unit": "服饰穿搭", "example": "A straw hat shades the sun.", "gradeName": "二年级", "meaning": "帽子（有檐）", "pos": "n."}, {"id": "gd_269", "word": "cap", "phonetic": "/kæp/", "syllables": ["cap"], "chinese": "鸭舌帽", "grade": 2, "unit": "服饰穿搭", "example": "He wears a baseball cap.", "gradeName": "二年级", "meaning": "鸭舌帽", "pos": "n."}, {"id": "gd_270", "word": "boots", "phonetic": "/buːts/", "syllables": ["boots"], "chinese": "靴子", "grade": 2, "unit": "服饰穿搭", "example": "Rubber rain boots in puddles.", "gradeName": "二年级", "meaning": "靴子", "pos": "n."}, {"id": "gd_271", "word": "scarf", "phonetic": "/skɑːf/", "syllables": ["scarf"], "chinese": "围巾", "grade": 2, "unit": "服饰穿搭", "example": "Wrap a wool scarf in winter.", "gradeName": "二年级", "meaning": "围巾", "pos": "n."}, {"id": "gd_272", "word": "gloves", "phonetic": "/ɡlʌvz/", "syllables": ["gloves"], "chinese": "手套", "grade": 2, "unit": "服饰穿搭", "example": "Warm leather gloves.", "gradeName": "二年级", "meaning": "手套", "pos": "n."}, {"id": "gd_273", "word": "slippers", "phonetic": "/ˈslɪpəz/", "syllables": ["slip", "pers"], "chinese": "拖鞋", "grade": 3, "unit": "服饰穿搭", "example": "Soft indoor slippers.", "gradeName": "三年级", "meaning": "拖鞋", "pos": "v."}, {"id": "gd_274", "word": "sneakers", "phonetic": "/ˈsniːkəz/", "syllables": ["sneak", "ers"], "chinese": "运动鞋", "grade": 4, "unit": "服饰穿搭", "example": "Lace up your running sneakers.", "gradeName": "四年级", "meaning": "运动鞋", "pos": "n."}, {"id": "gd_275", "word": "uniform", "phonetic": "/ˈjuːnɪfɔːm/", "syllables": ["u", "ni", "form"], "chinese": "制服；校服", "grade": 4, "unit": "服饰穿搭", "example": "Proudly wear our school uniform.", "gradeName": "四年级", "meaning": "制服；校服", "pos": "n."}, {"id": "gd_276", "word": "tie", "phonetic": "/taɪ/", "syllables": ["tie"], "chinese": "领带；系", "grade": 4, "unit": "服饰穿搭", "example": "A neat silk necktie.", "gradeName": "四年级", "meaning": "领带；系", "pos": "n."}, {"id": "gd_277", "word": "belt", "phonetic": "/belt/", "syllables": ["belt"], "chinese": "皮带；腰带", "grade": 4, "unit": "服饰穿搭", "example": "Fasten your leather belt.", "gradeName": "四年级", "meaning": "皮带；腰带", "pos": "n."}, {"id": "gd_278", "word": "raincoat", "phonetic": "/ˈreɪnkəʊt/", "syllables": ["rain", "coat"], "chinese": "雨衣", "grade": 3, "unit": "服饰穿搭", "example": "Yellow waterproof raincoat.", "gradeName": "三年级", "meaning": "雨衣", "pos": "adj."}, {"id": "gd_279", "word": "umbrella", "phonetic": "/ʌmˈbrelə/", "syllables": ["um", "brel", "la"], "chinese": "雨伞", "grade": 3, "unit": "服饰穿搭", "example": "Carry an umbrella on rainy days.", "gradeName": "三年级", "meaning": "雨伞", "pos": "adj."}, {"id": "gd_280", "word": "glasses", "phonetic": "/ˈɡlɑːsɪz/", "syllables": ["glas", "ses"], "chinese": "眼镜", "grade": 3, "unit": "服饰穿搭", "example": "Read books with reading glasses.", "gradeName": "三年级", "meaning": "眼镜", "pos": "n."}, {"id": "gd_281", "word": "home", "phonetic": "/həʊm/", "syllables": ["home"], "chinese": "家；家庭", "grade": 1, "unit": "居家生活", "example": "East or west, home is best.", "gradeName": "一年级", "meaning": "家；家庭", "pos": "n."}, {"id": "gd_282", "word": "house", "phonetic": "/haʊs/", "syllables": ["house"], "chinese": "房屋；房子", "grade": 1, "unit": "居家生活", "example": "They built a lovely wooden house.", "gradeName": "一年级", "meaning": "房屋；房子", "pos": "n."}, {"id": "gd_283", "word": "room", "phonetic": "/ruːm/", "syllables": ["room"], "chinese": "房间", "grade": 2, "unit": "居家生活", "example": "Clean your bedroom.", "gradeName": "二年级", "meaning": "房间", "pos": "n."}, {"id": "gd_284", "word": "bedroom", "phonetic": "/ˈbedruːm/", "syllables": ["bed", "room"], "chinese": "卧室", "grade": 2, "unit": "居家生活", "example": "Go to sleep in the bedroom.", "gradeName": "二年级", "meaning": "卧室", "pos": "n."}, {"id": "gd_285", "word": "living-room", "phonetic": "/ˈlɪvɪŋ ruːm/", "syllables": ["liv", "ing", "room"], "chinese": "客厅", "grade": 2, "unit": "居家生活", "example": "We watch TV in the living-room.", "gradeName": "二年级", "meaning": "客厅", "pos": "n."}, {"id": "gd_286", "word": "kitchen", "phonetic": "/ˈkɪtʃɪn/", "syllables": ["kitch", "en"], "chinese": "厨房", "grade": 2, "unit": "居家生活", "example": "Dad is cooking in the kitchen.", "gradeName": "二年级", "meaning": "厨房", "pos": "n."}, {"id": "gd_287", "word": "bathroom", "phonetic": "/ˈbɑːθruːm/", "syllables": ["bath", "room"], "chinese": "浴室；卫生间", "grade": 2, "unit": "居家生活", "example": "Brush your teeth in the bathroom.", "gradeName": "二年级", "meaning": "浴室；卫生间", "pos": "n."}, {"id": "gd_288", "word": "study", "phonetic": "/ˈstʌdi/", "syllables": ["stud", "y"], "chinese": "书房；学习", "grade": 2, "unit": "居家生活", "example": "Quiet study filled with books.", "gradeName": "二年级", "meaning": "书房；学习", "pos": "n."}, {"id": "gd_289", "word": "balcony", "phonetic": "/ˈbælkəni/", "syllables": ["bal", "co", "ny"], "chinese": "阳台", "grade": 4, "unit": "居家生活", "example": "Potted flowers on the balcony.", "gradeName": "四年级", "meaning": "阳台", "pos": "n."}, {"id": "gd_290", "word": "garden", "phonetic": "/ˈɡɑːdn/", "syllables": ["gar", "den"], "chinese": "花园；院子", "grade": 2, "unit": "居家生活", "example": "Roses bloom in our garden.", "gradeName": "二年级", "meaning": "花园；院子", "pos": "n."}, {"id": "gd_291", "word": "bed", "phonetic": "/bed/", "syllables": ["bed"], "chinese": "床", "grade": 2, "unit": "居家生活", "example": "Make your bed every morning.", "gradeName": "二年级", "meaning": "床", "pos": "n."}, {"id": "gd_292", "word": "sofa", "phonetic": "/ˈsəʊfə/", "syllables": ["so", "fa"], "chinese": "沙发", "grade": 2, "unit": "居家生活", "example": "Sit on the soft sofa.", "gradeName": "二年级", "meaning": "沙发", "pos": "n."}, {"id": "gd_293", "word": "table", "phonetic": "/ˈteɪbl/", "syllables": ["ta", "ble"], "chinese": "桌子；餐桌", "grade": 2, "unit": "居家生活", "example": "Food is ready on table.", "gradeName": "二年级", "meaning": "桌子；餐桌", "pos": "n."}, {"id": "gd_294", "word": "window", "phonetic": "/ˈwɪndəʊ/", "syllables": ["win", "dow"], "chinese": "窗户", "grade": 2, "unit": "居家生活", "example": "Open the window for fresh air.", "gradeName": "二年级", "meaning": "窗户", "pos": "n."}, {"id": "gd_295", "word": "door", "phonetic": "/dɔː(r)/", "syllables": ["door"], "chinese": "门", "grade": 2, "unit": "居家生活", "example": "Knock at the door first.", "gradeName": "二年级", "meaning": "门", "pos": "n."}, {"id": "gd_296", "word": "wall", "phonetic": "/wɔːl/", "syllables": ["wall"], "chinese": "墙壁", "grade": 3, "unit": "居家生活", "example": "Paint the wall sky blue.", "gradeName": "三年级", "meaning": "墙壁", "pos": "n."}, {"id": "gd_297", "word": "floor", "phonetic": "/flɔː(r)/", "syllables": ["floor"], "chinese": "地板；楼层", "grade": 3, "unit": "居家生活", "example": "Sweep the dusty floor.", "gradeName": "三年级", "meaning": "地板；楼层", "pos": "n."}, {"id": "gd_298", "word": "light", "phonetic": "/laɪt/", "syllables": ["light"], "chinese": "电灯；光线", "grade": 2, "unit": "居家生活", "example": "Turn off the light when leaving.", "gradeName": "二年级", "meaning": "电灯；光线", "pos": "n."}, {"id": "gd_299", "word": "lamp", "phonetic": "/læmp/", "syllables": ["lamp"], "chinese": "台灯", "grade": 3, "unit": "居家生活", "example": "Turn on the reading desk lamp.", "gradeName": "三年级", "meaning": "台灯", "pos": "n."}, {"id": "gd_300", "word": "clock", "phonetic": "/klɒk/", "syllables": ["clock"], "chinese": "时钟", "grade": 2, "unit": "居家生活", "example": "The alarm clock rings.", "gradeName": "二年级", "meaning": "时钟", "pos": "n."}, {"id": "gd_301", "word": "phone", "phonetic": "/fəʊn/", "syllables": ["phone"], "chinese": "电话", "grade": 2, "unit": "居家生活", "example": "Answer the phone politely.", "gradeName": "二年级", "meaning": "电话", "pos": "n."}, {"id": "gd_302", "word": "fridge", "phonetic": "/frɪdʒ/", "syllables": ["fridge"], "chinese": "电冰箱", "grade": 3, "unit": "居家生活", "example": "Keep milk cold in the fridge.", "gradeName": "三年级", "meaning": "电冰箱", "pos": "n."}, {"id": "gd_303", "word": "shelf", "phonetic": "/ʃelf/", "syllables": ["shelf"], "chinese": "书架；隔板", "grade": 4, "unit": "居家生活", "example": "Books arranged on the shelf.", "gradeName": "四年级", "meaning": "书架；隔板", "pos": "n."}, {"id": "gd_304", "word": "box", "phonetic": "/bɒks/", "syllables": ["box"], "chinese": "盒子；箱子", "grade": 2, "unit": "居家生活", "example": "Open the magic gift box.", "gradeName": "二年级", "meaning": "盒子；箱子", "pos": "n."}, {"id": "gd_305", "word": "key", "phonetic": "/kiː/", "syllables": ["key"], "chinese": "钥匙；关键", "grade": 3, "unit": "居家生活", "example": "Keep your door key safe.", "gradeName": "三年级", "meaning": "钥匙；关键", "pos": "n."}, {"id": "gd_306", "word": "mirror", "phonetic": "/ˈmɪrə(r)/", "syllables": ["mir", "ror"], "chinese": "镜子", "grade": 4, "unit": "居家生活", "example": "Look in the mirror and smile.", "gradeName": "四年级", "meaning": "镜子", "pos": "n."}, {"id": "gd_307", "word": "fan", "phonetic": "/fæn/", "syllables": ["fan"], "chinese": "风扇；迷", "grade": 3, "unit": "居家生活", "example": "Electric fan cools the room.", "gradeName": "三年级", "meaning": "风扇；迷", "pos": "adj."}, {"id": "gd_308", "word": "curtain", "phonetic": "/ˈkɜːtn/", "syllables": ["cur", "tain"], "chinese": "窗帘", "grade": 4, "unit": "居家生活", "example": "Draw the curtains in evening.", "gradeName": "四年级", "meaning": "窗帘", "pos": "n."}, {"id": "gd_309", "word": "towel", "phonetic": "/ˈtaʊəl/", "syllables": ["tow", "el"], "chinese": "毛巾", "grade": 3, "unit": "居家生活", "example": "Dry your hands with a clean towel.", "gradeName": "三年级", "meaning": "毛巾", "pos": "n."}, {"id": "gd_310", "word": "soap", "phonetic": "/səʊp/", "syllables": ["soap"], "chinese": "肥皂", "grade": 3, "unit": "居家生活", "example": "Wash hands with scented soap.", "gradeName": "三年级", "meaning": "肥皂", "pos": "n."}, {"id": "gd_311", "word": "city", "phonetic": "/ˈsɪti/", "syllables": ["cit", "y"], "chinese": "城市", "grade": 3, "unit": "社会与交通", "example": "Beijing is a vibrant ancient city.", "gradeName": "三年级", "meaning": "城市", "pos": "n."}, {"id": "gd_312", "word": "town", "phonetic": "/taʊn/", "syllables": ["town"], "chinese": "小镇；城镇", "grade": 3, "unit": "社会与交通", "example": "A peaceful seaside town.", "gradeName": "三年级", "meaning": "小镇；城镇", "pos": "adj."}, {"id": "gd_313", "word": "village", "phonetic": "/ˈvɪlɪdʒ/", "syllables": ["vil", "lage"], "chinese": "村庄；乡村", "grade": 3, "unit": "社会与交通", "example": "Green fields surround the village.", "gradeName": "三年级", "meaning": "村庄；乡村", "pos": "n."}, {"id": "gd_314", "word": "street", "phonetic": "/striːt/", "syllables": ["street"], "chinese": "街道", "grade": 3, "unit": "社会与交通", "example": "Cross the street with care.", "gradeName": "三年级", "meaning": "街道", "pos": "n."}, {"id": "gd_315", "word": "road", "phonetic": "/rəʊd/", "syllables": ["road"], "chinese": "道路；马路", "grade": 3, "unit": "社会与交通", "example": "A winding mountain road.", "gradeName": "三年级", "meaning": "道路；马路", "pos": "n."}, {"id": "gd_316", "word": "park", "phonetic": "/pɑːk/", "syllables": ["park"], "chinese": "公园", "grade": 2, "unit": "社会与交通", "example": "We had a picnic in the park.", "gradeName": "二年级", "meaning": "公园", "pos": "n."}, {"id": "gd_317", "word": "zoo", "phonetic": "/zuː/", "syllables": ["zoo"], "chinese": "动物园", "grade": 1, "unit": "社会与交通", "example": "Let's visit the animals in the zoo.", "gradeName": "一年级", "meaning": "动物园", "pos": "n."}, {"id": "gd_318", "word": "farm", "phonetic": "/fɑːm/", "syllables": ["farm"], "chinese": "农场", "grade": 2, "unit": "社会与交通", "example": "Old MacDonald had a farm.", "gradeName": "二年级", "meaning": "农场", "pos": "n."}, {"id": "gd_319", "word": "shop", "phonetic": "/ʃɒp/", "syllables": ["shop"], "chinese": "商店", "grade": 2, "unit": "社会与交通", "example": "Buy fresh pencils at the shop.", "gradeName": "二年级", "meaning": "商店", "pos": "n."}, {"id": "gd_320", "word": "store", "phonetic": "/stɔː(r)/", "syllables": ["store"], "chinese": "百货商店", "grade": 3, "unit": "社会与交通", "example": "Convenience store on corner.", "gradeName": "三年级", "meaning": "百货商店", "pos": "n."}, {"id": "gd_321", "word": "supermarket", "phonetic": "/ˈsuːpəmɑːkɪt/", "syllables": ["su", "per", "mar", "ket"], "chinese": "超市", "grade": 2, "unit": "社会与交通", "example": "Fruits and milk in supermarket.", "gradeName": "二年级", "meaning": "超市", "pos": "n."}, {"id": "gd_322", "word": "hospital", "phonetic": "/ˈhɒspɪtl/", "syllables": ["hos", "pi", "tal"], "chinese": "医院", "grade": 2, "unit": "社会与交通", "example": "The doctor heals sick kids in hospital.", "gradeName": "二年级", "meaning": "医院", "pos": "n."}, {"id": "gd_323", "word": "cinema", "phonetic": "/ˈsɪnəmə/", "syllables": ["cin", "e", "ma"], "chinese": "电影院", "grade": 2, "unit": "社会与交通", "example": "Watch an animated film at cinema.", "gradeName": "二年级", "meaning": "电影院", "pos": "n."}, {"id": "gd_324", "word": "bank", "phonetic": "/bæŋk/", "syllables": ["bank"], "chinese": "银行", "grade": 3, "unit": "社会与交通", "example": "Save coins in the bank.", "gradeName": "三年级", "meaning": "银行", "pos": "n."}, {"id": "gd_325", "word": "hotel", "phonetic": "/həʊˈtel/", "syllables": ["ho", "tel"], "chinese": "宾馆；酒店", "grade": 4, "unit": "社会与交通", "example": "Stay at a comfortable hotel.", "gradeName": "四年级", "meaning": "宾馆；酒店", "pos": "n."}, {"id": "gd_326", "word": "post office", "phonetic": "/ˈpəʊst ɒfɪs/", "syllables": ["post", "of", "fice"], "chinese": "邮局", "grade": 3, "unit": "社会与交通", "example": "Mail a letter at post office.", "gradeName": "三年级", "meaning": "邮局", "pos": "n."}, {"id": "gd_327", "word": "museum", "phonetic": "/mjuˈziːəm/", "syllables": ["mu", "se", "um"], "chinese": "博物馆", "grade": 4, "unit": "社会与交通", "example": "Learn history at national museum.", "gradeName": "四年级", "meaning": "博物馆", "pos": "n."}, {"id": "gd_328", "word": "airport", "phonetic": "/ˈeəpɔːt/", "syllables": ["air", "port"], "chinese": "机场", "grade": 4, "unit": "社会与交通", "example": "Planes take off at the airport.", "gradeName": "四年级", "meaning": "机场", "pos": "adj."}, {"id": "gd_329", "word": "station", "phonetic": "/ˈsteɪʃn/", "syllables": ["sta", "tion"], "chinese": "车站", "grade": 3, "unit": "社会与交通", "example": "Meet friends at the train station.", "gradeName": "三年级", "meaning": "车站", "pos": "n."}, {"id": "gd_330", "word": "bus stop", "phonetic": "/bʌs stɒp/", "syllables": ["bus", "stop"], "chinese": "公交车站", "grade": 2, "unit": "社会与交通", "example": "Wait patiently at the bus stop.", "gradeName": "二年级", "meaning": "公交车站", "pos": "n."}, {"id": "gd_331", "word": "car", "phonetic": "/kɑː(r)/", "syllables": ["car"], "chinese": "小汽车", "grade": 1, "unit": "社会与交通", "example": "The toy car runs fast.", "gradeName": "一年级", "meaning": "小汽车", "pos": "adj."}, {"id": "gd_332", "word": "bus", "phonetic": "/bʌs/", "syllables": ["bus"], "chinese": "公共汽车", "grade": 1, "unit": "社会与交通", "example": "Take the number ten bus.", "gradeName": "一年级", "meaning": "公共汽车", "pos": "n."}, {"id": "gd_333", "word": "bike", "phonetic": "/baɪk/", "syllables": ["bike"], "chinese": "自行车", "grade": 1, "unit": "社会与交通", "example": "Ride a bike to school.", "gradeName": "一年级", "meaning": "自行车", "pos": "adj."}, {"id": "gd_334", "word": "bicycle", "phonetic": "/ˈbaɪsɪkl/", "syllables": ["bi", "cy", "cle"], "chinese": "自行车", "grade": 2, "unit": "社会与交通", "example": "Wear a helmet when riding a bicycle.", "gradeName": "二年级", "meaning": "自行车", "pos": "adj."}, {"id": "gd_335", "word": "train", "phonetic": "/treɪn/", "syllables": ["train"], "chinese": "火车", "grade": 2, "unit": "社会与交通", "example": "Hear the train whistle loudly.", "gradeName": "二年级", "meaning": "火车", "pos": "n."}, {"id": "gd_336", "word": "plane", "phonetic": "/pleɪn/", "syllables": ["plane"], "chinese": "飞机", "grade": 2, "unit": "社会与交通", "example": "The plane flies through clouds.", "gradeName": "二年级", "meaning": "飞机", "pos": "v."}, {"id": "gd_337", "word": "airplane", "phonetic": "/ˈeəpleɪn/", "syllables": ["air", "plane"], "chinese": "飞机", "grade": 3, "unit": "社会与交通", "example": "Look at the silver airplane.", "gradeName": "三年级", "meaning": "飞机", "pos": "v."}, {"id": "gd_338", "word": "boat", "phonetic": "/bəʊt/", "syllables": ["boat"], "chinese": "小船", "grade": 2, "unit": "社会与交通", "example": "Row your boat gently.", "gradeName": "二年级", "meaning": "小船", "pos": "adj."}, {"id": "gd_339", "word": "ship", "phonetic": "/ʃɪp/", "syllables": ["ship"], "chinese": "轮船；大船", "grade": 2, "unit": "社会与交通", "example": "A huge ship sails on ocean.", "gradeName": "二年级", "meaning": "轮船；大船", "pos": "n."}, {"id": "gd_340", "word": "subway", "phonetic": "/ˈsʌbweɪ/", "syllables": ["sub", "way"], "chinese": "地铁", "grade": 4, "unit": "社会与交通", "example": "Subway trains are fast and green.", "gradeName": "四年级", "meaning": "地铁", "pos": "n."}, {"id": "gd_341", "word": "taxi", "phonetic": "/ˈtæksi/", "syllables": ["tax", "i"], "chinese": "出租车", "grade": 3, "unit": "社会与交通", "example": "Hail a taxi at terminal.", "gradeName": "三年级", "meaning": "出租车", "pos": "n."}, {"id": "gd_342", "word": "truck", "phonetic": "/trʌk/", "syllables": ["truck"], "chinese": "卡车", "grade": 3, "unit": "社会与交通", "example": "Heavy truck carries cargo.", "gradeName": "三年级", "meaning": "卡车", "pos": "n."}, {"id": "gd_343", "word": "van", "phonetic": "/væn/", "syllables": ["van"], "chinese": "面包车；厢式货车", "grade": 3, "unit": "社会与交通", "example": "Delivery van drives by.", "gradeName": "三年级", "meaning": "面包车；厢式货车", "pos": "n."}, {"id": "gd_344", "word": "stop", "phonetic": "/stɒp/", "syllables": ["stop"], "chinese": "停止；站牌", "grade": 2, "unit": "社会与交通", "example": "Stop at red traffic light.", "gradeName": "二年级", "meaning": "停止；站牌", "pos": "n."}, {"id": "gd_345", "word": "traffic", "phonetic": "/ˈtræfɪk/", "syllables": ["traf", "fic"], "chinese": "交通；车流", "grade": 4, "unit": "社会与交通", "example": "Heavy traffic on bridge.", "gradeName": "四年级", "meaning": "交通；车流", "pos": "n."}, {"id": "gd_346", "word": "country", "phonetic": "/ˈkʌntri/", "syllables": ["coun", "try"], "chinese": "国家；乡村", "grade": 4, "unit": "社会与交通", "example": "I love my motherland country.", "gradeName": "四年级", "meaning": "国家；乡村", "pos": "n."}, {"id": "gd_347", "word": "China", "phonetic": "/ˈtʃaɪnə/", "syllables": ["Chi", "na"], "chinese": "中国", "grade": 2, "unit": "社会与交通", "example": "China has a long history.", "gradeName": "二年级", "meaning": "中国", "pos": "n."}, {"id": "gd_348", "word": "Canada", "phonetic": "/ˈkænədə/", "syllables": ["Can", "a", "da"], "chinese": "加拿大", "grade": 3, "unit": "社会与交通", "example": "Maple leaves in Canada.", "gradeName": "三年级", "meaning": "加拿大", "pos": "n."}, {"id": "gd_349", "word": "America", "phonetic": "/əˈmerɪkə/", "syllables": ["A", "mer", "i", "ca"], "chinese": "美国", "grade": 3, "unit": "社会与交通", "example": "Bald eagle represents America.", "gradeName": "三年级", "meaning": "美国", "pos": "adj."}, {"id": "gd_350", "word": "UK", "phonetic": "/ˌjuː ˈkeɪ/", "syllables": ["U", "K"], "chinese": "英国", "grade": 3, "unit": "社会与交通", "example": "Big Ben in UK.", "gradeName": "三年级", "meaning": "英国", "pos": "n."}, {"id": "gd_351", "word": "world", "phonetic": "/wɜːld/", "syllables": ["world"], "chinese": "世界", "grade": 4, "unit": "社会与交通", "example": "Explore the wonderful world.", "gradeName": "四年级", "meaning": "世界", "pos": "n."}, {"id": "gd_352", "word": "bridge", "phonetic": "/brɪdʒ/", "syllables": ["bridge"], "chinese": "桥梁", "grade": 4, "unit": "社会与交通", "example": "Cross the river via bridge.", "gradeName": "四年级", "meaning": "桥梁", "pos": "n."}, {"id": "gd_353", "word": "corner", "phonetic": "/ˈkɔːnə(r)/", "syllables": ["cor", "ner"], "chinese": "拐角；角落", "grade": 4, "unit": "社会与交通", "example": "Turn right at the corner.", "gradeName": "四年级", "meaning": "拐角；角落", "pos": "n."}, {"id": "gd_354", "word": "doctor", "phonetic": "/ˈdɒktə(r)/", "syllables": ["doc", "tor"], "chinese": "医生", "grade": 3, "unit": "职业理想", "example": "The gentle doctor helps sick people.", "gradeName": "三年级", "meaning": "医生", "pos": "n."}, {"id": "gd_355", "word": "nurse", "phonetic": "/nɜːs/", "syllables": ["nurse"], "chinese": "护士", "grade": 3, "unit": "职业理想", "example": "Nurses care for hospital patients.", "gradeName": "三年级", "meaning": "护士", "pos": "n."}, {"id": "gd_356", "word": "farmer", "phonetic": "/ˈfɑːmə(r)/", "syllables": ["farm", "er"], "chinese": "农民", "grade": 3, "unit": "职业理想", "example": "The farmer grows golden wheat.", "gradeName": "三年级", "meaning": "农民", "pos": "n."}, {"id": "gd_357", "word": "driver", "phonetic": "/ˈdraɪvə(r)/", "syllables": ["dri", "ver"], "chinese": "司机", "grade": 3, "unit": "职业理想", "example": "The careful bus driver stops on time.", "gradeName": "三年级", "meaning": "司机", "pos": "n."}, {"id": "gd_358", "word": "cook", "phonetic": "/kʊk/", "syllables": ["cook"], "chinese": "厨师；烹调", "grade": 3, "unit": "职业理想", "example": "The master cook prepares tasty food.", "gradeName": "三年级", "meaning": "厨师；烹调", "pos": "n."}, {"id": "gd_359", "word": "worker", "phonetic": "/ˈwɜːkə(r)/", "syllables": ["work", "er"], "chinese": "工人", "grade": 3, "unit": "职业理想", "example": "Factory workers make tools.", "gradeName": "三年级", "meaning": "工人", "pos": "n."}, {"id": "gd_360", "word": "policeman", "phonetic": "/pəˈliːsmən/", "syllables": ["po", "lice", "man"], "chinese": "男警察", "grade": 3, "unit": "职业理想", "example": "The policeman directs busy traffic.", "gradeName": "三年级", "meaning": "男警察", "pos": "n."}, {"id": "gd_361", "word": "policewoman", "phonetic": "/pəˈliːswʊmən/", "syllables": ["po", "lice", "wom", "an"], "chinese": "女警察", "grade": 3, "unit": "职业理想", "example": "Brave policewoman on duty.", "gradeName": "三年级", "meaning": "女警察", "pos": "n."}, {"id": "gd_362", "word": "postman", "phonetic": "/ˈpəʊstmən/", "syllables": ["post", "man"], "chinese": "邮递员", "grade": 3, "unit": "职业理想", "example": "The postman delivers fresh letters.", "gradeName": "三年级", "meaning": "邮递员", "pos": "n."}, {"id": "gd_363", "word": "firefighter", "phonetic": "/ˈfaɪəfaɪtə(r)/", "syllables": ["fire", "fight", "er"], "chinese": "消防员", "grade": 4, "unit": "职业理想", "example": "Brave firefighters put out blaze.", "gradeName": "四年级", "meaning": "消防员", "pos": "n."}, {"id": "gd_364", "word": "pilot", "phonetic": "/ˈpaɪlət/", "syllables": ["pi", "lot"], "chinese": "飞行员", "grade": 5, "unit": "职业理想", "example": "The brave pilot guides the airplane.", "gradeName": "五年级", "meaning": "飞行员", "pos": "v."}, {"id": "gd_365", "word": "astronaut", "phonetic": "/ˈæstrənɔːt/", "syllables": ["as", "tro", "naut"], "chinese": "航天员；宇航员", "grade": 6, "unit": "职业理想", "example": "Astronauts step into outer space.", "gradeName": "六年级", "meaning": "航天员；宇航员", "pos": "n."}, {"id": "gd_366", "word": "scientist", "phonetic": "/ˈsaɪəntɪst/", "syllables": ["sci", "en", "tist"], "chinese": "科学家", "grade": 6, "unit": "职业理想", "example": "Tu Youyou is a celebrated scientist.", "gradeName": "六年级", "meaning": "科学家", "pos": "n."}, {"id": "gd_367", "word": "engineer", "phonetic": "/ˌendʒɪˈnɪə(r)/", "syllables": ["en", "gi", "neer"], "chinese": "工程师", "grade": 6, "unit": "职业理想", "example": "The engineer built a long bridge.", "gradeName": "六年级", "meaning": "工程师", "pos": "n."}, {"id": "gd_368", "word": "artist", "phonetic": "/ˈɑːtɪst/", "syllables": ["ar", "tist"], "chinese": "艺术家；画家", "grade": 5, "unit": "职业理想", "example": "The artist captured the sunset glow.", "gradeName": "五年级", "meaning": "艺术家；画家", "pos": "n."}, {"id": "gd_369", "word": "singer", "phonetic": "/ˈsɪŋə(r)/", "syllables": ["sing", "er"], "chinese": "歌手", "grade": 4, "unit": "职业理想", "example": "The famous singer touches hearts.", "gradeName": "四年级", "meaning": "歌手", "pos": "n."}, {"id": "gd_370", "word": "dancer", "phonetic": "/ˈdɑːnsə(r)/", "syllables": ["dan", "cer"], "chinese": "舞蹈演员", "grade": 4, "unit": "职业理想", "example": "The dancer leaps like a swan.", "gradeName": "四年级", "meaning": "舞蹈演员", "pos": "n."}, {"id": "gd_371", "word": "musician", "phonetic": "/mjuˈzɪʃn/", "syllables": ["mu", "si", "cian"], "chinese": "音乐家", "grade": 6, "unit": "职业理想", "example": "Mozart was a gifted musician.", "gradeName": "六年级", "meaning": "音乐家", "pos": "n."}, {"id": "gd_372", "word": "writer", "phonetic": "/ˈraɪtə(r)/", "syllables": ["wri", "ter"], "chinese": "作家", "grade": 5, "unit": "职业理想", "example": "The writer publishes a bestseller.", "gradeName": "五年级", "meaning": "作家", "pos": "n."}, {"id": "gd_373", "word": "player", "phonetic": "/ˈpleɪə(r)/", "syllables": ["play", "er"], "chinese": "运动员；选手", "grade": 4, "unit": "职业理想", "example": "Basketball player shoots a hoop.", "gradeName": "四年级", "meaning": "运动员；选手", "pos": "n."}, {"id": "gd_374", "word": "coach", "phonetic": "/kəʊtʃ/", "syllables": ["coach"], "chinese": "教练", "grade": 5, "unit": "职业理想", "example": "The coach trains track team.", "gradeName": "五年级", "meaning": "教练", "pos": "v."}, {"id": "gd_375", "word": "cleaner", "phonetic": "/ˈkliːnə(r)/", "syllables": ["clean", "er"], "chinese": "保洁员", "grade": 4, "unit": "职业理想", "example": "Cleaners keep avenues tidy.", "gradeName": "四年级", "meaning": "保洁员", "pos": "n."}, {"id": "gd_376", "word": "job", "phonetic": "/dʒɒb/", "syllables": ["job"], "chinese": "职业；工作", "grade": 3, "unit": "职业理想", "example": "Find a rewarding dream job.", "gradeName": "三年级", "meaning": "职业；工作", "pos": "n."}, {"id": "gd_377", "word": "work", "phonetic": "/wɜːk/", "syllables": ["work"], "chinese": "工作；劳动", "grade": 3, "unit": "职业理想", "example": "Hard work brings fruitful success.", "gradeName": "三年级", "meaning": "工作；劳动", "pos": "n."}, {"id": "gd_378", "word": "spring", "phonetic": "/sprɪŋ/", "syllables": ["spring"], "chinese": "春天；春季", "grade": 4, "unit": "自然与时节", "example": "In spring, green leaves sprout.", "gradeName": "四年级", "meaning": "春天；春季", "pos": "n."}, {"id": "gd_379", "word": "summer", "phonetic": "/ˈsʌmə(r)/", "syllables": ["sum", "mer"], "chinese": "夏天；夏季", "grade": 4, "unit": "自然与时节", "example": "In summer, cicadas sing loudly.", "gradeName": "四年级", "meaning": "夏天；夏季", "pos": "n."}, {"id": "gd_380", "word": "autumn", "phonetic": "/ˈɔːtəm/", "syllables": ["au", "tumn"], "chinese": "秋天；秋季", "grade": 4, "unit": "自然与时节", "example": "Golden leaves drop in autumn.", "gradeName": "四年级", "meaning": "秋天；秋季", "pos": "n."}, {"id": "gd_381", "word": "winter", "phonetic": "/ˈwɪntə(r)/", "syllables": ["win", "ter"], "chinese": "冬天；冬季", "grade": 4, "unit": "自然与时节", "example": "Snow covers mountains in winter.", "gradeName": "四年级", "meaning": "冬天；冬季", "pos": "n."}, {"id": "gd_382", "word": "season", "phonetic": "/ˈsiːzn/", "syllables": ["sea", "son"], "chinese": "季节", "grade": 4, "unit": "自然与时节", "example": "There are four distinct seasons.", "gradeName": "四年级", "meaning": "季节", "pos": "n."}, {"id": "gd_383", "word": "sun", "phonetic": "/sʌn/", "syllables": ["sun"], "chinese": "太阳", "grade": 1, "unit": "自然与时节", "example": "The sun rises in the east.", "gradeName": "一年级", "meaning": "太阳", "pos": "n."}, {"id": "gd_384", "word": "moon", "phonetic": "/muːn/", "syllables": ["moon"], "chinese": "月亮", "grade": 4, "unit": "自然与时节", "example": "The full moon shines brightly.", "gradeName": "四年级", "meaning": "月亮", "pos": "n."}, {"id": "gd_385", "word": "star", "phonetic": "/stɑː(r)/", "syllables": ["star"], "chinese": "星星；恒星", "grade": 4, "unit": "自然与时节", "example": "Count sparkling stars in evening.", "gradeName": "四年级", "meaning": "星星；恒星", "pos": "n."}, {"id": "gd_386", "word": "sky", "phonetic": "/skaɪ/", "syllables": ["sky"], "chinese": "天空", "grade": 4, "unit": "自然与时节", "example": "Kites soar into high sky.", "gradeName": "四年级", "meaning": "天空", "pos": "n."}, {"id": "gd_387", "word": "cloud", "phonetic": "/klaʊd/", "syllables": ["cloud"], "chinese": "云朵", "grade": 3, "unit": "自然与时节", "example": "White clouds drift across blue sky.", "gradeName": "三年级", "meaning": "云朵", "pos": "n."}, {"id": "gd_388", "word": "rain", "phonetic": "/reɪn/", "syllables": ["rain"], "chinese": "雨；下雨", "grade": 3, "unit": "自然与时节", "example": "April showers bring May flowers.", "gradeName": "三年级", "meaning": "雨；下雨", "pos": "adj."}, {"id": "gd_389", "word": "snow", "phonetic": "/snəʊ/", "syllables": ["snow"], "chinese": "雪；下雪", "grade": 3, "unit": "自然与时节", "example": "Pure white snow falls quietly.", "gradeName": "三年级", "meaning": "雪；下雪", "pos": "adj."}, {"id": "gd_390", "word": "wind", "phonetic": "/wɪnd/", "syllables": ["wind"], "chinese": "风", "grade": 3, "unit": "自然与时节", "example": "The north wind blows chilly.", "gradeName": "三年级", "meaning": "风", "pos": "adj."}, {"id": "gd_391", "word": "rainbow", "phonetic": "/ˈreɪnbəʊ/", "syllables": ["rain", "bow"], "chinese": "彩虹", "grade": 3, "unit": "自然与时节", "example": "A bright rainbow appears after rain.", "gradeName": "三年级", "meaning": "彩虹", "pos": "n."}, {"id": "gd_392", "word": "tree", "phonetic": "/triː/", "syllables": ["tree"], "chinese": "树木", "grade": 4, "unit": "自然与时节", "example": "Birds nest on tall oak tree.", "gradeName": "四年级", "meaning": "树木", "pos": "n."}, {"id": "gd_393", "word": "flower", "phonetic": "/ˈflaʊə(r)/", "syllables": ["flow", "er"], "chinese": "花朵", "grade": 4, "unit": "自然与时节", "example": "The jasmine flower smells sweet.", "gradeName": "四年级", "meaning": "花朵", "pos": "n."}, {"id": "gd_394", "word": "grass", "phonetic": "/ɡrɑːs/", "syllables": ["grass"], "chinese": "草坪；青草", "grade": 4, "unit": "自然与时节", "example": "Do not step on green grass.", "gradeName": "四年级", "meaning": "草坪；青草", "pos": "n."}, {"id": "gd_395", "word": "leaf", "phonetic": "/liːf/", "syllables": ["leaf"], "chinese": "树叶（单数）", "grade": 4, "unit": "自然与时节", "example": "A maple leaf falls gently.", "gradeName": "四年级", "meaning": "树叶（单数）", "pos": "n."}, {"id": "gd_396", "word": "leaves", "phonetic": "/liːvz/", "syllables": ["leaves"], "chinese": "树叶（复数）", "grade": 4, "unit": "自然与时节", "example": "Golden leaves flutter down.", "gradeName": "四年级", "meaning": "树叶（复数）", "pos": "n."}, {"id": "gd_397", "word": "river", "phonetic": "/ˈrɪvə(r)/", "syllables": ["riv", "er"], "chinese": "河流", "grade": 4, "unit": "自然与时节", "example": "Boats float down the wide river.", "gradeName": "四年级", "meaning": "河流", "pos": "n."}, {"id": "gd_398", "word": "lake", "phonetic": "/leɪk/", "syllables": ["lake"], "chinese": "湖泊", "grade": 4, "unit": "自然与时节", "example": "The lake is smooth as glass.", "gradeName": "四年级", "meaning": "湖泊", "pos": "n."}, {"id": "gd_399", "word": "sea", "phonetic": "/siː/", "syllables": ["sea"], "chinese": "海洋；大海", "grade": 4, "unit": "自然与时节", "example": "Waves crash against the blue sea.", "gradeName": "四年级", "meaning": "海洋；大海", "pos": "n."}, {"id": "gd_400", "word": "ocean", "phonetic": "/ˈəʊʃn/", "syllables": ["o", "cean"], "chinese": "大洋；大洋洲", "grade": 5, "unit": "自然与时节", "example": "Pacific Ocean is enormous.", "gradeName": "五年级", "meaning": "大洋；大洋洲", "pos": "adj."}, {"id": "gd_401", "word": "mountain", "phonetic": "/ˈmaʊntən/", "syllables": ["moun", "tain"], "chinese": "高山；山峰", "grade": 4, "unit": "自然与时节", "example": "Climb to the top of the mountain.", "gradeName": "四年级", "meaning": "高山；山峰", "pos": "adj."}, {"id": "gd_402", "word": "hill", "phonetic": "/hɪl/", "syllables": ["hill"], "chinese": "小山；丘陵", "grade": 4, "unit": "自然与时节", "example": "Sheep graze on the green hill.", "gradeName": "四年级", "meaning": "小山；丘陵", "pos": "adj."}, {"id": "gd_403", "word": "forest", "phonetic": "/ˈfɒrɪst/", "syllables": ["for", "est"], "chinese": "森林", "grade": 4, "unit": "自然与时节", "example": "Deer live in lush forest.", "gradeName": "四年级", "meaning": "森林", "pos": "n."}, {"id": "gd_404", "word": "earth", "phonetic": "/ɜːθ/", "syllables": ["earth"], "chinese": "地球；大地", "grade": 5, "unit": "自然与时节", "example": "Protect our shared mother Earth.", "gradeName": "五年级", "meaning": "地球；大地", "pos": "n."}, {"id": "gd_405", "word": "weather", "phonetic": "/ˈweðə(r)/", "syllables": ["weath", "er"], "chinese": "天气", "grade": 3, "unit": "自然与时节", "example": "What is the weather like?", "gradeName": "三年级", "meaning": "天气", "pos": "n."}, {"id": "gd_406", "word": "sunny", "phonetic": "/ˈsʌni/", "syllables": ["sun", "ny"], "chinese": "晴朗的", "grade": 3, "unit": "自然与时节", "example": "It is a sunny Sunday.", "gradeName": "三年级", "meaning": "晴朗的", "pos": "adj."}, {"id": "gd_407", "word": "rainy", "phonetic": "/ˈreɪni/", "syllables": ["rain", "y"], "chinese": "下雨的", "grade": 3, "unit": "自然与时节", "example": "Take an umbrella on rainy days.", "gradeName": "三年级", "meaning": "下雨的", "pos": "n."}, {"id": "gd_408", "word": "windy", "phonetic": "/ˈwɪndi/", "syllables": ["wind", "y"], "chinese": "刮风的", "grade": 3, "unit": "自然与时节", "example": "Fly a kite on a windy afternoon.", "gradeName": "三年级", "meaning": "刮风的", "pos": "n."}, {"id": "gd_409", "word": "cloudy", "phonetic": "/ˈklaʊdi/", "syllables": ["cloud", "y"], "chinese": "多云的", "grade": 3, "unit": "自然与时节", "example": "The sky is overcast and cloudy.", "gradeName": "三年级", "meaning": "多云的", "pos": "adj."}, {"id": "gd_410", "word": "snowy", "phonetic": "/ˈsnəʊi/", "syllables": ["snow", "y"], "chinese": "下雪的", "grade": 3, "unit": "自然与时节", "example": "Build a snowman on snowy days.", "gradeName": "三年级", "meaning": "下雪的", "pos": "n."}, {"id": "gd_411", "word": "warm", "phonetic": "/wɔːm/", "syllables": ["warm"], "chinese": "温暖的", "grade": 3, "unit": "自然与时节", "example": "Spring days are sunny and warm.", "gradeName": "三年级", "meaning": "温暖的", "pos": "n."}, {"id": "gd_412", "word": "hot", "phonetic": "/hɒt/", "syllables": ["hot"], "chinese": "炎热的", "grade": 3, "unit": "自然与时节", "example": "Summer afternoons are very hot.", "gradeName": "三年级", "meaning": "炎热的", "pos": "n."}, {"id": "gd_413", "word": "cool", "phonetic": "/kuːl/", "syllables": ["cool"], "chinese": "凉爽的", "grade": 3, "unit": "自然与时节", "example": "Autumn breeze is nice and cool.", "gradeName": "三年级", "meaning": "凉爽的", "pos": "adj."}, {"id": "gd_414", "word": "today", "phonetic": "/təˈdeɪ/", "syllables": ["to", "day"], "chinese": "今天", "grade": 3, "unit": "时间日历", "example": "Today is full of new hope.", "gradeName": "三年级", "meaning": "今天", "pos": "n."}, {"id": "gd_415", "word": "tomorrow", "phonetic": "/təˈmɒrəʊ/", "syllables": ["to", "mor", "row"], "chinese": "明天", "grade": 3, "unit": "时间日历", "example": "Tomorrow will be brighter.", "gradeName": "三年级", "meaning": "明天", "pos": "n."}, {"id": "gd_416", "word": "yesterday", "phonetic": "/ˈjestədeɪ/", "syllables": ["yes", "ter", "day"], "chinese": "昨天", "grade": 3, "unit": "时间日历", "example": "Yesterday all my troubles seemed away.", "gradeName": "三年级", "meaning": "昨天", "pos": "n."}, {"id": "gd_417", "word": "day", "phonetic": "/deɪ/", "syllables": ["day"], "chinese": "天；白天", "grade": 3, "unit": "时间日历", "example": "Have a wonderful day!", "gradeName": "三年级", "meaning": "天；白天", "pos": "n."}, {"id": "gd_418", "word": "week", "phonetic": "/wiːk/", "syllables": ["week"], "chinese": "星期；周", "grade": 3, "unit": "时间日历", "example": "Seven days in a week.", "gradeName": "三年级", "meaning": "星期；周", "pos": "n."}, {"id": "gd_419", "word": "month", "phonetic": "/mʌnθ/", "syllables": ["month"], "chinese": "月份", "grade": 5, "unit": "时间日历", "example": "Twelve months in one year.", "gradeName": "五年级", "meaning": "月份", "pos": "n."}, {"id": "gd_420", "word": "year", "phonetic": "/jɪə(r)/", "syllables": ["year"], "chinese": "年；年度", "grade": 5, "unit": "时间日历", "example": "Wish you a prosperous year.", "gradeName": "五年级", "meaning": "年；年度", "pos": "adj."}, {"id": "gd_421", "word": "time", "phonetic": "/taɪm/", "syllables": ["time"], "chinese": "时间", "grade": 3, "unit": "时间日历", "example": "Time flies like an arrow.", "gradeName": "三年级", "meaning": "时间", "pos": "n."}, {"id": "gd_422", "word": "o'clock", "phonetic": "/əˈklɒk/", "syllables": ["o", "clock"], "chinese": "……点钟", "grade": 3, "unit": "时间日历", "example": "Class begins at eight o'clock.", "gradeName": "三年级", "meaning": "……点钟", "pos": "n."}, {"id": "gd_423", "word": "hour", "phonetic": "/ˈaʊə(r)/", "syllables": ["hour"], "chinese": "小时", "grade": 4, "unit": "时间日历", "example": "Sixty minutes in an hour.", "gradeName": "四年级", "meaning": "小时", "pos": "adj."}, {"id": "gd_424", "word": "minute", "phonetic": "/ˈmɪnɪt/", "syllables": ["min", "ute"], "chinese": "分钟", "grade": 4, "unit": "时间日历", "example": "Wait for just one minute.", "gradeName": "四年级", "meaning": "分钟", "pos": "n."}, {"id": "gd_425", "word": "Monday", "phonetic": "/ˈmʌndeɪ/", "syllables": ["Mon", "day"], "chinese": "星期一", "grade": 3, "unit": "时间日历", "example": "School starts on Monday.", "gradeName": "三年级", "meaning": "星期一", "pos": "n."}, {"id": "gd_426", "word": "Tuesday", "phonetic": "/ˈtjuːzdeɪ/", "syllables": ["Tues", "day"], "chinese": "星期二", "grade": 3, "unit": "时间日历", "example": "We have English on Tuesday.", "gradeName": "三年级", "meaning": "星期二", "pos": "n."}, {"id": "gd_427", "word": "Wednesday", "phonetic": "/ˈwenzdeɪ/", "syllables": ["Wednes", "day"], "chinese": "星期三", "grade": 3, "unit": "时间日历", "example": "Wednesday is middle of week.", "gradeName": "三年级", "meaning": "星期三", "pos": "n."}, {"id": "gd_428", "word": "Thursday", "phonetic": "/ˈθɜːzdeɪ/", "syllables": ["Thurs", "day"], "chinese": "星期四", "grade": 3, "unit": "时间日历", "example": "Math test is on Thursday.", "gradeName": "三年级", "meaning": "星期四", "pos": "n."}, {"id": "gd_429", "word": "Friday", "phonetic": "/ˈfraɪdeɪ/", "syllables": ["Fri", "day"], "chinese": "星期五", "grade": 3, "unit": "时间日历", "example": "Friday evening is relaxing.", "gradeName": "三年级", "meaning": "星期五", "pos": "n."}, {"id": "gd_430", "word": "Saturday", "phonetic": "/ˈsætədeɪ/", "syllables": ["Sat", "ur", "day"], "chinese": "星期六", "grade": 3, "unit": "时间日历", "example": "We go camping on Saturday.", "gradeName": "三年级", "meaning": "星期六", "pos": "n."}, {"id": "gd_431", "word": "Sunday", "phonetic": "/ˈsʌndeɪ/", "syllables": ["Sun", "day"], "chinese": "星期日", "grade": 3, "unit": "时间日历", "example": "Visit grandparents on Sunday.", "gradeName": "三年级", "meaning": "星期日", "pos": "n."}, {"id": "gd_432", "word": "weekend", "phonetic": "/ˌwiːkˈend/", "syllables": ["week", "end"], "chinese": "周末", "grade": 3, "unit": "时间日历", "example": "Enjoy your restful weekend.", "gradeName": "三年级", "meaning": "周末", "pos": "n."}, {"id": "gd_433", "word": "January", "phonetic": "/ˈdʒænjuəri/", "syllables": ["Jan", "u", "ar", "y"], "chinese": "一月", "grade": 5, "unit": "时间日历", "example": "New Year arrives in January.", "gradeName": "五年级", "meaning": "一月", "pos": "n."}, {"id": "gd_434", "word": "February", "phonetic": "/ˈfebruəri/", "syllables": ["Feb", "ru", "ar", "y"], "chinese": "二月", "grade": 5, "unit": "时间日历", "example": "Spring Festival is in February.", "gradeName": "五年级", "meaning": "二月", "pos": "n."}, {"id": "gd_435", "word": "March", "phonetic": "/mɑːtʃ/", "syllables": ["March"], "chinese": "三月", "grade": 5, "unit": "时间日历", "example": "Plant green trees in March.", "gradeName": "五年级", "meaning": "三月", "pos": "n."}, {"id": "gd_436", "word": "April", "phonetic": "/ˈeɪprəl/", "syllables": ["A", "pril"], "chinese": "四月", "grade": 5, "unit": "时间日历", "example": "Warm April winds bring blooming flora.", "gradeName": "五年级", "meaning": "四月", "pos": "n."}, {"id": "gd_437", "word": "May", "phonetic": "/meɪ/", "syllables": ["May"], "chinese": "五月", "grade": 5, "unit": "时间日历", "example": "Labor Day is in early May.", "gradeName": "五年级", "meaning": "五月", "pos": "n."}, {"id": "gd_438", "word": "June", "phonetic": "/dʒuːn/", "syllables": ["June"], "chinese": "六月", "grade": 5, "unit": "时间日历", "example": "Children's Day is in June.", "gradeName": "五年级", "meaning": "六月", "pos": "n."}, {"id": "gd_439", "word": "July", "phonetic": "/dʒuˈlaɪ/", "syllables": ["Ju", "ly"], "chinese": "七月", "grade": 5, "unit": "时间日历", "example": "Summer holiday starts in July.", "gradeName": "五年级", "meaning": "七月", "pos": "n."}, {"id": "gd_440", "word": "August", "phonetic": "/ɔːˈɡʌst/", "syllables": ["Au", "gust"], "chinese": "八月", "grade": 5, "unit": "时间日历", "example": "Camp by the lakes in August.", "gradeName": "五年级", "meaning": "八月", "pos": "n."}, {"id": "gd_441", "word": "September", "phonetic": "/sepˈtembə(r)/", "syllables": ["Sep", "tem", "ber"], "chinese": "九月", "grade": 5, "unit": "时间日历", "example": "New school term opens September.", "gradeName": "五年级", "meaning": "九月", "pos": "n."}, {"id": "gd_442", "word": "October", "phonetic": "/ɒkˈtəʊbə(r)/", "syllables": ["Oc", "to", "ber"], "chinese": "十月", "grade": 5, "unit": "时间日历", "example": "National Day is in October.", "gradeName": "五年级", "meaning": "十月", "pos": "n."}, {"id": "gd_443", "word": "November", "phonetic": "/nəʊˈvembə(r)/", "syllables": ["No", "vem", "ber"], "chinese": "十一月", "grade": 5, "unit": "时间日历", "example": "Leaves tumble down in November.", "gradeName": "五年级", "meaning": "十一月", "pos": "n."}, {"id": "gd_444", "word": "December", "phonetic": "/dɪˈsembə(r)/", "syllables": ["De", "cem", "ber"], "chinese": "十二月", "grade": 5, "unit": "时间日历", "example": "December concludes a good year.", "gradeName": "五年级", "meaning": "十二月", "pos": "n."}, {"id": "gd_445", "word": "play", "phonetic": "/pleɪ/", "syllables": ["play"], "chinese": "玩耍；演奏", "grade": 3, "unit": "动作与日常", "example": "Play soccer in playground.", "gradeName": "三年级", "meaning": "玩耍；演奏", "pos": "v."}, {"id": "gd_446", "word": "sing", "phonetic": "/sɪŋ/", "syllables": ["sing"], "chinese": "唱歌", "grade": 3, "unit": "动作与日常", "example": "Sing an English song aloud.", "gradeName": "三年级", "meaning": "唱歌", "pos": "v."}, {"id": "gd_447", "word": "dance", "phonetic": "/dɑːns/", "syllables": ["dance"], "chinese": "跳舞", "grade": 3, "unit": "动作与日常", "example": "Dance with the happy rhythm.", "gradeName": "三年级", "meaning": "跳舞", "pos": "v."}, {"id": "gd_448", "word": "draw", "phonetic": "/drɔː/", "syllables": ["draw"], "chinese": "绘画；画画", "grade": 3, "unit": "动作与日常", "example": "Draw a picture with colors.", "gradeName": "三年级", "meaning": "绘画；画画", "pos": "n."}, {"id": "gd_449", "word": "read", "phonetic": "/riːd/", "syllables": ["read"], "chinese": "阅读；读书", "grade": 3, "unit": "动作与日常", "example": "Read good books every evening.", "gradeName": "三年级", "meaning": "阅读；读书", "pos": "n."}, {"id": "gd_450", "word": "write", "phonetic": "/raɪt/", "syllables": ["write"], "chinese": "写；书写", "grade": 3, "unit": "动作与日常", "example": "Write neatly with your pencil.", "gradeName": "三年级", "meaning": "写；书写", "pos": "v."}, {"id": "gd_451", "word": "swim", "phonetic": "/swɪm/", "syllables": ["swim"], "chinese": "游泳", "grade": 3, "unit": "动作与日常", "example": "Swim fast like a little fish.", "gradeName": "三年级", "meaning": "游泳", "pos": "v."}, {"id": "gd_452", "word": "run", "phonetic": "/rʌn/", "syllables": ["run"], "chinese": "跑步", "grade": 3, "unit": "动作与日常", "example": "Run three rounds every morning.", "gradeName": "三年级", "meaning": "跑步", "pos": "v."}, {"id": "gd_453", "word": "jump", "phonetic": "/dʒʌmp/", "syllables": ["jump"], "chinese": "跳跃", "grade": 3, "unit": "动作与日常", "example": "Jump over the low fence.", "gradeName": "三年级", "meaning": "跳跃", "pos": "v."}, {"id": "gd_454", "word": "fly", "phonetic": "/flaɪ/", "syllables": ["fly"], "chinese": "飞；放飞", "grade": 3, "unit": "动作与日常", "example": "Birds fly high in the air.", "gradeName": "三年级", "meaning": "飞；放飞", "pos": "v."}, {"id": "gd_455", "word": "walk", "phonetic": "/wɔːk/", "syllables": ["walk"], "chinese": "步行；散步", "grade": 3, "unit": "动作与日常", "example": "Take a peaceful walk in garden.", "gradeName": "三年级", "meaning": "步行；散步", "pos": "n."}, {"id": "gd_456", "word": "sleep", "phonetic": "/sliːp/", "syllables": ["sleep"], "chinese": "睡眠；睡觉", "grade": 3, "unit": "动作与日常", "example": "Sleep eight hours every night.", "gradeName": "三年级", "meaning": "睡眠；睡觉", "pos": "v."}, {"id": "gd_457", "word": "wake", "phonetic": "/weɪk/", "syllables": ["wake"], "chinese": "醒来；唤醒", "grade": 4, "unit": "动作与日常", "example": "Wake up early at sunrise.", "gradeName": "四年级", "meaning": "醒来；唤醒", "pos": "n."}, {"id": "gd_458", "word": "wash", "phonetic": "/wɒʃ/", "syllables": ["wash"], "chinese": "清洗；洗手", "grade": 3, "unit": "动作与日常", "example": "Wash your hands before eating.", "gradeName": "三年级", "meaning": "清洗；洗手", "pos": "n."}, {"id": "gd_459", "word": "clean", "phonetic": "/kliːn/", "syllables": ["clean"], "chinese": "打扫；干净的", "grade": 3, "unit": "动作与日常", "example": "Clean the classroom chalkboard.", "gradeName": "三年级", "meaning": "打扫；干净的", "pos": "v."}, {"id": "gd_460", "word": "listen", "phonetic": "/ˈlɪsn/", "syllables": ["lis", "ten"], "chinese": "倾听；听", "grade": 3, "unit": "动作与日常", "example": "Listen carefully in the lecture.", "gradeName": "三年级", "meaning": "倾听；听", "pos": "n."}, {"id": "gd_461", "word": "hear", "phonetic": "/hɪə(r)/", "syllables": ["hear"], "chinese": "听见；听到", "grade": 4, "unit": "动作与日常", "example": "Hear melodic birdsong outside.", "gradeName": "四年级", "meaning": "听见；听到", "pos": "v."}, {"id": "gd_462", "word": "speak", "phonetic": "/spiːk/", "syllables": ["speak"], "chinese": "说；讲（语言）", "grade": 3, "unit": "动作与日常", "example": "Speak English with confidence.", "gradeName": "三年级", "meaning": "说；讲（语言）", "pos": "v."}, {"id": "gd_463", "word": "talk", "phonetic": "/tɔːk/", "syllables": ["talk"], "chinese": "谈话；交谈", "grade": 3, "unit": "动作与日常", "example": "Talk with your good teacher.", "gradeName": "三年级", "meaning": "谈话；交谈", "pos": "n."}, {"id": "gd_464", "word": "tell", "phonetic": "/tel/", "syllables": ["tell"], "chinese": "告诉；讲述", "grade": 3, "unit": "动作与日常", "example": "Tell an interesting bedtime tale.", "gradeName": "三年级", "meaning": "告诉；讲述", "pos": "n."}, {"id": "gd_465", "word": "say", "phonetic": "/seɪ/", "syllables": ["say"], "chinese": "说；讲", "grade": 2, "unit": "动作与日常", "example": "Say thank you politely.", "gradeName": "二年级", "meaning": "说；讲", "pos": "v."}, {"id": "gd_466", "word": "ask", "phonetic": "/ɑːsk/", "syllables": ["ask"], "chinese": "询问；请求", "grade": 3, "unit": "动作与日常", "example": "Ask teacher for assistance.", "gradeName": "三年级", "meaning": "询问；请求", "pos": "n."}, {"id": "gd_467", "word": "answer", "phonetic": "/ˈɑːnsə(r)/", "syllables": ["an", "swer"], "chinese": "回答；答案", "grade": 3, "unit": "动作与日常", "example": "Answer questions correctly.", "gradeName": "三年级", "meaning": "回答；答案", "pos": "n."}, {"id": "gd_468", "word": "watch", "phonetic": "/wɒtʃ/", "syllables": ["watch"], "chinese": "观看；手表", "grade": 3, "unit": "动作与日常", "example": "Watch interesting science videos.", "gradeName": "三年级", "meaning": "观看；手表", "pos": "n."}, {"id": "gd_469", "word": "look", "phonetic": "/lʊk/", "syllables": ["look"], "chinese": "看；瞧", "grade": 1, "unit": "动作与日常", "example": "Look at the flying plane!", "gradeName": "一年级", "meaning": "看；瞧", "pos": "v."}, {"id": "gd_470", "word": "see", "phonetic": "/siː/", "syllables": ["see"], "chinese": "看见；明白", "grade": 1, "unit": "动作与日常", "example": "See you again next Monday.", "gradeName": "一年级", "meaning": "看见；明白", "pos": "v."}, {"id": "gd_471", "word": "smell", "phonetic": "/smel/", "syllables": ["smell"], "chinese": "闻；嗅；气味", "grade": 4, "unit": "动作与日常", "example": "Smell the sweet jasmine.", "gradeName": "四年级", "meaning": "闻；嗅；气味", "pos": "n."}, {"id": "gd_472", "word": "taste", "phonetic": "/teɪst/", "syllables": ["taste"], "chinese": "品尝；味道", "grade": 4, "unit": "动作与日常", "example": "Taste the crispy cookies.", "gradeName": "四年级", "meaning": "品尝；味道", "pos": "n."}, {"id": "gd_473", "word": "touch", "phonetic": "/tʌtʃ/", "syllables": ["touch"], "chinese": "触摸；接触", "grade": 2, "unit": "动作与日常", "example": "Touch your nose softly.", "gradeName": "二年级", "meaning": "触摸；接触", "pos": "n."}, {"id": "gd_474", "word": "feel", "phonetic": "/fiːl/", "syllables": ["feel"], "chinese": "感觉；觉得", "grade": 5, "unit": "动作与日常", "example": "I feel healthy and vibrant.", "gradeName": "五年级", "meaning": "感觉；觉得", "pos": "n."}, {"id": "gd_475", "word": "think", "phonetic": "/θɪŋk/", "syllables": ["think"], "chinese": "思考；认为", "grade": 4, "unit": "动作与日常", "example": "Think twice before acting.", "gradeName": "四年级", "meaning": "思考；认为", "pos": "n."}, {"id": "gd_476", "word": "know", "phonetic": "/nəʊ/", "syllables": ["know"], "chinese": "知道；了解", "grade": 3, "unit": "动作与日常", "example": "Do you know the answer?", "gradeName": "三年级", "meaning": "知道；了解", "pos": "n."}, {"id": "gd_477", "word": "learn", "phonetic": "/lɜːn/", "syllables": ["learn"], "chinese": "学习；学会", "grade": 3, "unit": "动作与日常", "example": "Learn new skills enthusiastically.", "gradeName": "三年级", "meaning": "学习；学会", "pos": "v."}, {"id": "gd_478", "word": "teach", "phonetic": "/tiːtʃ/", "syllables": ["teach"], "chinese": "教学；教授", "grade": 3, "unit": "动作与日常", "example": "Teach children with patience.", "gradeName": "三年级", "meaning": "教学；教授", "pos": "v."}, {"id": "gd_479", "word": "help", "phonetic": "/help/", "syllables": ["help"], "chinese": "帮助；援助", "grade": 2, "unit": "动作与日常", "example": "Help peers overcome difficulty.", "gradeName": "二年级", "meaning": "帮助；援助", "pos": "v."}, {"id": "gd_480", "word": "make", "phonetic": "/meɪk/", "syllables": ["make"], "chinese": "制作；使得", "grade": 3, "unit": "动作与日常", "example": "Make a birthday greeting card.", "gradeName": "三年级", "meaning": "制作；使得", "pos": "n."}, {"id": "gd_481", "word": "do", "phonetic": "/duː/", "syllables": ["do"], "chinese": "做；干", "grade": 2, "unit": "动作与日常", "example": "Do your morning exercises.", "gradeName": "二年级", "meaning": "做；干", "pos": "v."}, {"id": "gd_482", "word": "have", "phonetic": "/hæv/", "syllables": ["have"], "chinese": "有；吃；举行", "grade": 1, "unit": "动作与日常", "example": "Have a cup of warm tea.", "gradeName": "一年级", "meaning": "有；吃；举行", "pos": "v."}, {"id": "gd_483", "word": "give", "phonetic": "/ɡɪv/", "syllables": ["give"], "chinese": "给予；递给", "grade": 2, "unit": "动作与日常", "example": "Give flowers to your mother.", "gradeName": "二年级", "meaning": "给予；递给", "pos": "v."}, {"id": "gd_484", "word": "take", "phonetic": "/teɪk/", "syllables": ["take"], "chinese": "带走；花费；拍照", "grade": 2, "unit": "动作与日常", "example": "Take an umbrella on trip.", "gradeName": "二年级", "meaning": "带走；花费；拍照", "pos": "v."}, {"id": "gd_485", "word": "bring", "phonetic": "/brɪŋ/", "syllables": ["bring"], "chinese": "带来；拿来", "grade": 3, "unit": "动作与日常", "example": "Bring your dictionary tomorrow.", "gradeName": "三年级", "meaning": "带来；拿来", "pos": "v."}, {"id": "gd_486", "word": "buy", "phonetic": "/baɪ/", "syllables": ["buy"], "chinese": "购买；买", "grade": 3, "unit": "动作与日常", "example": "Buy fresh apples at supermarket.", "gradeName": "三年级", "meaning": "购买；买", "pos": "n."}, {"id": "gd_487", "word": "sell", "phonetic": "/sel/", "syllables": ["sell"], "chinese": "卖；出售", "grade": 4, "unit": "动作与日常", "example": "Sell homemade lemonade.", "gradeName": "四年级", "meaning": "卖；出售", "pos": "n."}, {"id": "gd_488", "word": "find", "phonetic": "/faɪnd/", "syllables": ["find"], "chinese": "找到；发现", "grade": 3, "unit": "动作与日常", "example": "Find the lost keys quickly.", "gradeName": "三年级", "meaning": "找到；发现", "pos": "v."}, {"id": "gd_489", "word": "lose", "phonetic": "/luːz/", "syllables": ["lose"], "chinese": "丢失；失败", "grade": 4, "unit": "动作与日常", "example": "Do not lose courage.", "gradeName": "四年级", "meaning": "丢失；失败", "pos": "n."}, {"id": "gd_490", "word": "win", "phonetic": "/wɪn/", "syllables": ["win"], "chinese": "获胜；赢取", "grade": 4, "unit": "动作与日常", "example": "Win the championship trophy.", "gradeName": "四年级", "meaning": "获胜；赢取", "pos": "n."}, {"id": "gd_491", "word": "pass", "phonetic": "/pɑːs/", "syllables": ["pass"], "chinese": "传递；通过", "grade": 3, "unit": "动作与日常", "example": "Please pass me the salt.", "gradeName": "三年级", "meaning": "传递；通过", "pos": "n."}, {"id": "gd_492", "word": "kick", "phonetic": "/kɪk/", "syllables": ["kick"], "chinese": "踢", "grade": 2, "unit": "动作与日常", "example": "Kick soccer ball into goal.", "gradeName": "二年级", "meaning": "踢", "pos": "v."}, {"id": "gd_493", "word": "catch", "phonetic": "/kætʃ/", "syllables": ["catch"], "chinese": "抓住；赶上", "grade": 3, "unit": "动作与日常", "example": "Catch the flying frisbee.", "gradeName": "三年级", "meaning": "抓住；赶上", "pos": "v."}, {"id": "gd_494", "word": "throw", "phonetic": "/θrəʊ/", "syllables": ["throw"], "chinese": "投掷；扔", "grade": 3, "unit": "动作与日常", "example": "Throw the ball to your teammate.", "gradeName": "三年级", "meaning": "投掷；扔", "pos": "n."}, {"id": "gd_495", "word": "hit", "phonetic": "/hɪt/", "syllables": ["hit"], "chinese": "击打；撞击", "grade": 4, "unit": "动作与日常", "example": "Hit the baseball with bat.", "gradeName": "四年级", "meaning": "击打；撞击", "pos": "n."}, {"id": "gd_496", "word": "climb", "phonetic": "/klaɪm/", "syllables": ["climb"], "chinese": "攀爬；爬山", "grade": 3, "unit": "动作与日常", "example": "Climb the hill to watch sunrise.", "gradeName": "三年级", "meaning": "攀爬；爬山", "pos": "n."}, {"id": "gd_497", "word": "skate", "phonetic": "/skeɪt/", "syllables": ["skate"], "chinese": "滑冰；溜冰", "grade": 4, "unit": "动作与日常", "example": "Skate on frozen winter lake.", "gradeName": "四年级", "meaning": "滑冰；溜冰", "pos": "v."}, {"id": "gd_498", "word": "ski", "phonetic": "/skiː/", "syllables": ["ski"], "chinese": "滑雪", "grade": 4, "unit": "动作与日常", "example": "Ski down the snowy slope.", "gradeName": "四年级", "meaning": "滑雪", "pos": "v."}, {"id": "gd_499", "word": "ride", "phonetic": "/raɪd/", "syllables": ["ride"], "chinese": "骑乘（车或马）", "grade": 3, "unit": "动作与日常", "example": "Ride your bike with helmet.", "gradeName": "三年级", "meaning": "骑乘（车或马）", "pos": "v."}, {"id": "gd_500", "word": "drive", "phonetic": "/draɪv/", "syllables": ["drive"], "chinese": "驾驶；开车", "grade": 3, "unit": "动作与日常", "example": "Drive safely on wet roads.", "gradeName": "三年级", "meaning": "驾驶；开车", "pos": "n."}, {"id": "gd_501", "word": "travel", "phonetic": "/ˈtrævl/", "syllables": ["trav", "el"], "chinese": "旅游；旅行", "grade": 5, "unit": "动作与日常", "example": "Travel broadens youthful horizons.", "gradeName": "五年级", "meaning": "旅游；旅行", "pos": "v."}, {"id": "gd_502", "word": "visit", "phonetic": "/ˈvɪzɪt/", "syllables": ["vis", "it"], "chinese": "拜访；参观", "grade": 5, "unit": "动作与日常", "example": "Visit historic museums in Beijing.", "gradeName": "五年级", "meaning": "拜访；参观", "pos": "n."}, {"id": "gd_503", "word": "stay", "phonetic": "/steɪ/", "syllables": ["stay"], "chinese": "停留；暂住", "grade": 4, "unit": "动作与日常", "example": "Stay healthy and active.", "gradeName": "四年级", "meaning": "停留；暂住", "pos": "n."}, {"id": "gd_504", "word": "live", "phonetic": "/lɪv/", "syllables": ["live"], "chinese": "居住；生活", "grade": 3, "unit": "动作与日常", "example": "Live in a peaceful community.", "gradeName": "三年级", "meaning": "居住；生活", "pos": "n."}, {"id": "gd_505", "word": "wait", "phonetic": "/weɪt/", "syllables": ["wait"], "chinese": "等待；等候", "grade": 3, "unit": "动作与日常", "example": "Wait for the green light.", "gradeName": "三年级", "meaning": "等待；等候", "pos": "v."}, {"id": "gd_506", "word": "open", "phonetic": "/ˈəʊpən/", "syllables": ["o", "pen"], "chinese": "打开；开着的", "grade": 1, "unit": "动作与日常", "example": "Open the door for guests.", "gradeName": "一年级", "meaning": "打开；开着的", "pos": "v."}, {"id": "gd_507", "word": "close", "phonetic": "/kləʊz/", "syllables": ["close"], "chinese": "关闭；合上", "grade": 1, "unit": "动作与日常", "example": "Close your textbooks now.", "gradeName": "一年级", "meaning": "关闭；合上", "pos": "v."}, {"id": "gd_508", "word": "cut", "phonetic": "/kʌt/", "syllables": ["cut"], "chinese": "剪切；切开", "grade": 2, "unit": "动作与日常", "example": "Cut paper into star shapes.", "gradeName": "二年级", "meaning": "剪切；切开", "pos": "n."}, {"id": "gd_509", "word": "put", "phonetic": "/pʊt/", "syllables": ["put"], "chinese": "放置；安置", "grade": 2, "unit": "动作与日常", "example": "Put pencils inside the box.", "gradeName": "二年级", "meaning": "放置；安置", "pos": "v."}, {"id": "gd_510", "word": "pick", "phonetic": "/pɪk/", "syllables": ["pick"], "chinese": "采摘；挑选", "grade": 3, "unit": "动作与日常", "example": "Pick sweet ripe apples.", "gradeName": "三年级", "meaning": "采摘；挑选", "pos": "n."}, {"id": "gd_511", "word": "plant", "phonetic": "/plɑːnt/", "syllables": ["plant"], "chinese": "种植；植物", "grade": 3, "unit": "动作与日常", "example": "Plant a leafy green tree.", "gradeName": "三年级", "meaning": "种植；植物", "pos": "v."}, {"id": "gd_512", "word": "grow", "phonetic": "/ɡrəʊ/", "syllables": ["grow"], "chinese": "生长；种植", "grade": 4, "unit": "动作与日常", "example": "Sunflowers grow towards sun.", "gradeName": "四年级", "meaning": "生长；种植", "pos": "adj."}, {"id": "gd_513", "word": "feed", "phonetic": "/fiːd/", "syllables": ["feed"], "chinese": "喂养；饲育", "grade": 3, "unit": "动作与日常", "example": "Feed the fluffy ducks grain.", "gradeName": "三年级", "meaning": "喂养；饲育", "pos": "v."}, {"id": "gd_514", "word": "bake", "phonetic": "/beɪk/", "syllables": ["bake"], "chinese": "烘烤；烤制", "grade": 4, "unit": "动作与日常", "example": "Bake crispy cookies.", "gradeName": "四年级", "meaning": "烘烤；烤制", "pos": "n."}, {"id": "gd_515", "word": "sweep", "phonetic": "/swiːp/", "syllables": ["sweep"], "chinese": "扫除；打扫", "grade": 3, "unit": "动作与日常", "example": "Sweep the porch floor.", "gradeName": "三年级", "meaning": "扫除；打扫", "pos": "v."}, {"id": "gd_516", "word": "mop", "phonetic": "/mɒp/", "syllables": ["mop"], "chinese": "拖地；拖把", "grade": 4, "unit": "动作与日常", "example": "Mop the kitchen tiles.", "gradeName": "四年级", "meaning": "拖地；拖把", "pos": "v."}, {"id": "gd_517", "word": "tidy", "phonetic": "/ˈtaɪdi/", "syllables": ["ti", "dy"], "chinese": "整理；整洁的", "grade": 4, "unit": "动作与日常", "example": "Tidy up your study desk.", "gradeName": "四年级", "meaning": "整理；整洁的", "pos": "n."}, {"id": "gd_518", "word": "show", "phonetic": "/ʃəʊ/", "syllables": ["show"], "chinese": "展示；出示", "grade": 2, "unit": "动作与日常", "example": "Show me your drawings.", "gradeName": "二年级", "meaning": "展示；出示", "pos": "v."}, {"id": "gd_519", "word": "send", "phonetic": "/send/", "syllables": ["send"], "chinese": "发送；邮寄", "grade": 4, "unit": "动作与日常", "example": "Send a warm holiday greeting.", "gradeName": "四年级", "meaning": "发送；邮寄", "pos": "n."}, {"id": "gd_520", "word": "smile", "phonetic": "/smaɪl/", "syllables": ["smile"], "chinese": "微笑", "grade": 3, "unit": "动作与日常", "example": "Smile brightly at everyone.", "gradeName": "三年级", "meaning": "微笑", "pos": "n."}, {"id": "gd_521", "word": "laugh", "phonetic": "/lɑːf/", "syllables": ["laugh"], "chinese": "发笑；大笑", "grade": 3, "unit": "动作与日常", "example": "Laugh cheerfully at the joke.", "gradeName": "三年级", "meaning": "发笑；大笑", "pos": "n."}, {"id": "gd_522", "word": "cry", "phonetic": "/kraɪ/", "syllables": ["cry"], "chinese": "哭泣；喊叫", "grade": 3, "unit": "动作与日常", "example": "Do not cry over spilled milk.", "gradeName": "三年级", "meaning": "哭泣；喊叫", "pos": "v."}, {"id": "gd_523", "word": "shout", "phonetic": "/ʃaʊt/", "syllables": ["shout"], "chinese": "呼喊；大叫", "grade": 4, "unit": "动作与日常", "example": "Never shout in library.", "gradeName": "四年级", "meaning": "呼喊；大叫", "pos": "n."}, {"id": "gd_524", "word": "start", "phonetic": "/stɑːt/", "syllables": ["start"], "chinese": "开始；出发", "grade": 3, "unit": "动作与日常", "example": "Start your morning journey.", "gradeName": "三年级", "meaning": "开始；出发", "pos": "v."}, {"id": "gd_525", "word": "begin", "phonetic": "/bɪˈɡɪn/", "syllables": ["be", "gin"], "chinese": "开始；着手", "grade": 4, "unit": "动作与日常", "example": "Begin reading the first chapter.", "gradeName": "四年级", "meaning": "开始；着手", "pos": "v."}, {"id": "gd_526", "word": "finish", "phonetic": "/ˈfɪnɪʃ/", "syllables": ["fin", "ish"], "chinese": "完成；结束", "grade": 4, "unit": "动作与日常", "example": "Finish assignments early.", "gradeName": "四年级", "meaning": "完成；结束", "pos": "n."}, {"id": "gd_527", "word": "end", "phonetic": "/end/", "syllables": ["end"], "chinese": "结束；末端", "grade": 3, "unit": "动作与日常", "example": "The happy story has an end.", "gradeName": "三年级", "meaning": "结束；末端", "pos": "v."}, {"id": "gd_528", "word": "try", "phonetic": "/traɪ/", "syllables": ["try"], "chinese": "尝试；努力", "grade": 3, "unit": "动作与日常", "example": "Try your best every time.", "gradeName": "三年级", "meaning": "尝试；努力", "pos": "n."}, {"id": "gd_529", "word": "hope", "phonetic": "/həʊp/", "syllables": ["hope"], "chinese": "希望；期盼", "grade": 6, "unit": "动作与日常", "example": "Never lose hope in tough times.", "gradeName": "六年级", "meaning": "希望；期盼", "pos": "v."}, {"id": "gd_530", "word": "wish", "phonetic": "/wɪʃ/", "syllables": ["wish"], "chinese": "愿望；祝福", "grade": 6, "unit": "动作与日常", "example": "Make a silent wish under stars.", "gradeName": "六年级", "meaning": "愿望；祝福", "pos": "v."}, {"id": "gd_531", "word": "want", "phonetic": "/wɒnt/", "syllables": ["want"], "chinese": "想要；需要", "grade": 2, "unit": "动作与日常", "example": "What do you want for lunch?", "gradeName": "二年级", "meaning": "想要；需要", "pos": "v."}, {"id": "gd_532", "word": "like", "phonetic": "/laɪk/", "syllables": ["like"], "chinese": "喜欢；像", "grade": 1, "unit": "动作与日常", "example": "I like sweet green grapes.", "gradeName": "一年级", "meaning": "喜欢；像", "pos": "v."}, {"id": "gd_533", "word": "love", "phonetic": "/lʌv/", "syllables": ["love"], "chinese": "热爱；关爱", "grade": 1, "unit": "动作与日常", "example": "Love your family and peers.", "gradeName": "一年级", "meaning": "热爱；关爱", "pos": "adj."}, {"id": "gd_534", "word": "need", "phonetic": "/niːd/", "syllables": ["need"], "chinese": "需要；必须", "grade": 3, "unit": "动作与日常", "example": "Plants need water and light.", "gradeName": "三年级", "meaning": "需要；必须", "pos": "v."}, {"id": "gd_535", "word": "can", "phonetic": "/kæn/", "syllables": ["can"], "chinese": "能；能够；罐头", "grade": 1, "unit": "情态动词", "example": "I can speak clear English.", "gradeName": "一年级", "meaning": "能；能够；罐头", "pos": "v."}, {"id": "gd_536", "word": "must", "phonetic": "/mʌst/", "syllables": ["must"], "chinese": "必须；务必", "grade": 4, "unit": "情态动词", "example": "You must obey safety rules.", "gradeName": "四年级", "meaning": "必须；务必", "pos": "v."}, {"id": "gd_537", "word": "should", "phonetic": "/ʃʊd/", "syllables": ["should"], "chinese": "应当；应该", "grade": 5, "unit": "情态动词", "example": "You should eat more veggies.", "gradeName": "五年级", "meaning": "应当；应该", "pos": "v."}, {"id": "gd_538", "word": "will", "phonetic": "/wɪl/", "syllables": ["will"], "chinese": "将要；会", "grade": 5, "unit": "情态动词", "example": "We will visit the museum.", "gradeName": "五年级", "meaning": "将要；会", "pos": "v."}, {"id": "gd_539", "word": "shall", "phonetic": "/ʃæl/", "syllables": ["shall"], "chinese": "将要；会", "grade": 5, "unit": "情态动词", "example": "Shall we begin our reading?", "gradeName": "五年级", "meaning": "将要；会", "pos": "v."}, {"id": "gd_540", "word": "would", "phonetic": "/wʊd/", "syllables": ["would"], "chinese": "将要；愿意", "grade": 4, "unit": "情态动词", "example": "Would you like a fresh pear?", "gradeName": "四年级", "meaning": "将要；愿意", "pos": "v."}, {"id": "gd_541", "word": "could", "phonetic": "/kʊd/", "syllables": ["could"], "chinese": "能够（can过去式）", "grade": 5, "unit": "情态动词", "example": "Could you lend me a hand?", "gradeName": "五年级", "meaning": "能够（can过去式）", "pos": "v."}, {"id": "gd_542", "word": "went", "phonetic": "/went/", "syllables": ["went"], "chinese": "去（go过去式）", "grade": 6, "unit": "不规则过去式", "example": "We went to Shanghai last summer.", "gradeName": "六年级", "meaning": "去（go过去式）", "pos": "v."}, {"id": "gd_543", "word": "saw", "phonetic": "/sɔː/", "syllables": ["saw"], "chinese": "看见（see过去式）", "grade": 6, "unit": "不规则过去式", "example": "I saw a magnificent rainbow.", "gradeName": "六年级", "meaning": "看见（see过去式）", "pos": "v."}, {"id": "gd_544", "word": "ate", "phonetic": "/eɪt/", "syllables": ["ate"], "chinese": "吃（eat过去式）", "grade": 6, "unit": "不规则过去式", "example": "He ate three dumplings for dinner.", "gradeName": "六年级", "meaning": "吃（eat过去式）", "pos": "v."}, {"id": "gd_545", "word": "had", "phonetic": "/hæd/", "syllables": ["had"], "chinese": "有；吃（have过去式）", "grade": 6, "unit": "不规则过去式", "example": "We had a wonderful picnic.", "gradeName": "六年级", "meaning": "有；吃（have过去式）", "pos": "v."}, {"id": "gd_546", "word": "did", "phonetic": "/dɪd/", "syllables": ["did"], "chinese": "做（do过去式）", "grade": 6, "unit": "不规则过去式", "example": "She did all her homework neatly.", "gradeName": "六年级", "meaning": "做（do过去式）", "pos": "v."}, {"id": "gd_547", "word": "was", "phonetic": "/wɒz/", "syllables": ["was"], "chinese": "是（am/is过去式）", "grade": 6, "unit": "不规则过去式", "example": "The weather was sunny yesterday.", "gradeName": "六年级", "meaning": "是（am/is过去式）", "pos": "v."}, {"id": "gd_548", "word": "were", "phonetic": "/wɜː(r)/", "syllables": ["were"], "chinese": "是（are过去式）", "grade": 6, "unit": "不规则过去式", "example": "They were joyful at concert.", "gradeName": "六年级", "meaning": "是（are过去式）", "pos": "v."}, {"id": "gd_549", "word": "bought", "phonetic": "/bɔːt/", "syllables": ["bought"], "chinese": "买（buy过去式）", "grade": 6, "unit": "不规则过去式", "example": "Dad bought a new tablet.", "gradeName": "六年级", "meaning": "买（buy过去式）", "pos": "v."}, {"id": "gd_550", "word": "took", "phonetic": "/tʊk/", "syllables": ["took"], "chinese": "带走（take过去式）", "grade": 6, "unit": "不规则过去式", "example": "He took lots of pictures on trip.", "gradeName": "六年级", "meaning": "带走（take过去式）", "pos": "v."}, {"id": "gd_551", "word": "came", "phonetic": "/keɪm/", "syllables": ["came"], "chinese": "来（come过去式）", "grade": 6, "unit": "不规则过去式", "example": "My cousins came to visit us.", "gradeName": "六年级", "meaning": "来（come过去式）", "pos": "v."}, {"id": "gd_552", "word": "made", "phonetic": "/meɪd/", "syllables": ["made"], "chinese": "做；制造（make过去式）", "grade": 6, "unit": "不规则过去式", "example": "Mom made a honey sponge cake.", "gradeName": "六年级", "meaning": "做；制造（make过去式）", "pos": "v."}, {"id": "gd_553", "word": "wrote", "phonetic": "/rəʊt/", "syllables": ["wrote"], "chinese": "写（write过去式）", "grade": 6, "unit": "不规则过去式", "example": "She wrote a thank-you note.", "gradeName": "六年级", "meaning": "写（write过去式）", "pos": "v."}, {"id": "gd_554", "word": "visited", "phonetic": "/ˈvɪzɪtɪd/", "syllables": ["vis", "it", "ed"], "chinese": "拜访（visit过去式）", "grade": 6, "unit": "规则过去式", "example": "We visited Great Wall in May.", "gradeName": "六年级", "meaning": "拜访（visit过去式）", "pos": "n."}, {"id": "gd_555", "word": "played", "phonetic": "/pleɪd/", "syllables": ["played"], "chinese": "玩（play过去式）", "grade": 6, "unit": "规则过去式", "example": "They played football in rain.", "gradeName": "六年级", "meaning": "玩（play过去式）", "pos": "v."}, {"id": "gd_556", "word": "cleaned", "phonetic": "/kliːnd/", "syllables": ["cleaned"], "chinese": "打扫（clean过去式）", "grade": 6, "unit": "规则过去式", "example": "We cleaned the school garden.", "gradeName": "六年级", "meaning": "打扫（clean过去式）", "pos": "v."}, {"id": "gd_557", "word": "stayed", "phonetic": "/steɪd/", "syllables": ["stayed"], "chinese": "停留（stay过去式）", "grade": 6, "unit": "规则过去式", "example": "I stayed at home and practiced piano.", "gradeName": "六年级", "meaning": "停留（stay过去式）", "pos": "n."}, {"id": "gd_558", "word": "watched", "phonetic": "/wɒtʃt/", "syllables": ["watched"], "chinese": "观看（watch过去式）", "grade": 6, "unit": "规则过去式", "example": "We watched the lunar eclipse.", "gradeName": "六年级", "meaning": "观看（watch过去式）", "pos": "n."}, {"id": "gd_559", "word": "learned", "phonetic": "/lɜːnd/", "syllables": ["learned"], "chinese": "学习（learn过去式）", "grade": 6, "unit": "规则过去式", "example": "He learned forty new words.", "gradeName": "六年级", "meaning": "学习（learn过去式）", "pos": "v."}, {"id": "gd_560", "word": "helped", "phonetic": "/helpt/", "syllables": ["helped"], "chinese": "帮助（help过去式）", "grade": 6, "unit": "规则过去式", "example": "She helped grandma cross the street.", "gradeName": "六年级", "meaning": "帮助（help过去式）", "pos": "v."}, {"id": "gd_561", "word": "big", "phonetic": "/bɪɡ/", "syllables": ["big"], "chinese": "大的", "grade": 1, "unit": "性质与感受", "example": "The elephant has big ears.", "gradeName": "一年级", "meaning": "大的", "pos": "adj."}, {"id": "gd_562", "word": "small", "phonetic": "/smɔːl/", "syllables": ["small"], "chinese": "小的", "grade": 1, "unit": "性质与感受", "example": "The mouse is very small.", "gradeName": "一年级", "meaning": "小的", "pos": "adj."}, {"id": "gd_563", "word": "long", "phonetic": "/lɒŋ/", "syllables": ["long"], "chinese": "长的", "grade": 1, "unit": "性质与感受", "example": "The snake has a long body.", "gradeName": "一年级", "meaning": "长的", "pos": "adj."}, {"id": "gd_564", "word": "short", "phonetic": "/ʃɔːt/", "syllables": ["short"], "chinese": "短的；矮的", "grade": 1, "unit": "性质与感受", "example": "The baby is cute and short.", "gradeName": "一年级", "meaning": "短的；矮的", "pos": "adj."}, {"id": "gd_565", "word": "tall", "phonetic": "/tɔːl/", "syllables": ["tall"], "chinese": "高的", "grade": 1, "unit": "性质与感受", "example": "Giraffes are very tall.", "gradeName": "一年级", "meaning": "高的", "pos": "adj."}, {"id": "gd_566", "word": "high", "phonetic": "/haɪ/", "syllables": ["high"], "chinese": "高度的；崇高的", "grade": 3, "unit": "性质与感受", "example": "Soar high into the sky.", "gradeName": "三年级", "meaning": "高度的；崇高的", "pos": "adj."}, {"id": "gd_567", "word": "low", "phonetic": "/ləʊ/", "syllables": ["low"], "chinese": "低矮的", "grade": 3, "unit": "性质与感受", "example": "Fly over low fences.", "gradeName": "三年级", "meaning": "低矮的", "pos": "adj."}, {"id": "gd_568", "word": "fat", "phonetic": "/fæt/", "syllables": ["fat"], "chinese": "胖的", "grade": 1, "unit": "性质与感受", "example": "The little panda looks fat.", "gradeName": "一年级", "meaning": "胖的", "pos": "adj."}, {"id": "gd_569", "word": "thin", "phonetic": "/θɪn/", "syllables": ["thin"], "chinese": "瘦的；薄的", "grade": 1, "unit": "性质与感受", "example": "The monkey is thin and agile.", "gradeName": "一年级", "meaning": "瘦的；薄的", "pos": "adj."}, {"id": "gd_570", "word": "heavy", "phonetic": "/ˈhevi/", "syllables": ["heav", "y"], "chinese": "沉重的", "grade": 4, "unit": "性质与感受", "example": "The luggage is too heavy to lift.", "gradeName": "四年级", "meaning": "沉重的", "pos": "n."}, {"id": "gd_571", "word": "strong", "phonetic": "/strɒŋ/", "syllables": ["strong"], "chinese": "强壮的", "grade": 4, "unit": "性质与感受", "example": "A strong body withstands chills.", "gradeName": "四年级", "meaning": "强壮的", "pos": "adj."}, {"id": "gd_572", "word": "weak", "phonetic": "/wiːk/", "syllables": ["weak"], "chinese": "虚弱的", "grade": 4, "unit": "性质与感受", "example": "Rest when you feel weak.", "gradeName": "四年级", "meaning": "虚弱的", "pos": "n."}, {"id": "gd_573", "word": "fast", "phonetic": "/fɑːst/", "syllables": ["fast"], "chinese": "迅速的；快的", "grade": 3, "unit": "性质与感受", "example": "Run fast towards goal line.", "gradeName": "三年级", "meaning": "迅速的；快的", "pos": "n."}, {"id": "gd_574", "word": "quick", "phonetic": "/kwɪk/", "syllables": ["quick"], "chinese": "敏捷的；快速的", "grade": 3, "unit": "性质与感受", "example": "Take a quick morning shower.", "gradeName": "三年级", "meaning": "敏捷的；快速的", "pos": "n."}, {"id": "gd_575", "word": "slow", "phonetic": "/sləʊ/", "syllables": ["slow"], "chinese": "缓慢的", "grade": 3, "unit": "性质与感受", "example": "Turtles walk slow and steady.", "gradeName": "三年级", "meaning": "缓慢的", "pos": "n."}, {"id": "gd_576", "word": "new", "phonetic": "/njuː/", "syllables": ["new"], "chinese": "崭新的", "grade": 1, "unit": "性质与感受", "example": "Wear a brand new sweater.", "gradeName": "一年级", "meaning": "崭新的", "pos": "n."}, {"id": "gd_577", "word": "old", "phonetic": "/əʊld/", "syllables": ["old"], "chinese": "陈旧的；年老的", "grade": 1, "unit": "性质与感受", "example": "An old oak tree in village.", "gradeName": "一年级", "meaning": "陈旧的；年老的", "pos": "n."}, {"id": "gd_578", "word": "young", "phonetic": "/jʌŋ/", "syllables": ["young"], "chinese": "年轻的；幼小的", "grade": 2, "unit": "性质与感受", "example": "Young saplings sprout.", "gradeName": "二年级", "meaning": "年轻的；幼小的", "pos": "adj."}, {"id": "gd_579", "word": "good", "phonetic": "/ɡʊd/", "syllables": ["good"], "chinese": "优良的；好的", "grade": 1, "unit": "性质与感受", "example": "You did a very good job.", "gradeName": "一年级", "meaning": "优良的；好的", "pos": "n."}, {"id": "gd_580", "word": "bad", "phonetic": "/bæd/", "syllables": ["bad"], "chinese": "糟糕的；坏的", "grade": 2, "unit": "性质与感受", "example": "Never form bad habits.", "gradeName": "二年级", "meaning": "糟糕的；坏的", "pos": "n."}, {"id": "gd_581", "word": "happy", "phonetic": "/ˈhæpi/", "syllables": ["hap", "py"], "chinese": "高兴的；开心的", "grade": 1, "unit": "性质与感受", "example": "Happy birthday to you!", "gradeName": "一年级", "meaning": "高兴的；开心的", "pos": "adj."}, {"id": "gd_582", "word": "glad", "phonetic": "/ɡlæd/", "syllables": ["glad"], "chinese": "欣慰的；高兴的", "grade": 3, "unit": "性质与感受", "example": "Glad to see your big improvement.", "gradeName": "三年级", "meaning": "欣慰的；高兴的", "pos": "adj."}, {"id": "gd_583", "word": "sad", "phonetic": "/sæd/", "syllables": ["sad"], "chinese": "伤心的；难过的", "grade": 5, "unit": "性质与感受", "example": "Do not be sad, tomorrow is new.", "gradeName": "五年级", "meaning": "伤心的；难过的", "pos": "adj."}, {"id": "gd_584", "word": "angry", "phonetic": "/ˈæŋɡri/", "syllables": ["an", "gry"], "chinese": "生气的", "grade": 5, "unit": "性质与感受", "example": "Calm down before you get angry.", "gradeName": "五年级", "meaning": "生气的", "pos": "adj."}, {"id": "gd_585", "word": "tired", "phonetic": "/ˈtaɪəd/", "syllables": ["tired"], "chinese": "疲劳的；累的", "grade": 5, "unit": "性质与感受", "example": "Take a rest when you feel tired.", "gradeName": "五年级", "meaning": "疲劳的；累的", "pos": "n."}, {"id": "gd_586", "word": "excited", "phonetic": "/ɪkˈsaɪtɪd/", "syllables": ["ex", "cit", "ed"], "chinese": "兴奋的；激动的", "grade": 5, "unit": "性质与感受", "example": "Students were excited for excursion.", "gradeName": "五年级", "meaning": "兴奋的；激动的", "pos": "adj."}, {"id": "gd_587", "word": "bored", "phonetic": "/bɔːd/", "syllables": ["bored"], "chinese": "无聊的", "grade": 5, "unit": "性质与感受", "example": "Read a novel if you feel bored.", "gradeName": "五年级", "meaning": "无聊的", "pos": "adj."}, {"id": "gd_588", "word": "scared", "phonetic": "/skeəd/", "syllables": ["scared"], "chinese": "害怕的", "grade": 5, "unit": "性质与感受", "example": "The puppy was scared of thunder.", "gradeName": "五年级", "meaning": "害怕的", "pos": "adj."}, {"id": "gd_589", "word": "proud", "phonetic": "/praʊd/", "syllables": ["proud"], "chinese": "自豪的", "grade": 5, "unit": "性质与感受", "example": "Parents are proud of your progress.", "gradeName": "五年级", "meaning": "自豪的", "pos": "adj."}, {"id": "gd_590", "word": "quiet", "phonetic": "/ˈkwaɪət/", "syllables": ["qui", "et"], "chinese": "安静的", "grade": 4, "unit": "性质与感受", "example": "Keep quiet in public reading room.", "gradeName": "四年级", "meaning": "安静的", "pos": "adj."}, {"id": "gd_591", "word": "noisy", "phonetic": "/ˈnɔɪzi/", "syllables": ["nois", "y"], "chinese": "嘈杂的；喧闹的", "grade": 4, "unit": "性质与感受", "example": "The busy marketplace is noisy.", "gradeName": "四年级", "meaning": "嘈杂的；喧闹的", "pos": "adj."}, {"id": "gd_592", "word": "loud", "phonetic": "/laʊd/", "syllables": ["loud"], "chinese": "大声的；响亮的", "grade": 4, "unit": "性质与感受", "example": "A loud whistle blew.", "gradeName": "四年级", "meaning": "大声的；响亮的", "pos": "adj."}, {"id": "gd_593", "word": "dirty", "phonetic": "/ˈdɜːti/", "syllables": ["dir", "ty"], "chinese": "肮脏的", "grade": 3, "unit": "性质与感受", "example": "Wash dirty soccer shoes.", "gradeName": "三年级", "meaning": "肮脏的", "pos": "n."}, {"id": "gd_594", "word": "easy", "phonetic": "/ˈiːzi/", "syllables": ["ea", "sy"], "chinese": "容易的", "grade": 3, "unit": "性质与感受", "example": "Practice makes the quiz easy.", "gradeName": "三年级", "meaning": "容易的", "pos": "adj."}, {"id": "gd_595", "word": "hard", "phonetic": "/hɑːd/", "syllables": ["hard"], "chinese": "困难的；坚硬的", "grade": 3, "unit": "性质与感受", "example": "Work hard to conquer difficulties.", "gradeName": "三年级", "meaning": "困难的；坚硬的", "pos": "n."}, {"id": "gd_596", "word": "difficult", "phonetic": "/ˈdɪfɪkəlt/", "syllables": ["dif", "fi", "cult"], "chinese": "困难的", "grade": 4, "unit": "性质与感受", "example": "Solve the difficult riddle.", "gradeName": "四年级", "meaning": "困难的", "pos": "n."}, {"id": "gd_597", "word": "soft", "phonetic": "/sɒft/", "syllables": ["soft"], "chinese": "柔软的", "grade": 3, "unit": "性质与感受", "example": "The bunny has soft fur.", "gradeName": "三年级", "meaning": "柔软的", "pos": "n."}, {"id": "gd_598", "word": "beautiful", "phonetic": "/ˈbjuːtɪfl/", "syllables": ["beau", "ti", "ful"], "chinese": "美丽的；优美的", "grade": 3, "unit": "性质与感受", "example": "What a beautiful sunrise!", "gradeName": "三年级", "meaning": "美丽的；优美的", "pos": "adj."}, {"id": "gd_599", "word": "pretty", "phonetic": "/ˈprɪti/", "syllables": ["pret", "ty"], "chinese": "俊俏的；漂亮的", "grade": 4, "unit": "性质与感受", "example": "What a pretty spring dress!", "gradeName": "四年级", "meaning": "俊俏的；漂亮的", "pos": "adj."}, {"id": "gd_600", "word": "cute", "phonetic": "/kjuːt/", "syllables": ["cute"], "chinese": "可爱的；乖巧的", "grade": 2, "unit": "性质与感受", "example": "A cute furry kitten.", "gradeName": "二年级", "meaning": "可爱的；乖巧的", "pos": "v."}, {"id": "gd_601", "word": "lovely", "phonetic": "/ˈlʌvli/", "syllables": ["love", "ly"], "chinese": "可爱的；愉快的", "grade": 2, "unit": "性质与感受", "example": "Spend a lovely picnic afternoon.", "gradeName": "二年级", "meaning": "可爱的；愉快的", "pos": "v."}, {"id": "gd_602", "word": "clever", "phonetic": "/ˈklevə(r)/", "syllables": ["clev", "er"], "chinese": "聪颖的；机敏的", "grade": 4, "unit": "性质与感受", "example": "The clever fox escaped hunter.", "gradeName": "四年级", "meaning": "聪颖的；机敏的", "pos": "adj."}, {"id": "gd_603", "word": "smart", "phonetic": "/smɑːt/", "syllables": ["smart"], "chinese": "聪明的；潇洒的", "grade": 3, "unit": "性质与感受", "example": "Smart kids study persistently.", "gradeName": "三年级", "meaning": "聪明的；潇洒的", "pos": "adj."}, {"id": "gd_604", "word": "brave", "phonetic": "/breɪv/", "syllables": ["brave"], "chinese": "勇敢的", "grade": 4, "unit": "性质与感受", "example": "Brave heroes protect city.", "gradeName": "四年级", "meaning": "勇敢的", "pos": "adj."}, {"id": "gd_605", "word": "polite", "phonetic": "/pəˈlaɪt/", "syllables": ["po", "lite"], "chinese": "有礼貌的", "grade": 4, "unit": "性质与感受", "example": "Always be polite to elders.", "gradeName": "四年级", "meaning": "有礼貌的", "pos": "v."}, {"id": "gd_606", "word": "helpful", "phonetic": "/ˈhelpfl/", "syllables": ["help", "ful"], "chinese": "乐于助人的", "grade": 4, "unit": "性质与感受", "example": "Students are kind and helpful.", "gradeName": "四年级", "meaning": "乐于助人的", "pos": "n."}, {"id": "gd_607", "word": "kind", "phonetic": "/kaɪnd/", "syllables": ["kind"], "chinese": "善良的；仁慈的", "grade": 3, "unit": "性质与感受", "example": "Be kind to animals.", "gradeName": "三年级", "meaning": "善良的；仁慈的", "pos": "adj."}, {"id": "gd_608", "word": "careful", "phonetic": "/ˈkeəfl/", "syllables": ["care", "ful"], "chinese": "细心的；仔细的", "grade": 3, "unit": "性质与感受", "example": "Be careful when crossing street.", "gradeName": "三年级", "meaning": "细心的；仔细的", "pos": "adj."}, {"id": "gd_609", "word": "safe", "phonetic": "/seɪf/", "syllables": ["safe"], "chinese": "安全的", "grade": 3, "unit": "性质与感受", "example": "Keep safe in playground.", "gradeName": "三年级", "meaning": "安全的", "pos": "adj."}, {"id": "gd_610", "word": "dangerous", "phonetic": "/ˈdeɪndʒərəs/", "syllables": ["dan", "ger", "ous"], "chinese": "危险的", "grade": 4, "unit": "性质与感受", "example": "Do not touch dangerous chemicals.", "gradeName": "四年级", "meaning": "危险的", "pos": "adj."}, {"id": "gd_611", "word": "same", "phonetic": "/seɪm/", "syllables": ["same"], "chinese": "相同的", "grade": 3, "unit": "性质与感受", "example": "We share the same dream.", "gradeName": "三年级", "meaning": "相同的", "pos": "n."}, {"id": "gd_612", "word": "different", "phonetic": "/ˈdɪfrənt/", "syllables": ["dif", "fer", "ent"], "chinese": "不同的", "grade": 4, "unit": "性质与感受", "example": "Everyone has different talents.", "gradeName": "四年级", "meaning": "不同的", "pos": "adj."}, {"id": "gd_613", "word": "busy", "phonetic": "/ˈbɪzi/", "syllables": ["bus", "y"], "chinese": "忙碌的", "grade": 3, "unit": "性质与感受", "example": "The bees are busy collecting honey.", "gradeName": "三年级", "meaning": "忙碌的", "pos": "adj."}, {"id": "gd_614", "word": "free", "phonetic": "/friː/", "syllables": ["free"], "chinese": "空闲的；自由的", "grade": 3, "unit": "性质与感受", "example": "Are you free this weekend?", "gradeName": "三年级", "meaning": "空闲的；自由的", "pos": "adj."}, {"id": "gd_615", "word": "rich", "phonetic": "/rɪtʃ/", "syllables": ["rich"], "chinese": "丰富的；富裕的", "grade": 4, "unit": "性质与感受", "example": "Fruit is rich in vitamins.", "gradeName": "四年级", "meaning": "丰富的；富裕的", "pos": "n."}, {"id": "gd_616", "word": "poor", "phonetic": "/pɔː(r)/", "syllables": ["poor"], "chinese": "贫穷的；可怜的", "grade": 4, "unit": "性质与感受", "example": "Help the poor puppy.", "gradeName": "四年级", "meaning": "贫穷的；可怜的", "pos": "adj."}, {"id": "gd_617", "word": "cheap", "phonetic": "/tʃiːp/", "syllables": ["cheap"], "chinese": "廉价的", "grade": 4, "unit": "性质与感受", "example": "This notebook is very cheap.", "gradeName": "四年级", "meaning": "廉价的", "pos": "n."}, {"id": "gd_618", "word": "expensive", "phonetic": "/ɪkˈspensɪv/", "syllables": ["ex", "pen", "sive"], "chinese": "昂贵的", "grade": 4, "unit": "性质与感受", "example": "Diamonds are rare and expensive.", "gradeName": "四年级", "meaning": "昂贵的", "pos": "adj."}, {"id": "gd_619", "word": "where", "phonetic": "/weə(r)/", "syllables": ["where"], "chinese": "哪里", "grade": 2, "unit": "功能词汇", "example": "Where is my English book?", "gradeName": "二年级", "meaning": "哪里", "pos": "n."}, {"id": "gd_620", "word": "when", "phonetic": "/wen/", "syllables": ["when"], "chinese": "何时；当……时", "grade": 3, "unit": "功能词汇", "example": "When does the train arrive?", "gradeName": "三年级", "meaning": "何时；当……时", "pos": "n."}, {"id": "gd_621", "word": "why", "phonetic": "/waɪ/", "syllables": ["why"], "chinese": "为什么", "grade": 3, "unit": "功能词汇", "example": "Why are you late today?", "gradeName": "三年级", "meaning": "为什么", "pos": "n."}, {"id": "gd_622", "word": "which", "phonetic": "/wɪtʃ/", "syllables": ["which"], "chinese": "哪一个", "grade": 3, "unit": "功能词汇", "example": "Which colour do you prefer?", "gradeName": "三年级", "meaning": "哪一个", "pos": "n."}, {"id": "gd_623", "word": "whose", "phonetic": "/huːz/", "syllables": ["whose"], "chinese": "谁的", "grade": 4, "unit": "功能词汇", "example": "Whose umbrella is this?", "gradeName": "四年级", "meaning": "谁的", "pos": "n."}, {"id": "gd_624", "word": "in", "phonetic": "/ɪn/", "syllables": ["in"], "chinese": "在……里", "grade": 1, "unit": "功能词汇", "example": "Pencils are in the box.", "gradeName": "一年级", "meaning": "在……里", "pos": "n."}, {"id": "gd_625", "word": "on", "phonetic": "/ɒn/", "syllables": ["on"], "chinese": "在……上", "grade": 1, "unit": "功能词汇", "example": "Book is on the desk.", "gradeName": "一年级", "meaning": "在……上", "pos": "n."}, {"id": "gd_626", "word": "under", "phonetic": "/ˈʌndə(r)/", "syllables": ["un", "der"], "chinese": "在……下", "grade": 1, "unit": "功能词汇", "example": "The cat hides under the bed.", "gradeName": "一年级", "meaning": "在……下", "pos": "n."}, {"id": "gd_627", "word": "near", "phonetic": "/nɪə(r)/", "syllables": ["near"], "chinese": "在……附近", "grade": 2, "unit": "功能词汇", "example": "My house is near the park.", "gradeName": "二年级", "meaning": "在……附近", "pos": "n."}, {"id": "gd_628", "word": "behind", "phonetic": "/bɪˈhaɪnd/", "syllables": ["be", "hind"], "chinese": "在……后", "grade": 2, "unit": "功能词汇", "example": "Stand behind the line.", "gradeName": "二年级", "meaning": "在……后", "pos": "n."}, {"id": "gd_629", "word": "beside", "phonetic": "/bɪˈsaɪd/", "syllables": ["be", "side"], "chinese": "在……旁边", "grade": 3, "unit": "功能词汇", "example": "Sit beside your friend.", "gradeName": "三年级", "meaning": "在……旁边", "pos": "n."}, {"id": "gd_630", "word": "between", "phonetic": "/bɪˈtwiːn/", "syllables": ["be", "tween"], "chinese": "在……之间", "grade": 3, "unit": "功能词汇", "example": "Sit between two trees.", "gradeName": "三年级", "meaning": "在……之间", "pos": "n."}, {"id": "gd_631", "word": "in front of", "phonetic": "/ɪn frʌnt əv/", "syllables": ["in", "front", "of"], "chinese": "在……前面", "grade": 3, "unit": "功能词汇", "example": "A tree in front of our house.", "gradeName": "三年级", "meaning": "在……前面", "pos": "n."}, {"id": "gd_632", "word": "with", "phonetic": "/wɪð/", "syllables": ["with"], "chinese": "和……一起；用", "grade": 2, "unit": "功能词汇", "example": "Play with your classmates.", "gradeName": "二年级", "meaning": "和……一起；用", "pos": "n."}, {"id": "gd_633", "word": "without", "phonetic": "/wɪˈðaʊt/", "syllables": ["with", "out"], "chinese": "没有；不带", "grade": 4, "unit": "功能词汇", "example": "Fish cannot live without water.", "gradeName": "四年级", "meaning": "没有；不带", "pos": "n."}, {"id": "gd_634", "word": "for", "phonetic": "/fɔː(r)/", "syllables": ["for"], "chinese": "为了；给", "grade": 2, "unit": "功能词汇", "example": "A gift for your birthday.", "gradeName": "二年级", "meaning": "为了；给", "pos": "n."}, {"id": "gd_635", "word": "from", "phonetic": "/frɒm/", "syllables": ["from"], "chinese": "来自；从", "grade": 2, "unit": "功能词汇", "example": "Where are you from?", "gradeName": "二年级", "meaning": "来自；从", "pos": "v."}, {"id": "gd_636", "word": "about", "phonetic": "/əˈbaʊt/", "syllables": ["a", "bout"], "chinese": "关于；大约", "grade": 3, "unit": "功能词汇", "example": "A story about astronauts.", "gradeName": "三年级", "meaning": "关于；大约", "pos": "v."}, {"id": "gd_637", "word": "up", "phonetic": "/ʌp/", "syllables": ["up"], "chinese": "向上", "grade": 2, "unit": "功能词汇", "example": "Hands up high.", "gradeName": "二年级", "meaning": "向上", "pos": "n."}, {"id": "gd_638", "word": "down", "phonetic": "/daʊn/", "syllables": ["down"], "chinese": "向下", "grade": 2, "unit": "功能词汇", "example": "Sit down quietly.", "gradeName": "二年级", "meaning": "向下", "pos": "n."}, {"id": "gd_639", "word": "into", "phonetic": "/ˈɪntu/", "syllables": ["in", "to"], "chinese": "进入……里", "grade": 3, "unit": "功能词汇", "example": "Walk into the classroom.", "gradeName": "三年级", "meaning": "进入……里", "pos": "n."}, {"id": "gd_640", "word": "out of", "phonetic": "/aʊt əv/", "syllables": ["out", "of"], "chinese": "走出；从……出", "grade": 3, "unit": "功能词汇", "example": "Step out of the building.", "gradeName": "三年级", "meaning": "走出；从……出", "pos": "n."}, {"id": "gd_641", "word": "and", "phonetic": "/ænd/", "syllables": ["and"], "chinese": "和；并且", "grade": 1, "unit": "功能词汇", "example": "Apples and bananas.", "gradeName": "一年级", "meaning": "和；并且", "pos": "n."}, {"id": "gd_642", "word": "but", "phonetic": "/bʌt/", "syllables": ["but"], "chinese": "但是", "grade": 2, "unit": "功能词汇", "example": "I like sports, but not swimming.", "gradeName": "二年级", "meaning": "但是", "pos": "n."}, {"id": "gd_643", "word": "or", "phonetic": "/ɔː(r)/", "syllables": ["or"], "chinese": "或者；还是", "grade": 2, "unit": "功能词汇", "example": "Tea or coffee?", "gradeName": "二年级", "meaning": "或者；还是", "pos": "n."}, {"id": "gd_644", "word": "so", "phonetic": "/səʊ/", "syllables": ["so"], "chinese": "因此；如此", "grade": 3, "unit": "功能词汇", "example": "It was rainy, so we stayed home.", "gradeName": "三年级", "meaning": "因此；如此", "pos": "n."}, {"id": "gd_645", "word": "because", "phonetic": "/bɪˈkɒz/", "syllables": ["be", "cause"], "chinese": "因为", "grade": 4, "unit": "功能词汇", "example": "I like spring because flowers bloom.", "gradeName": "四年级", "meaning": "因为", "pos": "n."}, {"id": "gd_646", "word": "if", "phonetic": "/ɪf/", "syllables": ["if"], "chinese": "如果；假如", "grade": 4, "unit": "功能词汇", "example": "If you work hard, you succeed.", "gradeName": "四年级", "meaning": "如果；假如", "pos": "n."}, {"id": "gd_647", "word": "then", "phonetic": "/ðen/", "syllables": ["then"], "chinese": "然后；当时", "grade": 3, "unit": "功能词汇", "example": "Wash hands, then eat lunch.", "gradeName": "三年级", "meaning": "然后；当时", "pos": "n."}, {"id": "gd_648", "word": "also", "phonetic": "/ˈɔːlsəʊ/", "syllables": ["al", "so"], "chinese": "也；并且", "grade": 3, "unit": "功能词汇", "example": "She also enjoys music.", "gradeName": "三年级", "meaning": "也；并且", "pos": "n."}, {"id": "gd_649", "word": "too", "phonetic": "/tuː/", "syllables": ["too"], "chinese": "也；太", "grade": 1, "unit": "功能词汇", "example": "Nice to meet you, too.", "gradeName": "一年级", "meaning": "也；太", "pos": "n."}, {"id": "gd_650", "word": "beach", "phonetic": "/biːtʃ/", "syllables": ["beach"], "chinese": "沙滩；海滩", "grade": 4, "unit": "自然与时节", "example": "Build sandcastles on the beach.", "gradeName": "四年级", "meaning": "沙滩；海滩", "pos": "n."}, {"id": "gd_651", "word": "sand", "phonetic": "/sænd/", "syllables": ["sand"], "chinese": "沙子", "grade": 4, "unit": "自然与时节", "example": "Golden sand warm in summer sun.", "gradeName": "四年级", "meaning": "沙子", "pos": "n."}, {"id": "gd_652", "word": "island", "phonetic": "/ˈaɪlənd/", "syllables": ["is", "land"], "chinese": "岛屿", "grade": 5, "unit": "自然与时节", "example": "Tropical green island in ocean.", "gradeName": "五年级", "meaning": "岛屿", "pos": "n."}, {"id": "gd_653", "word": "space", "phonetic": "/speɪs/", "syllables": ["space"], "chinese": "太空；空间", "grade": 5, "unit": "自然与时节", "example": "Astronauts travel into outer space.", "gradeName": "五年级", "meaning": "太空；空间", "pos": "n."}, {"id": "gd_654", "word": "planet", "phonetic": "/ˈplænɪt/", "syllables": ["plan", "et"], "chinese": "行星", "grade": 5, "unit": "自然与时节", "example": "Earth is our home planet.", "gradeName": "五年级", "meaning": "行星", "pos": "n."}, {"id": "gd_655", "word": "sunlight", "phonetic": "/ˈsʌnlaɪt/", "syllables": ["sun", "light"], "chinese": "阳光", "grade": 3, "unit": "自然与时节", "example": "Morning sunlight warms the room.", "gradeName": "三年级", "meaning": "阳光", "pos": "n."}, {"id": "gd_656", "word": "shadow", "phonetic": "/ˈʃædəʊ/", "syllables": ["shad", "ow"], "chinese": "影子", "grade": 3, "unit": "自然与时节", "example": "My shadow follows me around.", "gradeName": "三年级", "meaning": "影子", "pos": "n."}, {"id": "gd_657", "word": "fog", "phonetic": "/fɒɡ/", "syllables": ["fog"], "chinese": "雾气", "grade": 4, "unit": "自然与时节", "example": "Dense morning fog over river.", "gradeName": "四年级", "meaning": "雾气", "pos": "n."}, {"id": "gd_658", "word": "foggy", "phonetic": "/ˈfɒɡi/", "syllables": ["fog", "gy"], "chinese": "有雾的；多雾的", "grade": 4, "unit": "自然与时节", "example": "Drive carefully on a foggy morning.", "gradeName": "四年级", "meaning": "有雾的；多雾的", "pos": "v."}, {"id": "gd_659", "word": "thunder", "phonetic": "/ˈθʌndə(r)/", "syllables": ["thun", "der"], "chinese": "雷鸣；雷声", "grade": 4, "unit": "自然与时节", "example": "Hear distant rumbling thunder.", "gradeName": "四年级", "meaning": "雷鸣；雷声", "pos": "n."}, {"id": "gd_660", "word": "lightning", "phonetic": "/ˈlaɪtnɪŋ/", "syllables": ["light", "ning"], "chinese": "闪电", "grade": 4, "unit": "自然与时节", "example": "Flashes of bright lightning.", "gradeName": "四年级", "meaning": "闪电", "pos": "n."}, {"id": "gd_661", "word": "storm", "phonetic": "/stɔːm/", "syllables": ["storm"], "chinese": "暴风雨", "grade": 4, "unit": "自然与时节", "example": "A sudden heavy summer storm.", "gradeName": "四年级", "meaning": "暴风雨", "pos": "n."}, {"id": "gd_662", "word": "stone", "phonetic": "/stəʊn/", "syllables": ["stone"], "chinese": "石头", "grade": 3, "unit": "自然与时节", "example": "Skip smooth stones across lake.", "gradeName": "三年级", "meaning": "石头", "pos": "n."}, {"id": "gd_663", "word": "rock", "phonetic": "/rɒk/", "syllables": ["rock"], "chinese": "岩石", "grade": 3, "unit": "自然与时节", "example": "Climb the big gray rock.", "gradeName": "三年级", "meaning": "岩石", "pos": "n."}, {"id": "gd_664", "word": "desert", "phonetic": "/ˈdezət/", "syllables": ["des", "ert"], "chinese": "沙漠", "grade": 5, "unit": "自然与时节", "example": "Camels walk across desert sands.", "gradeName": "五年级", "meaning": "沙漠", "pos": "n."}, {"id": "gd_665", "word": "cave", "phonetic": "/keɪv/", "syllables": ["cave"], "chinese": "洞穴", "grade": 5, "unit": "自然与时节", "example": "Bats rest in the cool cave.", "gradeName": "五年级", "meaning": "洞穴", "pos": "n."}, {"id": "gd_666", "word": "shore", "phonetic": "/ʃɔː(r)/", "syllables": ["shore"], "chinese": "岸边；滨", "grade": 5, "unit": "自然与时节", "example": "Waves lap against the shore.", "gradeName": "五年级", "meaning": "岸边；滨", "pos": "n."}, {"id": "gd_667", "word": "breeze", "phonetic": "/briːz/", "syllables": ["breeze"], "chinese": "微风", "grade": 4, "unit": "自然与时节", "example": "A refreshing spring breeze.", "gradeName": "四年级", "meaning": "微风", "pos": "n."}, {"id": "gd_668", "word": "frost", "phonetic": "/frɒst/", "syllables": ["frost"], "chinese": "霜；霜冻", "grade": 5, "unit": "自然与时节", "example": "Winter frost on glass windows.", "gradeName": "五年级", "meaning": "霜；霜冻", "pos": "n."}, {"id": "gd_669", "word": "nature", "phonetic": "/ˈneɪtʃə(r)/", "syllables": ["na", "ture"], "chinese": "大自然；自然界", "grade": 4, "unit": "自然与时节", "example": "Protect nature and wildlife.", "gradeName": "四年级", "meaning": "大自然；自然界", "pos": "adj."}, {"id": "gd_670", "word": "bowl", "phonetic": "/bəʊl/", "syllables": ["bowl"], "chinese": "碗", "grade": 2, "unit": "生活用品", "example": "A bowl of warm noodles.", "gradeName": "二年级", "meaning": "碗", "pos": "n."}, {"id": "gd_671", "word": "plate", "phonetic": "/pleɪt/", "syllables": ["plate"], "chinese": "盘子；碟子", "grade": 2, "unit": "生活用品", "example": "Put sweet fruits on the plate.", "gradeName": "二年级", "meaning": "盘子；碟子", "pos": "n."}, {"id": "gd_672", "word": "fork", "phonetic": "/fɔːk/", "syllables": ["fork"], "chinese": "叉子", "grade": 2, "unit": "生活用品", "example": "Eat spaghetti with a fork.", "gradeName": "二年级", "meaning": "叉子", "pos": "n."}, {"id": "gd_673", "word": "spoon", "phonetic": "/spuːn/", "syllables": ["spoon"], "chinese": "勺子；匙", "grade": 2, "unit": "生活用品", "example": "Stir hot soup with a spoon.", "gradeName": "二年级", "meaning": "勺子；匙", "pos": "n."}, {"id": "gd_674", "word": "knife", "phonetic": "/naɪf/", "syllables": ["knife"], "chinese": "餐刀；小刀", "grade": 2, "unit": "生活用品", "example": "Butter your bread with a knife.", "gradeName": "二年级", "meaning": "餐刀；小刀", "pos": "n."}, {"id": "gd_675", "word": "chopsticks", "phonetic": "/ˈtʃɒpstɪks/", "syllables": ["chop", "sticks"], "chinese": "筷子", "grade": 2, "unit": "生活用品", "example": "Use bamboo chopsticks skillfully.", "gradeName": "二年级", "meaning": "筷子", "pos": "n."}, {"id": "gd_676", "word": "cup", "phonetic": "/kʌp/", "syllables": ["cup"], "chinese": "茶杯；杯子", "grade": 1, "unit": "生活用品", "example": "A cup of warm green tea.", "gradeName": "一年级", "meaning": "茶杯；杯子", "pos": "n."}, {"id": "gd_677", "word": "glass", "phonetic": "/ɡlɑːs/", "syllables": ["glass"], "chinese": "玻璃杯；玻璃", "grade": 2, "unit": "生活用品", "example": "A tall glass of orange juice.", "gradeName": "二年级", "meaning": "玻璃杯；玻璃", "pos": "n."}, {"id": "gd_678", "word": "bottle", "phonetic": "/ˈbɒtl/", "syllables": ["bot", "tle"], "chinese": "水瓶；瓶子", "grade": 2, "unit": "生活用品", "example": "A reusable water bottle.", "gradeName": "二年级", "meaning": "水瓶；瓶子", "pos": "n."}, {"id": "gd_679", "word": "pot", "phonetic": "/pɒt/", "syllables": ["pot"], "chinese": "锅；壶", "grade": 3, "unit": "生活用品", "example": "Cook stew in an iron pot.", "gradeName": "三年级", "meaning": "锅；壶", "pos": "n."}, {"id": "gd_680", "word": "ticket", "phonetic": "/ˈtɪkɪt/", "syllables": ["tick", "et"], "chinese": "车票；门票", "grade": 3, "unit": "生活用品", "example": "Show your museum entrance ticket.", "gradeName": "三年级", "meaning": "车票；门票", "pos": "n."}, {"id": "gd_681", "word": "passport", "phonetic": "/ˈpɑːspɔːt/", "syllables": ["pass", "port"], "chinese": "护照", "grade": 5, "unit": "生活用品", "example": "Keep your passport secure.", "gradeName": "五年级", "meaning": "护照", "pos": "n."}, {"id": "gd_682", "word": "camera", "phonetic": "/ˈkæmrə/", "syllables": ["cam", "er", "a"], "chinese": "照相机", "grade": 3, "unit": "生活用品", "example": "Take photos with digital camera.", "gradeName": "三年级", "meaning": "照相机", "pos": "n."}, {"id": "gd_683", "word": "wallet", "phonetic": "/ˈwɒlɪt/", "syllables": ["wal", "let"], "chinese": "钱包", "grade": 4, "unit": "生活用品", "example": "Keep coins in your wallet.", "gradeName": "四年级", "meaning": "钱包", "pos": "n."}, {"id": "gd_684", "word": "letter", "phonetic": "/ˈletə(r)/", "syllables": ["let", "ter"], "chinese": "信件；字母", "grade": 2, "unit": "生活用品", "example": "Write a letter to grandpa.", "gradeName": "二年级", "meaning": "信件；字母", "pos": "n."}, {"id": "gd_685", "word": "postcard", "phonetic": "/ˈpəʊstkɑːd/", "syllables": ["post", "card"], "chinese": "明信片", "grade": 3, "unit": "生活用品", "example": "Send a scenic holiday postcard.", "gradeName": "三年级", "meaning": "明信片", "pos": "n."}, {"id": "gd_686", "word": "envelope", "phonetic": "/ˈenvələʊp/", "syllables": ["en", "ve", "lope"], "chinese": "信封", "grade": 4, "unit": "生活用品", "example": "Put the letter into an envelope.", "gradeName": "四年级", "meaning": "信封", "pos": "n."}, {"id": "gd_687", "word": "email", "phonetic": "/ˈiːmeɪl/", "syllables": ["e", "mail"], "chinese": "电子邮件", "grade": 4, "unit": "生活用品", "example": "Send a quick email to teacher.", "gradeName": "四年级", "meaning": "电子邮件", "pos": "n."}, {"id": "gd_688", "word": "message", "phonetic": "/ˈmesɪdʒ/", "syllables": ["mes", "sage"], "chinese": "消息；口信", "grade": 4, "unit": "生活用品", "example": "Leave a polite voice message.", "gradeName": "四年级", "meaning": "消息；口信", "pos": "n."}, {"id": "gd_689", "word": "radio", "phonetic": "/ˈreɪdiəʊ/", "syllables": ["ra", "di", "o"], "chinese": "收音机", "grade": 3, "unit": "生活用品", "example": "Listen to English news on radio.", "gradeName": "三年级", "meaning": "收音机", "pos": "n."}, {"id": "gd_690", "word": "invite", "phonetic": "/ɪnˈvaɪt/", "syllables": ["in", "vite"], "chinese": "邀请", "grade": 4, "unit": "动作与日常", "example": "Invite peers to birthday party.", "gradeName": "四年级", "meaning": "邀请", "pos": "n."}, {"id": "gd_691", "word": "borrow", "phonetic": "/ˈbɒrəʊ/", "syllables": ["bor", "row"], "chinese": "借入；借用", "grade": 3, "unit": "动作与日常", "example": "Borrow three books from library.", "gradeName": "三年级", "meaning": "借入；借用", "pos": "n."}, {"id": "gd_692", "word": "lend", "phonetic": "/lend/", "syllables": ["lend"], "chinese": "借给；借出", "grade": 4, "unit": "动作与日常", "example": "Lend a pencil to your friend.", "gradeName": "四年级", "meaning": "借给；借出", "pos": "n."}, {"id": "gd_693", "word": "pack", "phonetic": "/pæk/", "syllables": ["pack"], "chinese": "打包；收拾行李", "grade": 4, "unit": "动作与日常", "example": "Pack your luggage for travel.", "gradeName": "四年级", "meaning": "打包；收拾行李", "pos": "v."}, {"id": "gd_694", "word": "arrive", "phonetic": "/əˈraɪv/", "syllables": ["ar", "rive"], "chinese": "到达；抵达", "grade": 4, "unit": "动作与日常", "example": "The train will arrive on time.", "gradeName": "四年级", "meaning": "到达；抵达", "pos": "n."}, {"id": "gd_695", "word": "leave", "phonetic": "/liːv/", "syllables": ["leave"], "chinese": "离开；留下", "grade": 4, "unit": "动作与日常", "example": "Leave for school at seven thirty.", "gradeName": "四年级", "meaning": "离开；留下", "pos": "n."}, {"id": "gd_696", "word": "choose", "phonetic": "/tʃuːz/", "syllables": ["choose"], "chinese": "选择；挑选", "grade": 4, "unit": "动作与日常", "example": "Choose your favorite English book.", "gradeName": "四年级", "meaning": "选择；挑选", "pos": "n."}, {"id": "gd_697", "word": "agree", "phonetic": "/əˈɡriː/", "syllables": ["a", "gree"], "chinese": "赞同；同意", "grade": 5, "unit": "动作与日常", "example": "I agree with your brilliant plan.", "gradeName": "五年级", "meaning": "赞同；同意", "pos": "n."}, {"id": "gd_698", "word": "refuse", "phonetic": "/rɪˈfjuːz/", "syllables": ["re", "fuse"], "chinese": "拒绝", "grade": 5, "unit": "动作与日常", "example": "Politely refuse unhealthy snacks.", "gradeName": "五年级", "meaning": "拒绝", "pos": "n."}, {"id": "gd_699", "word": "explain", "phonetic": "/ɪkˈspleɪn/", "syllables": ["ex", "plain"], "chinese": "解释；说明", "grade": 5, "unit": "动作与日常", "example": "Explain the math solution clearly.", "gradeName": "五年级", "meaning": "解释；说明", "pos": "n."}, {"id": "gd_700", "word": "describe", "phonetic": "/dɪˈskraɪb/", "syllables": ["de", "scribe"], "chinese": "描述；描绘", "grade": 5, "unit": "动作与日常", "example": "Describe your dream bedroom.", "gradeName": "五年级", "meaning": "描述；描绘", "pos": "n."}, {"id": "gd_701", "word": "practice", "phonetic": "/ˈpræktɪs/", "syllables": ["prac", "tice"], "chinese": "练习；操练", "grade": 3, "unit": "动作与日常", "example": "Practice spoken English daily.", "gradeName": "三年级", "meaning": "练习；操练", "pos": "n."}, {"id": "gd_702", "word": "review", "phonetic": "/rɪˈvjuː/", "syllables": ["re", "view"], "chinese": "复习；温习", "grade": 3, "unit": "动作与日常", "example": "Review vocabulary before bed.", "gradeName": "三年级", "meaning": "复习；温习", "pos": "n."}, {"id": "gd_703", "word": "prepare", "phonetic": "/prɪˈpeə(r)/", "syllables": ["pre", "pare"], "chinese": "准备；预备", "grade": 4, "unit": "动作与日常", "example": "Prepare for the coming term.", "gradeName": "四年级", "meaning": "准备；预备", "pos": "n."}, {"id": "gd_704", "word": "protect", "phonetic": "/prəˈtekt/", "syllables": ["pro", "tect"], "chinese": "保护；保卫", "grade": 5, "unit": "动作与日常", "example": "Protect endangered animals.", "gradeName": "五年级", "meaning": "保护；保卫", "pos": "n."}, {"id": "gd_705", "word": "save", "phonetic": "/seɪv/", "syllables": ["save"], "chinese": "拯救；节约", "grade": 3, "unit": "动作与日常", "example": "Save water and electricity.", "gradeName": "三年级", "meaning": "拯救；节约", "pos": "n."}, {"id": "gd_706", "word": "waste", "phonetic": "/weɪst/", "syllables": ["waste"], "chinese": "浪费", "grade": 4, "unit": "动作与日常", "example": "Never waste delicious food.", "gradeName": "四年级", "meaning": "浪费", "pos": "n."}, {"id": "gd_707", "word": "share", "phonetic": "/ʃeə(r)/", "syllables": ["share"], "chinese": "分享；分担", "grade": 2, "unit": "动作与日常", "example": "Share sweet apples with friends.", "gradeName": "二年级", "meaning": "分享；分担", "pos": "n."}, {"id": "gd_708", "word": "care", "phonetic": "/keə(r)/", "syllables": ["care"], "chinese": "关心；在乎", "grade": 3, "unit": "动作与日常", "example": "Care for younger schoolmates.", "gradeName": "三年级", "meaning": "关心；在乎", "pos": "v."}, {"id": "gd_709", "word": "celebrate", "phonetic": "/ˈselɪbreɪt/", "syllables": ["cel", "e", "brate"], "chinese": "庆祝；祝贺", "grade": 4, "unit": "动作与日常", "example": "Celebrate the New Year joyfully.", "gradeName": "四年级", "meaning": "庆祝；祝贺", "pos": "n."}, {"id": "gd_710", "word": "compete", "phonetic": "/kəmˈpiːt/", "syllables": ["com", "pete"], "chinese": "竞争；竞赛", "grade": 5, "unit": "动作与日常", "example": "Compete fairly in track sports.", "gradeName": "五年级", "meaning": "竞争；竞赛", "pos": "n."}, {"id": "gd_711", "word": "score", "phonetic": "/skɔː(r)/", "syllables": ["score"], "chinese": "得分；进球", "grade": 4, "unit": "动作与日常", "example": "Score the winning goal in soccer.", "gradeName": "四年级", "meaning": "得分；进球", "pos": "n."}, {"id": "gd_712", "word": "miss", "phonetic": "/mɪs/", "syllables": ["miss"], "chinese": "思念；错过", "grade": 3, "unit": "动作与日常", "example": "I miss my grandparents dearly.", "gradeName": "三年级", "meaning": "思念；错过", "pos": "n."}, {"id": "gd_713", "word": "cross", "phonetic": "/krɒs/", "syllables": ["cross"], "chinese": "横过；穿过", "grade": 3, "unit": "动作与日常", "example": "Cross zebra crossing with care.", "gradeName": "三年级", "meaning": "横过；穿过", "pos": "n."}, {"id": "gd_714", "word": "turn", "phonetic": "/tɜːn/", "syllables": ["turn"], "chinese": "转向；转弯", "grade": 2, "unit": "动作与日常", "example": "Turn right at the bookstore.", "gradeName": "二年级", "meaning": "转向；转弯", "pos": "n."}, {"id": "gd_715", "word": "curious", "phonetic": "/ˈkjʊəriəs/", "syllables": ["cu", "ri", "ous"], "chinese": "好奇的", "grade": 4, "unit": "性格与品质", "example": "Children are curious about nature.", "gradeName": "四年级", "meaning": "好奇的", "pos": "adj."}];

  const PEP_VOCABULARY = [{"id": "pep_001", "word": "cat", "phonetic": "/kæt/", "syllables": ["cat"], "chinese": "猫", "grade": 1, "unit": "动物天地", "example": "The cat catches mice.", "gradeName": "一年级", "meaning": "猫", "pos": "n."}, {"id": "pep_002", "word": "dog", "phonetic": "/dɒɡ/", "syllables": ["dog"], "chinese": "狗", "grade": 1, "unit": "动物天地", "example": "The dog barks joyfully.", "gradeName": "一年级", "meaning": "狗", "pos": "n."}, {"id": "pep_003", "word": "duck", "phonetic": "/dʌk/", "syllables": ["duck"], "chinese": "鸭子", "grade": 1, "unit": "动物天地", "example": "Ducks swim in the pond.", "gradeName": "一年级", "meaning": "鸭子", "pos": "n."}, {"id": "pep_004", "word": "bear", "phonetic": "/beə(r)/", "syllables": ["bear"], "chinese": "熊", "grade": 1, "unit": "动物天地", "example": "A big brown bear sleeps.", "gradeName": "一年级", "meaning": "熊", "pos": "n."}, {"id": "pep_005", "word": "panda", "phonetic": "/ˈpændə/", "syllables": ["pan", "da"], "chinese": "大熊猫", "grade": 1, "unit": "动物天地", "example": "Pandas love fresh bamboo.", "gradeName": "一年级", "meaning": "大熊猫", "pos": "adj."}, {"id": "pep_006", "word": "monkey", "phonetic": "/ˈmʌŋki/", "syllables": ["mon", "key"], "chinese": "猴子", "grade": 1, "unit": "动物天地", "example": "Monkeys climb tall trees.", "gradeName": "一年级", "meaning": "猴子", "pos": "n."}, {"id": "pep_007", "word": "rabbit", "phonetic": "/ˈræbɪt/", "syllables": ["rab", "bit"], "chinese": "兔子", "grade": 1, "unit": "动物天地", "example": "The white rabbit has red eyes.", "gradeName": "一年级", "meaning": "兔子", "pos": "n."}, {"id": "pep_008", "word": "tiger", "phonetic": "/ˈtaɪɡə(r)/", "syllables": ["ti", "ger"], "chinese": "老虎", "grade": 1, "unit": "动物天地", "example": "Tigers are strong and brave.", "gradeName": "一年级", "meaning": "老虎", "pos": "n."}, {"id": "pep_009", "word": "lion", "phonetic": "/ˈlaɪən/", "syllables": ["li", "on"], "chinese": "狮子", "grade": 1, "unit": "动物天地", "example": "The lion is the king of beasts.", "gradeName": "一年级", "meaning": "狮子", "pos": "n."}, {"id": "pep_010", "word": "elephant", "phonetic": "/ˈelɪfənt/", "syllables": ["el", "e", "phant"], "chinese": "大象", "grade": 1, "unit": "动物天地", "example": "The elephant has a long nose.", "gradeName": "一年级", "meaning": "大象", "pos": "adj."}, {"id": "pep_011", "word": "bird", "phonetic": "/bɜːd/", "syllables": ["bird"], "chinese": "小鸟", "grade": 1, "unit": "动物天地", "example": "Birds sing in the morning.", "gradeName": "一年级", "meaning": "小鸟", "pos": "adj."}, {"id": "pep_012", "word": "fish", "phonetic": "/fɪʃ/", "syllables": ["fish"], "chinese": "鱼", "grade": 1, "unit": "动物天地", "example": "Fish swim in clean water.", "gradeName": "一年级", "meaning": "鱼", "pos": "n."}, {"id": "pep_013", "word": "pig", "phonetic": "/pɪɡ/", "syllables": ["pig"], "chinese": "猪", "grade": 1, "unit": "动物天地", "example": "The little pig is sleeping.", "gradeName": "一年级", "meaning": "猪", "pos": "n."}, {"id": "pep_014", "word": "mouse", "phonetic": "/maʊs/", "syllables": ["mouse"], "chinese": "老鼠", "grade": 1, "unit": "动物天地", "example": "The tiny mouse is eating cheese.", "gradeName": "一年级", "meaning": "老鼠", "pos": "n."}, {"id": "pep_015", "word": "frog", "phonetic": "/frɒɡ/", "syllables": ["frog"], "chinese": "青蛙", "grade": 1, "unit": "动物天地", "example": "Green frogs jump into the lake.", "gradeName": "一年级", "meaning": "青蛙", "pos": "n."}, {"id": "pep_016", "word": "horse", "phonetic": "/hɔːs/", "syllables": ["horse"], "chinese": "马", "grade": 2, "unit": "动物天地", "example": "A white horse gallops across fields.", "gradeName": "二年级", "meaning": "马", "pos": "n."}, {"id": "pep_017", "word": "cow", "phonetic": "/kaʊ/", "syllables": ["cow"], "chinese": "奶牛；母牛", "grade": 2, "unit": "动物天地", "example": "Cows give us healthy milk.", "gradeName": "二年级", "meaning": "奶牛；母牛", "pos": "n."}, {"id": "pep_018", "word": "sheep", "phonetic": "/ʃiːp/", "syllables": ["sheep"], "chinese": "绵羊", "grade": 2, "unit": "动物天地", "example": "Flock of white sheep on green hill.", "gradeName": "二年级", "meaning": "绵羊", "pos": "n."}, {"id": "pep_019", "word": "goat", "phonetic": "/ɡəʊt/", "syllables": ["goat"], "chinese": "山羊", "grade": 2, "unit": "动物天地", "example": "Mountain goats climb steep rocks.", "gradeName": "二年级", "meaning": "山羊", "pos": "n."}, {"id": "pep_020", "word": "hen", "phonetic": "/hen/", "syllables": ["hen"], "chinese": "母鸡", "grade": 2, "unit": "动物天地", "example": "The hen laid a fresh brown egg.", "gradeName": "二年级", "meaning": "母鸡", "pos": "n."}, {"id": "pep_021", "word": "rooster", "phonetic": "/ˈruːstə(r)/", "syllables": ["roos", "ter"], "chinese": "公鸡", "grade": 2, "unit": "动物天地", "example": "The rooster crows at dawn.", "gradeName": "二年级", "meaning": "公鸡", "pos": "n."}, {"id": "pep_022", "word": "chick", "phonetic": "/tʃɪk/", "syllables": ["chick"], "chinese": "小鸡", "grade": 2, "unit": "动物天地", "example": "Yellow chicks follow their mother.", "gradeName": "二年级", "meaning": "小鸡", "pos": "adj."}, {"id": "pep_023", "word": "goose", "phonetic": "/ɡuːs/", "syllables": ["goose"], "chinese": "鹅", "grade": 2, "unit": "动物天地", "example": "The white goose swims gracefully.", "gradeName": "二年级", "meaning": "鹅", "pos": "n."}, {"id": "pep_024", "word": "snake", "phonetic": "/sneɪk/", "syllables": ["snake"], "chinese": "蛇", "grade": 2, "unit": "动物天地", "example": "The long snake glides through grass.", "gradeName": "二年级", "meaning": "蛇", "pos": "n."}, {"id": "pep_025", "word": "giraffe", "phonetic": "/dʒəˈrɑːf/", "syllables": ["gi", "raffe"], "chinese": "长颈鹿", "grade": 3, "unit": "动物天地", "example": "Giraffes have very long necks.", "gradeName": "三年级", "meaning": "长颈鹿", "pos": "adj."}, {"id": "pep_026", "word": "deer", "phonetic": "/dɪə(r)/", "syllables": ["deer"], "chinese": "鹿", "grade": 3, "unit": "动物天地", "example": "Gentle deer drink at the spring.", "gradeName": "三年级", "meaning": "鹿", "pos": "n."}, {"id": "pep_027", "word": "zebra", "phonetic": "/ˈzebrə/", "syllables": ["ze", "bra"], "chinese": "斑马", "grade": 3, "unit": "动物天地", "example": "Zebras have black and white stripes.", "gradeName": "三年级", "meaning": "斑马", "pos": "n."}, {"id": "pep_028", "word": "kangaroo", "phonetic": "/ˌkæŋɡəˈruː/", "syllables": ["kan", "ga", "roo"], "chinese": "袋鼠", "grade": 3, "unit": "动物天地", "example": "Kangaroos hop across Australia.", "gradeName": "三年级", "meaning": "袋鼠", "pos": "n."}, {"id": "pep_029", "word": "fox", "phonetic": "/fɒks/", "syllables": ["fox"], "chinese": "狐狸", "grade": 3, "unit": "动物天地", "example": "The clever fox has a bushy tail.", "gradeName": "三年级", "meaning": "狐狸", "pos": "n."}, {"id": "pep_030", "word": "wolf", "phonetic": "/wʊlf/", "syllables": ["wolf"], "chinese": "狼", "grade": 3, "unit": "动物天地", "example": "Wolves live together in a pack.", "gradeName": "三年级", "meaning": "狼", "pos": "n."}, {"id": "pep_031", "word": "butterfly", "phonetic": "/ˈbʌtəflaɪ/", "syllables": ["but", "ter", "fly"], "chinese": "蝴蝶", "grade": 3, "unit": "动物天地", "example": "Colorful butterflies flutter around roses.", "gradeName": "三年级", "meaning": "蝴蝶", "pos": "n."}, {"id": "pep_032", "word": "bee", "phonetic": "/biː/", "syllables": ["bee"], "chinese": "蜜蜂", "grade": 3, "unit": "动物天地", "example": "Busy bees collect sweet nectar.", "gradeName": "三年级", "meaning": "蜜蜂", "pos": "n."}, {"id": "pep_033", "word": "ant", "phonetic": "/ænt/", "syllables": ["ant"], "chinese": "蚂蚁", "grade": 3, "unit": "动物天地", "example": "Tiny ants work together diligently.", "gradeName": "三年级", "meaning": "蚂蚁", "pos": "n."}, {"id": "pep_034", "word": "whale", "phonetic": "/weɪl/", "syllables": ["whale"], "chinese": "鲸鱼", "grade": 4, "unit": "动物天地", "example": "Blue whales are oceanic giants.", "gradeName": "四年级", "meaning": "鲸鱼", "pos": "n."}, {"id": "pep_035", "word": "dolphin", "phonetic": "/ˈdɒlfɪn/", "syllables": ["dol", "phin"], "chinese": "海豚", "grade": 4, "unit": "动物天地", "example": "Dolphins leap joyfully over waves.", "gradeName": "四年级", "meaning": "海豚", "pos": "n."}, {"id": "pep_036", "word": "shark", "phonetic": "/ʃɑːk/", "syllables": ["shark"], "chinese": "鲨鱼", "grade": 4, "unit": "动物天地", "example": "Sharks swim fast in deep ocean.", "gradeName": "四年级", "meaning": "鲨鱼", "pos": "n."}, {"id": "pep_037", "word": "dinosaur", "phonetic": "/ˈdaɪnəsɔː(r)/", "syllables": ["di", "no", "saur"], "chinese": "恐龙", "grade": 4, "unit": "动物天地", "example": "Huge dinosaurs lived long ago.", "gradeName": "四年级", "meaning": "恐龙", "pos": "n."}, {"id": "pep_038", "word": "insect", "phonetic": "/ˈɪnsekt/", "syllables": ["in", "sect"], "chinese": "昆虫", "grade": 4, "unit": "动物天地", "example": "Learn about insects in science class.", "gradeName": "四年级", "meaning": "昆虫", "pos": "n."}, {"id": "pep_039", "word": "pet", "phonetic": "/pet/", "syllables": ["pet"], "chinese": "宠物", "grade": 2, "unit": "动物天地", "example": "Take good care of your home pet.", "gradeName": "二年级", "meaning": "宠物", "pos": "n."}, {"id": "pep_040", "word": "tail", "phonetic": "/teɪl/", "syllables": ["tail"], "chinese": "尾巴", "grade": 2, "unit": "动物天地", "example": "The dog wags its fluffy tail.", "gradeName": "二年级", "meaning": "尾巴", "pos": "n."}, {"id": "pep_041", "word": "red", "phonetic": "/red/", "syllables": ["red"], "chinese": "红色；红色的", "grade": 1, "unit": "绚丽色彩", "example": "I like red roses.", "gradeName": "一年级", "meaning": "红色；红色的", "pos": "adj."}, {"id": "pep_042", "word": "yellow", "phonetic": "/ˈjeləʊ/", "syllables": ["yel", "low"], "chinese": "黄色；黄色的", "grade": 1, "unit": "绚丽色彩", "example": "The sun is bright yellow.", "gradeName": "一年级", "meaning": "黄色；黄色的", "pos": "adj."}, {"id": "pep_043", "word": "green", "phonetic": "/ɡriːn/", "syllables": ["green"], "chinese": "绿色；绿色的", "grade": 1, "unit": "绚丽色彩", "example": "Look at the green grass.", "gradeName": "一年级", "meaning": "绿色；绿色的", "pos": "adj."}, {"id": "pep_044", "word": "blue", "phonetic": "/bluː/", "syllables": ["blue"], "chinese": "蓝色；蓝色的", "grade": 1, "unit": "绚丽色彩", "example": "The sea is beautiful blue.", "gradeName": "一年级", "meaning": "蓝色；蓝色的", "pos": "adj."}, {"id": "pep_045", "word": "black", "phonetic": "/blæk/", "syllables": ["black"], "chinese": "黑色；黑色的", "grade": 1, "unit": "绚丽色彩", "example": "A black cat runs fast.", "gradeName": "一年级", "meaning": "黑色；黑色的", "pos": "adj."}, {"id": "pep_046", "word": "white", "phonetic": "/waɪt/", "syllables": ["white"], "chinese": "白色；白色的", "grade": 1, "unit": "绚丽色彩", "example": "Snow is pure white.", "gradeName": "一年级", "meaning": "白色；白色的", "pos": "adj."}, {"id": "pep_047", "word": "orange", "phonetic": "/ˈɒrɪndʒ/", "syllables": ["or", "ange"], "chinese": "橙色；橙色的", "grade": 1, "unit": "绚丽色彩", "example": "I want an orange juice.", "gradeName": "一年级", "meaning": "橙色；橙色的", "pos": "adj."}, {"id": "pep_048", "word": "brown", "phonetic": "/braʊn/", "syllables": ["brown"], "chinese": "棕色；棕色的", "grade": 1, "unit": "绚丽色彩", "example": "The bear has brown fur.", "gradeName": "一年级", "meaning": "棕色；棕色的", "pos": "adj."}, {"id": "pep_049", "word": "pink", "phonetic": "/pɪŋk/", "syllables": ["pink"], "chinese": "粉色；粉红色的", "grade": 1, "unit": "绚丽色彩", "example": "She wears a pink ribbon.", "gradeName": "一年级", "meaning": "粉色；粉红色的", "pos": "adj."}, {"id": "pep_050", "word": "purple", "phonetic": "/ˈpɜːpl/", "syllables": ["pur", "ple"], "chinese": "紫色；紫色的", "grade": 1, "unit": "绚丽色彩", "example": "Grapes are sweet and purple.", "gradeName": "一年级", "meaning": "紫色；紫色的", "pos": "adj."}, {"id": "pep_051", "word": "grey", "phonetic": "/ɡreɪ/", "syllables": ["grey"], "chinese": "灰色；灰色的", "grade": 1, "unit": "绚丽色彩", "example": "Rain clouds are dark grey.", "gradeName": "一年级", "meaning": "灰色；灰色的", "pos": "adj."}, {"id": "pep_052", "word": "gold", "phonetic": "/ɡəʊld/", "syllables": ["gold"], "chinese": "金色；黄金", "grade": 3, "unit": "绚丽色彩", "example": "The queen wore a gold crown.", "gradeName": "三年级", "meaning": "金色；黄金", "pos": "n."}, {"id": "pep_053", "word": "silver", "phonetic": "/ˈsɪlvə(r)/", "syllables": ["sil", "ver"], "chinese": "银色；白银", "grade": 3, "unit": "绚丽色彩", "example": "The moon shines like silver.", "gradeName": "三年级", "meaning": "银色；白银", "pos": "n."}, {"id": "pep_054", "word": "bright", "phonetic": "/braɪt/", "syllables": ["bright"], "chinese": "明亮的；鲜艳的", "grade": 3, "unit": "绚丽色彩", "example": "Bright stars fill night sky.", "gradeName": "三年级", "meaning": "明亮的；鲜艳的", "pos": "n."}, {"id": "pep_055", "word": "colour", "phonetic": "/ˈkʌlə(r)/", "syllables": ["col", "our"], "chinese": "颜色", "grade": 1, "unit": "绚丽色彩", "example": "What colour is the rainbow?", "gradeName": "一年级", "meaning": "颜色", "pos": "n."}, {"id": "pep_056", "word": "one", "phonetic": "/wʌn/", "syllables": ["one"], "chinese": "一", "grade": 1, "unit": "数字与计数", "example": "I have one apple.", "gradeName": "一年级", "meaning": "一", "pos": "n."}, {"id": "pep_057", "word": "two", "phonetic": "/tuː/", "syllables": ["two"], "chinese": "二", "grade": 1, "unit": "数字与计数", "example": "Two birds are flying.", "gradeName": "一年级", "meaning": "二", "pos": "n."}, {"id": "pep_058", "word": "three", "phonetic": "/θriː/", "syllables": ["three"], "chinese": "三", "grade": 1, "unit": "数字与计数", "example": "There are three pens.", "gradeName": "一年级", "meaning": "三", "pos": "n."}, {"id": "pep_059", "word": "four", "phonetic": "/fɔː(r)/", "syllables": ["four"], "chinese": "四", "grade": 1, "unit": "数字与计数", "example": "Four students are reading.", "gradeName": "一年级", "meaning": "四", "pos": "n."}, {"id": "pep_060", "word": "five", "phonetic": "/faɪv/", "syllables": ["five"], "chinese": "五", "grade": 1, "unit": "数字与计数", "example": "Give me high five!", "gradeName": "一年级", "meaning": "五", "pos": "n."}, {"id": "pep_061", "word": "six", "phonetic": "/sɪks/", "syllables": ["six"], "chinese": "六", "grade": 1, "unit": "数字与计数", "example": "She is six years old.", "gradeName": "一年级", "meaning": "六", "pos": "n."}, {"id": "pep_062", "word": "seven", "phonetic": "/ˈsevn/", "syllables": ["sev", "en"], "chinese": "七", "grade": 1, "unit": "数字与计数", "example": "A week has seven days.", "gradeName": "一年级", "meaning": "七", "pos": "n."}, {"id": "pep_063", "word": "eight", "phonetic": "/eɪt/", "syllables": ["eight"], "chinese": "八", "grade": 1, "unit": "数字与计数", "example": "Eight desks are in a row.", "gradeName": "一年级", "meaning": "八", "pos": "n."}, {"id": "pep_064", "word": "nine", "phonetic": "/naɪn/", "syllables": ["nine"], "chinese": "九", "grade": 1, "unit": "数字与计数", "example": "Nine stars shine in the night.", "gradeName": "一年级", "meaning": "九", "pos": "n."}, {"id": "pep_065", "word": "ten", "phonetic": "/ten/", "syllables": ["ten"], "chinese": "十", "grade": 1, "unit": "数字与计数", "example": "Count from one to ten.", "gradeName": "一年级", "meaning": "十", "pos": "n."}, {"id": "pep_066", "word": "eleven", "phonetic": "/ɪˈlevn/", "syllables": ["e", "lev", "en"], "chinese": "十一", "grade": 2, "unit": "数字与计数", "example": "There are eleven football players.", "gradeName": "二年级", "meaning": "十一", "pos": "n."}, {"id": "pep_067", "word": "twelve", "phonetic": "/twelv/", "syllables": ["twelve"], "chinese": "十二", "grade": 2, "unit": "数字与计数", "example": "A year has twelve months.", "gradeName": "二年级", "meaning": "十二", "pos": "n."}, {"id": "pep_068", "word": "thirteen", "phonetic": "/ˌθɜːˈtiːn/", "syllables": ["thir", "teen"], "chinese": "十三", "grade": 2, "unit": "数字与计数", "example": "Thirteen is an interesting number.", "gradeName": "二年级", "meaning": "十三", "pos": "n."}, {"id": "pep_069", "word": "fourteen", "phonetic": "/ˌfɔːˈtiːn/", "syllables": ["four", "teen"], "chinese": "十四", "grade": 2, "unit": "数字与计数", "example": "Count to fourteen carefully.", "gradeName": "二年级", "meaning": "十四", "pos": "n."}, {"id": "pep_070", "word": "fifteen", "phonetic": "/ˌfɪfˈtiːn/", "syllables": ["fif", "teen"], "chinese": "十五", "grade": 2, "unit": "数字与计数", "example": "Fifteen minutes makes a quarter.", "gradeName": "二年级", "meaning": "十五", "pos": "n."}, {"id": "pep_071", "word": "sixteen", "phonetic": "/ˌsɪksˈtiːn/", "syllables": ["six", "teen"], "chinese": "十六", "grade": 2, "unit": "数字与计数", "example": "She is sixteen years old.", "gradeName": "二年级", "meaning": "十六", "pos": "n."}, {"id": "pep_072", "word": "seventeen", "phonetic": "/ˌsevnˈtiːn/", "syllables": ["sev", "en", "teen"], "chinese": "十七", "grade": 2, "unit": "数字与计数", "example": "Seventeen flowers bloom.", "gradeName": "二年级", "meaning": "十七", "pos": "n."}, {"id": "pep_073", "word": "eighteen", "phonetic": "/ˌeɪˈtiːn/", "syllables": ["eigh", "teen"], "chinese": "十八", "grade": 2, "unit": "数字与计数", "example": "Eighteen students passed.", "gradeName": "二年级", "meaning": "十八", "pos": "n."}, {"id": "pep_074", "word": "nineteen", "phonetic": "/ˌnaɪnˈtiːn/", "syllables": ["nine", "teen"], "chinese": "十九", "grade": 2, "unit": "数字与计数", "example": "Nineteen apples in the basket.", "gradeName": "二年级", "meaning": "十九", "pos": "n."}, {"id": "pep_075", "word": "twenty", "phonetic": "/ˈtwenti/", "syllables": ["twen", "ty"], "chinese": "二十", "grade": 2, "unit": "数字与计数", "example": "Twenty birds fly south.", "gradeName": "二年级", "meaning": "二十", "pos": "n."}, {"id": "pep_076", "word": "thirty", "phonetic": "/ˈθɜːti/", "syllables": ["thir", "ty"], "chinese": "三十", "grade": 2, "unit": "数字与计数", "example": "Thirty days has September.", "gradeName": "二年级", "meaning": "三十", "pos": "n."}, {"id": "pep_077", "word": "forty", "phonetic": "/ˈfɔːti/", "syllables": ["for", "ty"], "chinese": "四十", "grade": 2, "unit": "数字与计数", "example": "Forty minutes per class.", "gradeName": "二年级", "meaning": "四十", "pos": "n."}, {"id": "pep_078", "word": "fifty", "phonetic": "/ˈfɪfti/", "syllables": ["fif", "ty"], "chinese": "五十", "grade": 2, "unit": "数字与计数", "example": "Fifty stars on the flag.", "gradeName": "二年级", "meaning": "五十", "pos": "n."}, {"id": "pep_079", "word": "sixty", "phonetic": "/ˈsɪksti/", "syllables": ["six", "ty"], "chinese": "六十", "grade": 2, "unit": "数字与计数", "example": "Sixty seconds make a minute.", "gradeName": "二年级", "meaning": "六十", "pos": "n."}, {"id": "pep_080", "word": "seventy", "phonetic": "/ˈsevnti/", "syllables": ["sev", "en", "ty"], "chinese": "七十", "grade": 2, "unit": "数字与计数", "example": "Seventy pages in this book.", "gradeName": "二年级", "meaning": "七十", "pos": "n."}, {"id": "pep_081", "word": "eighty", "phonetic": "/ˈeɪti/", "syllables": ["eigh", "ty"], "chinese": "八十", "grade": 2, "unit": "数字与计数", "example": "Eighty meters broad river.", "gradeName": "二年级", "meaning": "八十", "pos": "n."}, {"id": "pep_082", "word": "ninety", "phonetic": "/ˈnaɪnti/", "syllables": ["nine", "ty"], "chinese": "九十", "grade": 2, "unit": "数字与计数", "example": "Score ninety points in test.", "gradeName": "二年级", "meaning": "九十", "pos": "n."}, {"id": "pep_083", "word": "hundred", "phonetic": "/ˈhʌndrəd/", "syllables": ["hun", "dred"], "chinese": "一百", "grade": 2, "unit": "数字与计数", "example": "A hundred percent effort.", "gradeName": "二年级", "meaning": "一百", "pos": "n."}, {"id": "pep_084", "word": "thousand", "phonetic": "/ˈθaʊznd/", "syllables": ["thou", "sand"], "chinese": "一千", "grade": 4, "unit": "数字与计数", "example": "A journey of a thousand miles begins with a single step.", "gradeName": "四年级", "meaning": "一千", "pos": "n."}, {"id": "pep_085", "word": "first", "phonetic": "/fɜːst/", "syllables": ["first"], "chinese": "第一", "grade": 3, "unit": "数字与计数", "example": "Safety comes first.", "gradeName": "三年级", "meaning": "第一", "pos": "n."}, {"id": "pep_086", "word": "second", "phonetic": "/ˈsekənd/", "syllables": ["sec", "ond"], "chinese": "第二；秒", "grade": 3, "unit": "数字与计数", "example": "He won the second prize.", "gradeName": "三年级", "meaning": "第二；秒", "pos": "n."}, {"id": "pep_087", "word": "third", "phonetic": "/θɜːd/", "syllables": ["third"], "chinese": "第三", "grade": 3, "unit": "数字与计数", "example": "The classroom is on the third floor.", "gradeName": "三年级", "meaning": "第三", "pos": "n."}, {"id": "pep_088", "word": "fourth", "phonetic": "/fɔːθ/", "syllables": ["fourth"], "chinese": "第四", "grade": 3, "unit": "数字与计数", "example": "Today is the fourth of July.", "gradeName": "三年级", "meaning": "第四", "pos": "n."}, {"id": "pep_089", "word": "fifth", "phonetic": "/fɪfθ/", "syllables": ["fifth"], "chinese": "第五", "grade": 3, "unit": "数字与计数", "example": "She came in fifth place.", "gradeName": "三年级", "meaning": "第五", "pos": "n."}, {"id": "pep_090", "word": "number", "phonetic": "/ˈnʌmbə(r)/", "syllables": ["num", "ber"], "chinese": "数字；号码", "grade": 2, "unit": "数字与计数", "example": "What is your telephone number?", "gradeName": "二年级", "meaning": "数字；号码", "pos": "n."}, {"id": "pep_091", "word": "eye", "phonetic": "/aɪ/", "syllables": ["eye"], "chinese": "眼睛", "grade": 1, "unit": "身体与健康", "example": "Open your eyes.", "gradeName": "一年级", "meaning": "眼睛", "pos": "n."}, {"id": "pep_092", "word": "nose", "phonetic": "/nəʊz/", "syllables": ["nose"], "chinese": "鼻子", "grade": 1, "unit": "身体与健康", "example": "Touch your nose.", "gradeName": "一年级", "meaning": "鼻子", "pos": "n."}, {"id": "pep_093", "word": "mouth", "phonetic": "/maʊθ/", "syllables": ["mouth"], "chinese": "嘴巴", "grade": 1, "unit": "身体与健康", "example": "Open your mouth wide.", "gradeName": "一年级", "meaning": "嘴巴", "pos": "n."}, {"id": "pep_094", "word": "ear", "phonetic": "/ɪə(r)/", "syllables": ["ear"], "chinese": "耳朵", "grade": 1, "unit": "身体与健康", "example": "Listen with your ears.", "gradeName": "一年级", "meaning": "耳朵", "pos": "n."}, {"id": "pep_095", "word": "face", "phonetic": "/feɪs/", "syllables": ["face"], "chinese": "脸庞；面孔", "grade": 1, "unit": "身体与健康", "example": "Wash your face every morning.", "gradeName": "一年级", "meaning": "脸庞；面孔", "pos": "n."}, {"id": "pep_096", "word": "head", "phonetic": "/hed/", "syllables": ["head"], "chinese": "头；头部", "grade": 1, "unit": "身体与健康", "example": "Nod your head.", "gradeName": "一年级", "meaning": "头；头部", "pos": "n."}, {"id": "pep_097", "word": "hair", "phonetic": "/heə(r)/", "syllables": ["hair"], "chinese": "头发", "grade": 1, "unit": "身体与健康", "example": "Comb your black hair.", "gradeName": "一年级", "meaning": "头发", "pos": "n."}, {"id": "pep_098", "word": "arm", "phonetic": "/ɑːm/", "syllables": ["arm"], "chinese": "胳膊；手臂", "grade": 1, "unit": "身体与健康", "example": "Wave your arms.", "gradeName": "一年级", "meaning": "胳膊；手臂", "pos": "n."}, {"id": "pep_099", "word": "hand", "phonetic": "/hænd/", "syllables": ["hand"], "chinese": "手", "grade": 1, "unit": "身体与健康", "example": "Clap your hands.", "gradeName": "一年级", "meaning": "手", "pos": "n."}, {"id": "pep_100", "word": "leg", "phonetic": "/leɡ/", "syllables": ["leg"], "chinese": "腿", "grade": 1, "unit": "身体与健康", "example": "Shake your legs.", "gradeName": "一年级", "meaning": "腿", "pos": "n."}, {"id": "pep_101", "word": "foot", "phonetic": "/fʊt/", "syllables": ["foot"], "chinese": "脚（单数）", "grade": 1, "unit": "身体与健康", "example": "Stamp your foot.", "gradeName": "一年级", "meaning": "脚（单数）", "pos": "n."}, {"id": "pep_102", "word": "feet", "phonetic": "/fiːt/", "syllables": ["feet"], "chinese": "双脚（复数）", "grade": 1, "unit": "身体与健康", "example": "Wash your feet.", "gradeName": "一年级", "meaning": "双脚（复数）", "pos": "n."}, {"id": "pep_103", "word": "body", "phonetic": "/ˈbɒdi/", "syllables": ["bod", "y"], "chinese": "身体", "grade": 1, "unit": "身体与健康", "example": "Exercise makes a strong body.", "gradeName": "一年级", "meaning": "身体", "pos": "n."}, {"id": "pep_104", "word": "finger", "phonetic": "/ˈfɪŋɡə(r)/", "syllables": ["fin", "ger"], "chinese": "手指", "grade": 1, "unit": "身体与健康", "example": "Count on your fingers.", "gradeName": "一年级", "meaning": "手指", "pos": "n."}, {"id": "pep_105", "word": "toe", "phonetic": "/təʊ/", "syllables": ["toe"], "chinese": "脚趾", "grade": 1, "unit": "身体与健康", "example": "Wiggle your toes.", "gradeName": "一年级", "meaning": "脚趾", "pos": "n."}, {"id": "pep_106", "word": "knee", "phonetic": "/niː/", "syllables": ["knee"], "chinese": "膝盖", "grade": 1, "unit": "身体与健康", "example": "Bend your knees.", "gradeName": "一年级", "meaning": "膝盖", "pos": "n."}, {"id": "pep_107", "word": "shoulder", "phonetic": "/ˈʃəʊldə(r)/", "syllables": ["shoul", "der"], "chinese": "肩膀", "grade": 2, "unit": "身体与健康", "example": "Touch your shoulders.", "gradeName": "二年级", "meaning": "肩膀", "pos": "n."}, {"id": "pep_108", "word": "tooth", "phonetic": "/tuːθ/", "syllables": ["tooth"], "chinese": "牙齿（单数）", "grade": 2, "unit": "身体与健康", "example": "Brush every single tooth.", "gradeName": "二年级", "meaning": "牙齿（单数）", "pos": "n."}, {"id": "pep_109", "word": "teeth", "phonetic": "/tiːθ/", "syllables": ["teeth"], "chinese": "牙齿（复数）", "grade": 2, "unit": "身体与健康", "example": "Keep your teeth clean.", "gradeName": "二年级", "meaning": "牙齿（复数）", "pos": "n."}, {"id": "pep_110", "word": "neck", "phonetic": "/nek/", "syllables": ["neck"], "chinese": "脖子；颈部", "grade": 2, "unit": "身体与健康", "example": "Giraffes have a long neck.", "gradeName": "二年级", "meaning": "脖子；颈部", "pos": "n."}, {"id": "pep_111", "word": "back", "phonetic": "/bæk/", "syllables": ["back"], "chinese": "背部；后面", "grade": 3, "unit": "身体与健康", "example": "Sit with your back straight.", "gradeName": "三年级", "meaning": "背部；后面", "pos": "n."}, {"id": "pep_112", "word": "stomach", "phonetic": "/ˈstʌmək/", "syllables": ["stom", "ach"], "chinese": "胃；腹部", "grade": 4, "unit": "身体与健康", "example": "My stomach feels full.", "gradeName": "四年级", "meaning": "胃；腹部", "pos": "n."}, {"id": "pep_113", "word": "heart", "phonetic": "/hɑːt/", "syllables": ["heart"], "chinese": "心脏；心愿", "grade": 4, "unit": "身体与健康", "example": "A kind and generous heart.", "gradeName": "四年级", "meaning": "心脏；心愿", "pos": "n."}, {"id": "pep_114", "word": "cold", "phonetic": "/kəʊld/", "syllables": ["cold"], "chinese": "感冒；寒冷", "grade": 3, "unit": "身体与健康", "example": "He caught a bad cold.", "gradeName": "三年级", "meaning": "感冒；寒冷", "pos": "n."}, {"id": "pep_115", "word": "fever", "phonetic": "/ˈfiːvə(r)/", "syllables": ["fe", "ver"], "chinese": "发烧；发热", "grade": 4, "unit": "身体与健康", "example": "Take medicine when you have a fever.", "gradeName": "四年级", "meaning": "发烧；发热", "pos": "n."}, {"id": "pep_116", "word": "father", "phonetic": "/ˈfɑːðə(r)/", "syllables": ["fa", "ther"], "chinese": "父亲；爸爸", "grade": 1, "unit": "温馨家庭", "example": "My father is very strong.", "gradeName": "一年级", "meaning": "父亲；爸爸", "pos": "n."}, {"id": "pep_117", "word": "mother", "phonetic": "/ˈmʌðə(r)/", "syllables": ["moth", "er"], "chinese": "母亲；妈妈", "grade": 1, "unit": "温馨家庭", "example": "My mother cooks delicious food.", "gradeName": "一年级", "meaning": "母亲；妈妈", "pos": "n."}, {"id": "pep_118", "word": "dad", "phonetic": "/dæd/", "syllables": ["dad"], "chinese": "爸爸（口语）", "grade": 1, "unit": "温馨家庭", "example": "Dad, let's play catch!", "gradeName": "一年级", "meaning": "爸爸（口语）", "pos": "n."}, {"id": "pep_119", "word": "mum", "phonetic": "/mʌm/", "syllables": ["mum"], "chinese": "妈妈（口语）", "grade": 1, "unit": "温馨家庭", "example": "Mum helps me learn English.", "gradeName": "一年级", "meaning": "妈妈（口语）", "pos": "n."}, {"id": "pep_120", "word": "brother", "phonetic": "/ˈbrʌðə(r)/", "syllables": ["broth", "er"], "chinese": "哥哥；弟弟", "grade": 1, "unit": "温馨家庭", "example": "My brother plays soccer.", "gradeName": "一年级", "meaning": "哥哥；弟弟", "pos": "n."}, {"id": "pep_121", "word": "sister", "phonetic": "/ˈsɪstə(r)/", "syllables": ["sis", "ter"], "chinese": "姐姐；妹妹", "grade": 1, "unit": "温馨家庭", "example": "My sister likes drawing.", "gradeName": "一年级", "meaning": "姐姐；妹妹", "pos": "n."}, {"id": "pep_122", "word": "grandfather", "phonetic": "/ˈɡrænfɑːðə(r)/", "syllables": ["grand", "fa", "ther"], "chinese": "祖父；外公", "grade": 1, "unit": "温馨家庭", "example": "My grandfather tells stories.", "gradeName": "一年级", "meaning": "祖父；外公", "pos": "n."}, {"id": "pep_123", "word": "grandmother", "phonetic": "/ˈɡrænmʌðə(r)/", "syllables": ["grand", "moth", "er"], "chinese": "祖母；外婆", "grade": 1, "unit": "温馨家庭", "example": "My grandmother bakes pies.", "gradeName": "一年级", "meaning": "祖母；外婆", "pos": "n."}, {"id": "pep_124", "word": "grandpa", "phonetic": "/ˈɡrænpɑː/", "syllables": ["grand", "pa"], "chinese": "爷爷；外公", "grade": 1, "unit": "温馨家庭", "example": "Grandpa waters flowers.", "gradeName": "一年级", "meaning": "爷爷；外公", "pos": "n."}, {"id": "pep_125", "word": "grandma", "phonetic": "/ˈɡrænmɑː/", "syllables": ["grand", "ma"], "chinese": "奶奶；外婆", "grade": 1, "unit": "温馨家庭", "example": "Grandma knits warm gloves.", "gradeName": "一年级", "meaning": "奶奶；外婆", "pos": "n."}, {"id": "pep_126", "word": "parent", "phonetic": "/ˈpeərənt/", "syllables": ["par", "ent"], "chinese": "父亲或母亲", "grade": 3, "unit": "温馨家庭", "example": "Respect your parents.", "gradeName": "三年级", "meaning": "父亲或母亲", "pos": "n."}, {"id": "pep_127", "word": "parents", "phonetic": "/ˈpeərənts/", "syllables": ["par", "ents"], "chinese": "父母亲", "grade": 3, "unit": "温馨家庭", "example": "My parents encourage me.", "gradeName": "三年级", "meaning": "父母亲", "pos": "n."}, {"id": "pep_128", "word": "uncle", "phonetic": "/ˈʌŋkl/", "syllables": ["un", "cle"], "chinese": "叔叔；伯伯；舅舅", "grade": 2, "unit": "温馨家庭", "example": "My uncle lives in Beijing.", "gradeName": "二年级", "meaning": "叔叔；伯伯；舅舅", "pos": "n."}, {"id": "pep_129", "word": "aunt", "phonetic": "/ɑːnt/", "syllables": ["aunt"], "chinese": "姑姑；阿姨；婶婶", "grade": 2, "unit": "温馨家庭", "example": "Aunt Mary brings gifts.", "gradeName": "二年级", "meaning": "姑姑；阿姨；婶婶", "pos": "n."}, {"id": "pep_130", "word": "cousin", "phonetic": "/ˈkʌzn/", "syllables": ["cous", "in"], "chinese": "堂（表）兄弟姐妹", "grade": 3, "unit": "温馨家庭", "example": "Play chess with my cousin.", "gradeName": "三年级", "meaning": "堂（表）兄弟姐妹", "pos": "n."}, {"id": "pep_131", "word": "baby", "phonetic": "/ˈbeɪbi/", "syllables": ["ba", "by"], "chinese": "婴儿；幼崽", "grade": 2, "unit": "温馨家庭", "example": "The baby is fast asleep.", "gradeName": "二年级", "meaning": "婴儿；幼崽", "pos": "n."}, {"id": "pep_132", "word": "son", "phonetic": "/sʌn/", "syllables": ["son"], "chinese": "儿子", "grade": 4, "unit": "温馨家庭", "example": "He is proud of his son.", "gradeName": "四年级", "meaning": "儿子", "pos": "n."}, {"id": "pep_133", "word": "daughter", "phonetic": "/ˈdɔːtə(r)/", "syllables": ["daugh", "ter"], "chinese": "女儿", "grade": 4, "unit": "温馨家庭", "example": "Their daughter plays violin.", "gradeName": "四年级", "meaning": "女儿", "pos": "n."}, {"id": "pep_134", "word": "boy", "phonetic": "/bɔɪ/", "syllables": ["boy"], "chinese": "男孩", "grade": 1, "unit": "温馨家庭", "example": "The boy is running fast.", "gradeName": "一年级", "meaning": "男孩", "pos": "n."}, {"id": "pep_135", "word": "girl", "phonetic": "/ɡɜːl/", "syllables": ["girl"], "chinese": "女孩", "grade": 1, "unit": "温馨家庭", "example": "The girl dances gracefully.", "gradeName": "一年级", "meaning": "女孩", "pos": "n."}, {"id": "pep_136", "word": "man", "phonetic": "/mæn/", "syllables": ["man"], "chinese": "男人；成年男子", "grade": 1, "unit": "温馨家庭", "example": "The man carries a heavy box.", "gradeName": "一年级", "meaning": "男人；成年男子", "pos": "n."}, {"id": "pep_137", "word": "men", "phonetic": "/men/", "syllables": ["men"], "chinese": "男人（复数）", "grade": 3, "unit": "温馨家庭", "example": "Three men working together.", "gradeName": "三年级", "meaning": "男人（复数）", "pos": "n."}, {"id": "pep_138", "word": "woman", "phonetic": "/ˈwʊmən/", "syllables": ["wom", "an"], "chinese": "女人；成年女子", "grade": 1, "unit": "温馨家庭", "example": "The woman is our teacher.", "gradeName": "一年级", "meaning": "女人；成年女子", "pos": "n."}, {"id": "pep_139", "word": "women", "phonetic": "/ˈwɪmɪn/", "syllables": ["wom", "en"], "chinese": "女人（复数）", "grade": 3, "unit": "温馨家庭", "example": "Smart women leaders.", "gradeName": "三年级", "meaning": "女人（复数）", "pos": "n."}, {"id": "pep_140", "word": "child", "phonetic": "/tʃaɪld/", "syllables": ["child"], "chinese": "儿童；孩子（单数）", "grade": 3, "unit": "温馨家庭", "example": "Every child is unique.", "gradeName": "三年级", "meaning": "儿童；孩子（单数）", "pos": "n."}, {"id": "pep_141", "word": "children", "phonetic": "/ˈtʃɪldrən/", "syllables": ["chil", "dren"], "chinese": "孩子们（复数）", "grade": 3, "unit": "温馨家庭", "example": "Children laugh happily.", "gradeName": "三年级", "meaning": "孩子们（复数）", "pos": "n."}, {"id": "pep_142", "word": "kid", "phonetic": "/kɪd/", "syllables": ["kid"], "chinese": "小孩子", "grade": 2, "unit": "温馨家庭", "example": "Kids play on swings.", "gradeName": "二年级", "meaning": "小孩子", "pos": "adj."}, {"id": "pep_143", "word": "people", "phonetic": "/ˈpiːpl/", "syllables": ["peo", "ple"], "chinese": "人；人们", "grade": 3, "unit": "温馨家庭", "example": "Many people visit the park.", "gradeName": "三年级", "meaning": "人；人们", "pos": "n."}, {"id": "pep_144", "word": "friend", "phonetic": "/frend/", "syllables": ["friend"], "chinese": "朋友", "grade": 1, "unit": "温馨家庭", "example": "A loyal friend is a treasure.", "gradeName": "一年级", "meaning": "朋友", "pos": "n."}, {"id": "pep_145", "word": "classmate", "phonetic": "/ˈklɑːsmeɪt/", "syllables": ["class", "mate"], "chinese": "同班同学", "grade": 2, "unit": "温馨家庭", "example": "Help your classmates cheerfully.", "gradeName": "二年级", "meaning": "同班同学", "pos": "adj."}, {"id": "pep_146", "word": "book", "phonetic": "/bʊk/", "syllables": ["book"], "chinese": "书；书籍", "grade": 1, "unit": "校园文具", "example": "Open your book, please.", "gradeName": "一年级", "meaning": "书；书籍", "pos": "n."}, {"id": "pep_147", "word": "ruler", "phonetic": "/ˈruːlə(r)/", "syllables": ["ru", "ler"], "chinese": "尺子", "grade": 1, "unit": "校园文具", "example": "I have a green ruler.", "gradeName": "一年级", "meaning": "尺子", "pos": "n."}, {"id": "pep_148", "word": "pencil", "phonetic": "/ˈpensl/", "syllables": ["pen", "cil"], "chinese": "铅笔", "grade": 1, "unit": "校园文具", "example": "Sharpen your pencil.", "gradeName": "一年级", "meaning": "铅笔", "pos": "n."}, {"id": "pep_149", "word": "eraser", "phonetic": "/ɪˈreɪzə(r)/", "syllables": ["e", "ra", "ser"], "chinese": "橡皮擦", "grade": 1, "unit": "校园文具", "example": "Use an eraser to fix it.", "gradeName": "一年级", "meaning": "橡皮擦", "pos": "n."}, {"id": "pep_150", "word": "pen", "phonetic": "/pen/", "syllables": ["pen"], "chinese": "钢笔；圆珠笔", "grade": 1, "unit": "校园文具", "example": "Write with a blue pen.", "gradeName": "一年级", "meaning": "钢笔；圆珠笔", "pos": "n."}, {"id": "pep_151", "word": "bag", "phonetic": "/bæɡ/", "syllables": ["bag"], "chinese": "书包；袋子", "grade": 1, "unit": "校园文具", "example": "Put the book into the bag.", "gradeName": "一年级", "meaning": "书包；袋子", "pos": "n."}, {"id": "pep_152", "word": "schoolbag", "phonetic": "/ˈskuːlbæɡ/", "syllables": ["school", "bag"], "chinese": "书包", "grade": 1, "unit": "校园文具", "example": "My schoolbag is heavy.", "gradeName": "一年级", "meaning": "书包", "pos": "n."}, {"id": "pep_153", "word": "crayon", "phonetic": "/ˈkreɪən/", "syllables": ["cray", "on"], "chinese": "蜡笔", "grade": 1, "unit": "校园文具", "example": "Draw flowers with crayons.", "gradeName": "一年级", "meaning": "蜡笔", "pos": "n."}, {"id": "pep_154", "word": "sharpener", "phonetic": "/ˈʃɑːpnə(r)/", "syllables": ["sharp", "en", "er"], "chinese": "卷笔刀", "grade": 1, "unit": "校园文具", "example": "May I borrow your sharpener?", "gradeName": "一年级", "meaning": "卷笔刀", "pos": "n."}, {"id": "pep_155", "word": "pencil-box", "phonetic": "/ˈpensl bɒks/", "syllables": ["pen", "cil", "box"], "chinese": "铅笔盒", "grade": 1, "unit": "校园文具", "example": "My pencil-box is on the desk.", "gradeName": "一年级", "meaning": "铅笔盒", "pos": "n."}, {"id": "pep_156", "word": "desk", "phonetic": "/desk/", "syllables": ["desk"], "chinese": "书桌", "grade": 1, "unit": "校园文具", "example": "Clean your desk.", "gradeName": "一年级", "meaning": "书桌", "pos": "n."}, {"id": "pep_157", "word": "chair", "phonetic": "/tʃeə(r)/", "syllables": ["chair"], "chinese": "椅子", "grade": 1, "unit": "校园文具", "example": "Sit on the chair.", "gradeName": "一年级", "meaning": "椅子", "pos": "n."}, {"id": "pep_158", "word": "blackboard", "phonetic": "/ˈblækbɔːd/", "syllables": ["black", "board"], "chinese": "黑板", "grade": 1, "unit": "校园文具", "example": "Look at the blackboard.", "gradeName": "一年级", "meaning": "黑板", "pos": "adj."}, {"id": "pep_159", "word": "paper", "phonetic": "/ˈpeɪpə(r)/", "syllables": ["pa", "per"], "chinese": "纸张", "grade": 1, "unit": "校园文具", "example": "Write on clean white paper.", "gradeName": "一年级", "meaning": "纸张", "pos": "n."}, {"id": "pep_160", "word": "scissors", "phonetic": "/ˈsɪzəz/", "syllables": ["scis", "sors"], "chinese": "剪刀", "grade": 2, "unit": "校园文具", "example": "Be careful with sharp scissors.", "gradeName": "二年级", "meaning": "剪刀", "pos": "n."}, {"id": "pep_161", "word": "glue", "phonetic": "/ɡluː/", "syllables": ["glue"], "chinese": "胶水", "grade": 2, "unit": "校园文具", "example": "Paste paper with glue.", "gradeName": "二年级", "meaning": "胶水", "pos": "n."}, {"id": "pep_162", "word": "notebook", "phonetic": "/ˈnəʊtbʊk/", "syllables": ["note", "book"], "chinese": "笔记本", "grade": 2, "unit": "校园文具", "example": "Take notes in your notebook.", "gradeName": "二年级", "meaning": "笔记本", "pos": "n."}, {"id": "pep_163", "word": "marker", "phonetic": "/ˈmɑːkə(r)/", "syllables": ["mar", "ker"], "chinese": "马克笔", "grade": 2, "unit": "校园文具", "example": "Color posters with markers.", "gradeName": "二年级", "meaning": "马克笔", "pos": "n."}, {"id": "pep_164", "word": "school", "phonetic": "/skuːl/", "syllables": ["school"], "chinese": "学校", "grade": 1, "unit": "校园文具", "example": "Walk to school every day.", "gradeName": "一年级", "meaning": "学校", "pos": "v."}, {"id": "pep_165", "word": "classroom", "phonetic": "/ˈklɑːsruːm/", "syllables": ["class", "room"], "chinese": "教室", "grade": 1, "unit": "校园文具", "example": "Keep the classroom quiet.", "gradeName": "一年级", "meaning": "教室", "pos": "v."}, {"id": "pep_166", "word": "teacher", "phonetic": "/ˈtiːtʃə(r)/", "syllables": ["teach", "er"], "chinese": "老师", "grade": 1, "unit": "校园文具", "example": "Respect your teacher.", "gradeName": "一年级", "meaning": "老师", "pos": "n."}, {"id": "pep_167", "word": "student", "phonetic": "/ˈstjuːdnt/", "syllables": ["stu", "dent"], "chinese": "学生", "grade": 1, "unit": "校园文具", "example": "Diligent students learn fast.", "gradeName": "一年级", "meaning": "学生", "pos": "v."}, {"id": "pep_168", "word": "class", "phonetic": "/klɑːs/", "syllables": ["class"], "chinese": "班级；课程", "grade": 1, "unit": "校园文具", "example": "Class begins at eight.", "gradeName": "一年级", "meaning": "班级；课程", "pos": "n."}, {"id": "pep_169", "word": "lesson", "phonetic": "/ˈlesn/", "syllables": ["les", "son"], "chinese": "功课；课", "grade": 2, "unit": "校园文具", "example": "Review your lesson carefully.", "gradeName": "二年级", "meaning": "功课；课", "pos": "n."}, {"id": "pep_170", "word": "homework", "phonetic": "/ˈhəʊmwɜːk/", "syllables": ["home", "work"], "chinese": "家庭作业", "grade": 2, "unit": "校园文具", "example": "Finish your homework on time.", "gradeName": "二年级", "meaning": "家庭作业", "pos": "n."}, {"id": "pep_171", "word": "English", "phonetic": "/ˈɪŋɡlɪʃ/", "syllables": ["Eng", "lish"], "chinese": "英语；英文", "grade": 3, "unit": "校园课程", "example": "Practice English every day.", "gradeName": "三年级", "meaning": "英语；英文", "pos": "n."}, {"id": "pep_172", "word": "Chinese", "phonetic": "/ˌtʃaɪˈniːz/", "syllables": ["Chi", "nese"], "chinese": "语文；中文", "grade": 3, "unit": "校园课程", "example": "Chinese culture is profound.", "gradeName": "三年级", "meaning": "语文；中文", "pos": "n."}, {"id": "pep_173", "word": "maths", "phonetic": "/mæθs/", "syllables": ["maths"], "chinese": "数学", "grade": 3, "unit": "校园课程", "example": "Maths trains logical thinking.", "gradeName": "三年级", "meaning": "数学", "pos": "n."}, {"id": "pep_174", "word": "science", "phonetic": "/ˈsaɪəns/", "syllables": ["sci", "ence"], "chinese": "科学", "grade": 3, "unit": "校园课程", "example": "Science unlocks world wonders.", "gradeName": "三年级", "meaning": "科学", "pos": "n."}, {"id": "pep_175", "word": "music", "phonetic": "/ˈmjuːzɪk/", "syllables": ["mu", "sic"], "chinese": "音乐", "grade": 3, "unit": "校园课程", "example": "Music calms restless minds.", "gradeName": "三年级", "meaning": "音乐", "pos": "n."}, {"id": "pep_176", "word": "art", "phonetic": "/ɑːt/", "syllables": ["art"], "chinese": "美术；艺术", "grade": 3, "unit": "校园课程", "example": "Paint vivid landscapes in art.", "gradeName": "三年级", "meaning": "美术；艺术", "pos": "adj."}, {"id": "pep_177", "word": "PE", "phonetic": "/ˌpiː ˈiː/", "syllables": ["P", "E"], "chinese": "体育课", "grade": 3, "unit": "校园课程", "example": "We play basketball in PE.", "gradeName": "三年级", "meaning": "体育课", "pos": "n."}, {"id": "pep_178", "word": "history", "phonetic": "/ˈhɪstri/", "syllables": ["his", "to", "ry"], "chinese": "历史", "grade": 5, "unit": "校园课程", "example": "Learn lessons from history.", "gradeName": "五年级", "meaning": "历史", "pos": "n."}, {"id": "pep_179", "word": "subject", "phonetic": "/ˈsʌbdʒɪkt/", "syllables": ["sub", "ject"], "chinese": "学科；科目", "grade": 3, "unit": "校园课程", "example": "What is your favorite subject?", "gradeName": "三年级", "meaning": "学科；科目", "pos": "v."}, {"id": "pep_180", "word": "library", "phonetic": "/ˈlaɪbrəri/", "syllables": ["li", "brar", "y"], "chinese": "图书馆", "grade": 2, "unit": "校园设施", "example": "Read quiet books in the library.", "gradeName": "二年级", "meaning": "图书馆", "pos": "n."}, {"id": "pep_181", "word": "playground", "phonetic": "/ˈpleɪɡraʊnd/", "syllables": ["play", "ground"], "chinese": "操场", "grade": 2, "unit": "校园设施", "example": "Run freely on the playground.", "gradeName": "二年级", "meaning": "操场", "pos": "n."}, {"id": "pep_182", "word": "gym", "phonetic": "/dʒɪm/", "syllables": ["gym"], "chinese": "体育馆；健身房", "grade": 3, "unit": "校园设施", "example": "Play badminton in gym.", "gradeName": "三年级", "meaning": "体育馆；健身房", "pos": "n."}, {"id": "pep_183", "word": "canteen", "phonetic": "/kænˈtiːn/", "syllables": ["can", "teen"], "chinese": "食堂", "grade": 2, "unit": "校园设施", "example": "Line up for lunch at canteen.", "gradeName": "二年级", "meaning": "食堂", "pos": "n."}, {"id": "pep_184", "word": "office", "phonetic": "/ˈɒfɪs/", "syllables": ["of", "fice"], "chinese": "办公室", "grade": 3, "unit": "校园设施", "example": "Teachers work in the office.", "gradeName": "三年级", "meaning": "办公室", "pos": "n."}, {"id": "pep_185", "word": "hall", "phonetic": "/hɔːl/", "syllables": ["hall"], "chinese": "礼堂；大厅", "grade": 4, "unit": "校园设施", "example": "School assembly in the hall.", "gradeName": "四年级", "meaning": "礼堂；大厅", "pos": "adj."}, {"id": "pep_186", "word": "lab", "phonetic": "/læb/", "syllables": ["lab"], "chinese": "实验室", "grade": 5, "unit": "校园设施", "example": "Chemistry experiment in lab.", "gradeName": "五年级", "meaning": "实验室", "pos": "n."}, {"id": "pep_187", "word": "grade", "phonetic": "/ɡreɪd/", "syllables": ["grade"], "chinese": "年级；成绩", "grade": 2, "unit": "校园生活", "example": "I am in third grade.", "gradeName": "二年级", "meaning": "年级；成绩", "pos": "adj."}, {"id": "pep_188", "word": "term", "phonetic": "/tɜːm/", "syllables": ["term"], "chinese": "学期", "grade": 4, "unit": "校园生活", "example": "A brand new school term.", "gradeName": "四年级", "meaning": "学期", "pos": "v."}, {"id": "pep_189", "word": "exam", "phonetic": "/ɪɡˈzæm/", "syllables": ["ex", "am"], "chinese": "考试", "grade": 4, "unit": "校园生活", "example": "Prepare well for the exam.", "gradeName": "四年级", "meaning": "考试", "pos": "n."}, {"id": "pep_190", "word": "test", "phonetic": "/test/", "syllables": ["test"], "chinese": "测验；测试", "grade": 3, "unit": "校园生活", "example": "Score full marks in test.", "gradeName": "三年级", "meaning": "测验；测试", "pos": "n."}, {"id": "pep_191", "word": "rule", "phonetic": "/ruːl/", "syllables": ["rule"], "chinese": "规则；校规", "grade": 3, "unit": "校园生活", "example": "Follow school safety rules.", "gradeName": "三年级", "meaning": "规则；校规", "pos": "n."}, {"id": "pep_192", "word": "bell", "phonetic": "/bel/", "syllables": ["bell"], "chinese": "铃声；钟", "grade": 2, "unit": "校园生活", "example": "The class bell rings.", "gradeName": "二年级", "meaning": "铃声；钟", "pos": "n."}, {"id": "pep_193", "word": "song", "phonetic": "/sɒŋ/", "syllables": ["song"], "chinese": "歌曲", "grade": 2, "unit": "校园生活", "example": "Sing a cheerful English song.", "gradeName": "二年级", "meaning": "歌曲", "pos": "n."}, {"id": "pep_194", "word": "story", "phonetic": "/ˈstɔːri/", "syllables": ["sto", "ry"], "chinese": "故事", "grade": 2, "unit": "校园生活", "example": "Listen to an inspiring story.", "gradeName": "二年级", "meaning": "故事", "pos": "n."}, {"id": "pep_195", "word": "question", "phonetic": "/ˈkwestʃən/", "syllables": ["ques", "tion"], "chinese": "问题", "grade": 3, "unit": "校园生活", "example": "Raise your hand to ask a question.", "gradeName": "三年级", "meaning": "问题", "pos": "n."}, {"id": "pep_196", "word": "apple", "phonetic": "/ˈæpl/", "syllables": ["ap", "ple"], "chinese": "苹果", "grade": 2, "unit": "美味饮食", "example": "An apple a day keeps the doctor away.", "gradeName": "二年级", "meaning": "苹果", "pos": "n."}, {"id": "pep_197", "word": "banana", "phonetic": "/bəˈnɑːnə/", "syllables": ["ba", "nan", "a"], "chinese": "香蕉", "grade": 2, "unit": "美味饮食", "example": "Monkeys like yellow bananas.", "gradeName": "二年级", "meaning": "香蕉", "pos": "n."}, {"id": "pep_198", "word": "pear", "phonetic": "/peə(r)/", "syllables": ["pear"], "chinese": "梨", "grade": 2, "unit": "美味饮食", "example": "The pear is juicy and sweet.", "gradeName": "二年级", "meaning": "梨", "pos": "n."}, {"id": "pep_199", "word": "watermelon", "phonetic": "/ˈwɔːtəmelən/", "syllables": ["wa", "ter", "mel", "on"], "chinese": "西瓜", "grade": 2, "unit": "美味饮食", "example": "Watermelon is my summer treat.", "gradeName": "二年级", "meaning": "西瓜", "pos": "n."}, {"id": "pep_200", "word": "grape", "phonetic": "/ɡreɪp/", "syllables": ["grape"], "chinese": "葡萄", "grade": 2, "unit": "美味饮食", "example": "Sweet purple grapes grow on vines.", "gradeName": "二年级", "meaning": "葡萄", "pos": "n."}, {"id": "pep_201", "word": "strawberry", "phonetic": "/ˈstrɔːbəri/", "syllables": ["straw", "ber", "ry"], "chinese": "草莓", "grade": 2, "unit": "美味饮食", "example": "Fresh strawberries are red.", "gradeName": "二年级", "meaning": "草莓", "pos": "n."}, {"id": "pep_202", "word": "peach", "phonetic": "/piːtʃ/", "syllables": ["peach"], "chinese": "桃子", "grade": 2, "unit": "美味饮食", "example": "The peach smells very nice.", "gradeName": "二年级", "meaning": "桃子", "pos": "n."}, {"id": "pep_203", "word": "fruit", "phonetic": "/fruːt/", "syllables": ["fruit"], "chinese": "水果", "grade": 2, "unit": "美味饮食", "example": "Eat more fruit to stay healthy.", "gradeName": "二年级", "meaning": "水果", "pos": "n."}, {"id": "pep_204", "word": "lemon", "phonetic": "/ˈlemən/", "syllables": ["lem", "on"], "chinese": "柠檬", "grade": 2, "unit": "美味饮食", "example": "Lemons taste fresh and sour.", "gradeName": "二年级", "meaning": "柠檬", "pos": "n."}, {"id": "pep_205", "word": "mango", "phonetic": "/ˈmæŋɡəʊ/", "syllables": ["man", "go"], "chinese": "芒果", "grade": 2, "unit": "美味饮食", "example": "Sweet tropical mango slices.", "gradeName": "二年级", "meaning": "芒果", "pos": "n."}, {"id": "pep_206", "word": "pineapple", "phonetic": "/ˈpaɪnæpl/", "syllables": ["pine", "ap", "ple"], "chinese": "菠萝", "grade": 2, "unit": "美味饮食", "example": "Pineapple on sweet pizza.", "gradeName": "二年级", "meaning": "菠萝", "pos": "n."}, {"id": "pep_207", "word": "cherry", "phonetic": "/ˈtʃeri/", "syllables": ["cher", "ry"], "chinese": "樱桃", "grade": 2, "unit": "美味饮食", "example": "Bright red ripe cherries.", "gradeName": "二年级", "meaning": "樱桃", "pos": "n."}, {"id": "pep_208", "word": "tomato", "phonetic": "/təˈmɑːtəʊ/", "syllables": ["to", "ma", "to"], "chinese": "西红柿；番茄", "grade": 3, "unit": "美味饮食", "example": "Ripe tomatoes in garden.", "gradeName": "三年级", "meaning": "西红柿；番茄", "pos": "n."}, {"id": "pep_209", "word": "potato", "phonetic": "/pəˈteɪtəʊ/", "syllables": ["po", "ta", "to"], "chinese": "土豆；马铃薯", "grade": 3, "unit": "美味饮食", "example": "Mashed potatoes with butter.", "gradeName": "三年级", "meaning": "土豆；马铃薯", "pos": "n."}, {"id": "pep_210", "word": "carrot", "phonetic": "/ˈkærət/", "syllables": ["car", "rot"], "chinese": "胡萝卜", "grade": 2, "unit": "美味饮食", "example": "Rabbits crunch crunchy carrots.", "gradeName": "二年级", "meaning": "胡萝卜", "pos": "n."}, {"id": "pep_211", "word": "onion", "phonetic": "/ˈʌnjən/", "syllables": ["on", "ion"], "chinese": "洋葱", "grade": 3, "unit": "美味饮食", "example": "Chop onions for beef stew.", "gradeName": "三年级", "meaning": "洋葱", "pos": "n."}, {"id": "pep_212", "word": "cucumber", "phonetic": "/ˈkjuːkʌmbə(r)/", "syllables": ["cu", "cum", "ber"], "chinese": "黄瓜", "grade": 3, "unit": "美味饮食", "example": "Cool and fresh cucumbers.", "gradeName": "三年级", "meaning": "黄瓜", "pos": "adj."}, {"id": "pep_213", "word": "mushroom", "phonetic": "/ˈmʌʃrʊm/", "syllables": ["mush", "room"], "chinese": "蘑菇", "grade": 3, "unit": "美味饮食", "example": "Wild mushrooms in forest.", "gradeName": "三年级", "meaning": "蘑菇", "pos": "n."}, {"id": "pep_214", "word": "bean", "phonetic": "/biːn/", "syllables": ["bean"], "chinese": "豆子；豆类", "grade": 3, "unit": "美味饮食", "example": "Green beans are nutritious.", "gradeName": "三年级", "meaning": "豆子；豆类", "pos": "n."}, {"id": "pep_215", "word": "cabbage", "phonetic": "/ˈkæbɪdʒ/", "syllables": ["cab", "bage"], "chinese": "卷心菜", "grade": 3, "unit": "美味饮食", "example": "Crispy shredded cabbage.", "gradeName": "三年级", "meaning": "卷心菜", "pos": "n."}, {"id": "pep_216", "word": "rice", "phonetic": "/raɪs/", "syllables": ["rice"], "chinese": "米饭；水稻", "grade": 2, "unit": "美味饮食", "example": "Chinese people eat white rice.", "gradeName": "二年级", "meaning": "米饭；水稻", "pos": "n."}, {"id": "pep_217", "word": "noodle", "phonetic": "/ˈnuːdl/", "syllables": ["noo", "dle"], "chinese": "面条", "grade": 2, "unit": "美味饮食", "example": "I like beef noodles for lunch.", "gradeName": "二年级", "meaning": "面条", "pos": "n."}, {"id": "pep_218", "word": "bread", "phonetic": "/bred/", "syllables": ["bread"], "chinese": "面包", "grade": 2, "unit": "美味饮食", "example": "Bake fresh bread every day.", "gradeName": "二年级", "meaning": "面包", "pos": "n."}, {"id": "pep_219", "word": "egg", "phonetic": "/eɡ/", "syllables": ["egg"], "chinese": "鸡蛋；卵", "grade": 2, "unit": "美味饮食", "example": "Boil an egg for breakfast.", "gradeName": "二年级", "meaning": "鸡蛋；卵", "pos": "n."}, {"id": "pep_220", "word": "milk", "phonetic": "/mɪlk/", "syllables": ["milk"], "chinese": "牛奶", "grade": 2, "unit": "美味饮食", "example": "Drink warm milk before bed.", "gradeName": "二年级", "meaning": "牛奶", "pos": "n."}, {"id": "pep_221", "word": "water", "phonetic": "/ˈwɔːtə(r)/", "syllables": ["wa", "ter"], "chinese": "水", "grade": 2, "unit": "美味饮食", "example": "Drink plenty of water.", "gradeName": "二年级", "meaning": "水", "pos": "n."}, {"id": "pep_222", "word": "juice", "phonetic": "/dʒuːs/", "syllables": ["juice"], "chinese": "果汁", "grade": 2, "unit": "美味饮食", "example": "Would you like some orange juice?", "gradeName": "二年级", "meaning": "果汁", "pos": "n."}, {"id": "pep_223", "word": "tea", "phonetic": "/tiː/", "syllables": ["tea"], "chinese": "茶", "grade": 2, "unit": "美味饮食", "example": "Grandfather loves green tea.", "gradeName": "二年级", "meaning": "茶", "pos": "n."}, {"id": "pep_224", "word": "coffee", "phonetic": "/ˈkɒfi/", "syllables": ["cof", "fee"], "chinese": "咖啡", "grade": 2, "unit": "美味饮食", "example": "Coffee gives energy in the morning.", "gradeName": "二年级", "meaning": "咖啡", "pos": "n."}, {"id": "pep_225", "word": "soup", "phonetic": "/suːp/", "syllables": ["soup"], "chinese": "汤", "grade": 2, "unit": "美味饮食", "example": "The tomato soup is delicious.", "gradeName": "二年级", "meaning": "汤", "pos": "n."}, {"id": "pep_226", "word": "cake", "phonetic": "/keɪk/", "syllables": ["cake"], "chinese": "蛋糕", "grade": 2, "unit": "美味饮食", "example": "Cut the birthday cake together.", "gradeName": "二年级", "meaning": "蛋糕", "pos": "n."}, {"id": "pep_227", "word": "candy", "phonetic": "/ˈkændi/", "syllables": ["can", "dy"], "chinese": "糖果", "grade": 2, "unit": "美味饮食", "example": "Do not eat too much candy.", "gradeName": "二年级", "meaning": "糖果", "pos": "n."}, {"id": "pep_228", "word": "chicken", "phonetic": "/ˈtʃɪkɪn/", "syllables": ["chick", "en"], "chinese": "鸡肉；小鸡", "grade": 2, "unit": "美味饮食", "example": "We have roast chicken tonight.", "gradeName": "二年级", "meaning": "鸡肉；小鸡", "pos": "n."}, {"id": "pep_229", "word": "meat", "phonetic": "/miːt/", "syllables": ["meat"], "chinese": "肉类", "grade": 2, "unit": "美味饮食", "example": "Fresh meat provides protein.", "gradeName": "二年级", "meaning": "肉类", "pos": "n."}, {"id": "pep_230", "word": "beef", "phonetic": "/biːf/", "syllables": ["beef"], "chinese": "牛肉", "grade": 2, "unit": "美味饮食", "example": "Steak is tender beef.", "gradeName": "二年级", "meaning": "牛肉", "pos": "n."}, {"id": "pep_231", "word": "pork", "phonetic": "/pɔːk/", "syllables": ["pork"], "chinese": "猪肉", "grade": 2, "unit": "美味饮食", "example": "Sweet and sour pork ribs.", "gradeName": "二年级", "meaning": "猪肉", "pos": "n."}, {"id": "pep_232", "word": "cheese", "phonetic": "/tʃiːz/", "syllables": ["cheese"], "chinese": "奶酪；芝士", "grade": 2, "unit": "美味饮食", "example": "Melted cheese tastes rich.", "gradeName": "二年级", "meaning": "奶酪；芝士", "pos": "n."}, {"id": "pep_233", "word": "cookie", "phonetic": "/ˈkʊki/", "syllables": ["cook", "ie"], "chinese": "曲奇饼干", "grade": 2, "unit": "美味饮食", "example": "Chocolate chip cookies.", "gradeName": "二年级", "meaning": "曲奇饼干", "pos": "n."}, {"id": "pep_234", "word": "sandwich", "phonetic": "/ˈsænwɪtʃ/", "syllables": ["sand", "wich"], "chinese": "三明治", "grade": 2, "unit": "美味饮食", "example": "A ham and lettuce sandwich.", "gradeName": "二年级", "meaning": "三明治", "pos": "n."}, {"id": "pep_235", "word": "hamburger", "phonetic": "/ˈhæmbɜːɡə(r)/", "syllables": ["ham", "bur", "ger"], "chinese": "汉堡包", "grade": 2, "unit": "美味饮食", "example": "Juicy homemade hamburger.", "gradeName": "二年级", "meaning": "汉堡包", "pos": "n."}, {"id": "pep_236", "word": "salad", "phonetic": "/ˈsæləd/", "syllables": ["sal", "ad"], "chinese": "沙拉", "grade": 2, "unit": "美味饮食", "example": "Crispy garden vegetable salad.", "gradeName": "二年级", "meaning": "沙拉", "pos": "n."}, {"id": "pep_237", "word": "pizza", "phonetic": "/ˈpiːtsə/", "syllables": ["piz", "za"], "chinese": "披萨", "grade": 3, "unit": "美味饮食", "example": "Share a large cheese pizza.", "gradeName": "三年级", "meaning": "披萨", "pos": "n."}, {"id": "pep_238", "word": "dumpling", "phonetic": "/ˈdʌmplɪŋ/", "syllables": ["dump", "ling"], "chinese": "饺子", "grade": 3, "unit": "美味饮食", "example": "Eat dumplings at Spring Festival.", "gradeName": "三年级", "meaning": "饺子", "pos": "n."}, {"id": "pep_239", "word": "snack", "phonetic": "/snæk/", "syllables": ["snack"], "chinese": "零食；点心", "grade": 3, "unit": "美味饮食", "example": "Healthy fruit snacks.", "gradeName": "三年级", "meaning": "零食；点心", "pos": "n."}, {"id": "pep_240", "word": "ice-cream", "phonetic": "/ˌaɪs ˈkriːm/", "syllables": ["ice", "cream"], "chinese": "冰淇淋", "grade": 2, "unit": "美味饮食", "example": "Vanilla ice-cream cone.", "gradeName": "二年级", "meaning": "冰淇淋", "pos": "n."}, {"id": "pep_241", "word": "chocolate", "phonetic": "/ˈtʃɒklət/", "syllables": ["choc", "o", "late"], "chinese": "巧克力", "grade": 3, "unit": "美味饮食", "example": "Dark sweet chocolate bar.", "gradeName": "三年级", "meaning": "巧克力", "pos": "n."}, {"id": "pep_242", "word": "sugar", "phonetic": "/ˈʃʊɡə(r)/", "syllables": ["su", "gar"], "chinese": "糖", "grade": 3, "unit": "美味饮食", "example": "Do not add too much sugar.", "gradeName": "三年级", "meaning": "糖", "pos": "n."}, {"id": "pep_243", "word": "salt", "phonetic": "/sɔːlt/", "syllables": ["salt"], "chinese": "盐", "grade": 3, "unit": "美味饮食", "example": "A pinch of salt in cooking.", "gradeName": "三年级", "meaning": "盐", "pos": "n."}, {"id": "pep_244", "word": "butter", "phonetic": "/ˈbʌtə(r)/", "syllables": ["but", "ter"], "chinese": "黄油", "grade": 3, "unit": "美味饮食", "example": "Spread butter on toast.", "gradeName": "三年级", "meaning": "黄油", "pos": "adj."}, {"id": "pep_245", "word": "honey", "phonetic": "/ˈhʌni/", "syllables": ["hon", "ey"], "chinese": "蜂蜜", "grade": 3, "unit": "美味饮食", "example": "Golden sweet bee honey.", "gradeName": "三年级", "meaning": "蜂蜜", "pos": "n."}, {"id": "pep_246", "word": "hungry", "phonetic": "/ˈhʌŋɡri/", "syllables": ["hun", "gry"], "chinese": "饥饿的", "grade": 2, "unit": "美味饮食", "example": "I am so hungry after sports.", "gradeName": "二年级", "meaning": "饥饿的", "pos": "n."}, {"id": "pep_247", "word": "thirsty", "phonetic": "/ˈθɜːsti/", "syllables": ["thirs", "ty"], "chinese": "口渴的", "grade": 2, "unit": "美味饮食", "example": "Drink water when you are thirsty.", "gradeName": "二年级", "meaning": "口渴的", "pos": "n."}, {"id": "pep_248", "word": "full", "phonetic": "/fʊl/", "syllables": ["full"], "chinese": "饱的；充满的", "grade": 3, "unit": "美味饮食", "example": "I am full after dinner.", "gradeName": "三年级", "meaning": "饱的；充满的", "pos": "n."}, {"id": "pep_249", "word": "delicious", "phonetic": "/dɪˈlɪʃəs/", "syllables": ["de", "li", "cious"], "chinese": "美味的；可口的", "grade": 3, "unit": "美味饮食", "example": "Mom's dishes are delicious.", "gradeName": "三年级", "meaning": "美味的；可口的", "pos": "adj."}, {"id": "pep_250", "word": "sweet", "phonetic": "/swiːt/", "syllables": ["sweet"], "chinese": "甜的；芳香的", "grade": 2, "unit": "美味饮食", "example": "Honey is sweet and healthy.", "gradeName": "二年级", "meaning": "甜的；芳香的", "pos": "n."}, {"id": "pep_251", "word": "sour", "phonetic": "/ˈsaʊə(r)/", "syllables": ["sour"], "chinese": "酸的", "grade": 3, "unit": "美味饮食", "example": "Green apples taste slightly sour.", "gradeName": "三年级", "meaning": "酸的", "pos": "n."}, {"id": "pep_252", "word": "breakfast", "phonetic": "/ˈbrekfəst/", "syllables": ["break", "fast"], "chinese": "早餐", "grade": 3, "unit": "美味饮食", "example": "Never skip nutritious breakfast.", "gradeName": "三年级", "meaning": "早餐", "pos": "n."}, {"id": "pep_253", "word": "lunch", "phonetic": "/lʌntʃ/", "syllables": ["lunch"], "chinese": "午餐", "grade": 3, "unit": "美味饮食", "example": "Have a healthy lunch at noon.", "gradeName": "三年级", "meaning": "午餐", "pos": "n."}, {"id": "pep_254", "word": "dinner", "phonetic": "/ˈdɪnə(r)/", "syllables": ["din", "ner"], "chinese": "正餐；晚餐", "grade": 3, "unit": "美味饮食", "example": "Family gathers for dinner.", "gradeName": "三年级", "meaning": "正餐；晚餐", "pos": "n."}, {"id": "pep_255", "word": "meal", "phonetic": "/miːl/", "syllables": ["meal"], "chinese": "一餐；饭食", "grade": 3, "unit": "美味饮食", "example": "Enjoy three square meals.", "gradeName": "三年级", "meaning": "一餐；饭食", "pos": "n."}, {"id": "pep_256", "word": "shirt", "phonetic": "/ʃɜːt/", "syllables": ["shirt"], "chinese": "衬衫（男士）", "grade": 2, "unit": "服饰穿搭", "example": "Iron your white shirt.", "gradeName": "二年级", "meaning": "衬衫（男士）", "pos": "n."}, {"id": "pep_257", "word": "T-shirt", "phonetic": "/ˈtiː ʃɜːt/", "syllables": ["T", "shirt"], "chinese": "T恤衫", "grade": 2, "unit": "服饰穿搭", "example": "I wear a cool T-shirt in summer.", "gradeName": "二年级", "meaning": "T恤衫", "pos": "n."}, {"id": "pep_258", "word": "skirt", "phonetic": "/skɜːt/", "syllables": ["skirt"], "chinese": "半身裙", "grade": 2, "unit": "服饰穿搭", "example": "She wears a lovely floral skirt.", "gradeName": "二年级", "meaning": "半身裙", "pos": "n."}, {"id": "pep_259", "word": "dress", "phonetic": "/dres/", "syllables": ["dress"], "chinese": "连衣裙", "grade": 2, "unit": "服饰穿搭", "example": "The princess wore a golden dress.", "gradeName": "二年级", "meaning": "连衣裙", "pos": "n."}, {"id": "pep_260", "word": "coat", "phonetic": "/kəʊt/", "syllables": ["coat"], "chinese": "外套；大衣", "grade": 2, "unit": "服饰穿搭", "example": "Put on your warm coat.", "gradeName": "二年级", "meaning": "外套；大衣", "pos": "n."}, {"id": "pep_261", "word": "jacket", "phonetic": "/ˈdʒækɪt/", "syllables": ["jack", "et"], "chinese": "夹克衫", "grade": 2, "unit": "服饰穿搭", "example": "Zip up your denim jacket.", "gradeName": "二年级", "meaning": "夹克衫", "pos": "n."}, {"id": "pep_262", "word": "sweater", "phonetic": "/ˈswetə(r)/", "syllables": ["sweat", "er"], "chinese": "毛衣", "grade": 2, "unit": "服饰穿搭", "example": "Knitted sweater keeps you warm.", "gradeName": "二年级", "meaning": "毛衣", "pos": "n."}, {"id": "pep_263", "word": "pants", "phonetic": "/pænts/", "syllables": ["pants"], "chinese": "裤子", "grade": 2, "unit": "服饰穿搭", "example": "These blue pants fit well.", "gradeName": "二年级", "meaning": "裤子", "pos": "n."}, {"id": "pep_264", "word": "shorts", "phonetic": "/ʃɔːts/", "syllables": ["shorts"], "chinese": "短裤", "grade": 2, "unit": "服饰穿搭", "example": "Put on your sports shorts.", "gradeName": "二年级", "meaning": "短裤", "pos": "adj."}, {"id": "pep_265", "word": "jeans", "phonetic": "/dʒiːnz/", "syllables": ["jeans"], "chinese": "牛仔裤", "grade": 2, "unit": "服饰穿搭", "example": "Classic blue cotton jeans.", "gradeName": "二年级", "meaning": "牛仔裤", "pos": "n."}, {"id": "pep_266", "word": "shoes", "phonetic": "/ʃuːz/", "syllables": ["shoes"], "chinese": "鞋子", "grade": 2, "unit": "服饰穿搭", "example": "Tie the shoelaces on your shoes.", "gradeName": "二年级", "meaning": "鞋子", "pos": "n."}, {"id": "pep_267", "word": "socks", "phonetic": "/sɒks/", "syllables": ["socks"], "chinese": "袜子", "grade": 2, "unit": "服饰穿搭", "example": "Cotton socks protect your feet.", "gradeName": "二年级", "meaning": "袜子", "pos": "n."}, {"id": "pep_268", "word": "hat", "phonetic": "/hæt/", "syllables": ["hat"], "chinese": "帽子（有檐）", "grade": 2, "unit": "服饰穿搭", "example": "A straw hat shades the sun.", "gradeName": "二年级", "meaning": "帽子（有檐）", "pos": "n."}, {"id": "pep_269", "word": "cap", "phonetic": "/kæp/", "syllables": ["cap"], "chinese": "鸭舌帽", "grade": 2, "unit": "服饰穿搭", "example": "He wears a baseball cap.", "gradeName": "二年级", "meaning": "鸭舌帽", "pos": "n."}, {"id": "pep_270", "word": "boots", "phonetic": "/buːts/", "syllables": ["boots"], "chinese": "靴子", "grade": 2, "unit": "服饰穿搭", "example": "Rubber rain boots in puddles.", "gradeName": "二年级", "meaning": "靴子", "pos": "n."}, {"id": "pep_271", "word": "scarf", "phonetic": "/skɑːf/", "syllables": ["scarf"], "chinese": "围巾", "grade": 2, "unit": "服饰穿搭", "example": "Wrap a wool scarf in winter.", "gradeName": "二年级", "meaning": "围巾", "pos": "n."}, {"id": "pep_272", "word": "gloves", "phonetic": "/ɡlʌvz/", "syllables": ["gloves"], "chinese": "手套", "grade": 2, "unit": "服饰穿搭", "example": "Warm leather gloves.", "gradeName": "二年级", "meaning": "手套", "pos": "n."}, {"id": "pep_273", "word": "slippers", "phonetic": "/ˈslɪpəz/", "syllables": ["slip", "pers"], "chinese": "拖鞋", "grade": 3, "unit": "服饰穿搭", "example": "Soft indoor slippers.", "gradeName": "三年级", "meaning": "拖鞋", "pos": "v."}, {"id": "pep_274", "word": "sneakers", "phonetic": "/ˈsniːkəz/", "syllables": ["sneak", "ers"], "chinese": "运动鞋", "grade": 4, "unit": "服饰穿搭", "example": "Lace up your running sneakers.", "gradeName": "四年级", "meaning": "运动鞋", "pos": "n."}, {"id": "pep_275", "word": "uniform", "phonetic": "/ˈjuːnɪfɔːm/", "syllables": ["u", "ni", "form"], "chinese": "制服；校服", "grade": 4, "unit": "服饰穿搭", "example": "Proudly wear our school uniform.", "gradeName": "四年级", "meaning": "制服；校服", "pos": "n."}, {"id": "pep_276", "word": "tie", "phonetic": "/taɪ/", "syllables": ["tie"], "chinese": "领带；系", "grade": 4, "unit": "服饰穿搭", "example": "A neat silk necktie.", "gradeName": "四年级", "meaning": "领带；系", "pos": "n."}, {"id": "pep_277", "word": "belt", "phonetic": "/belt/", "syllables": ["belt"], "chinese": "皮带；腰带", "grade": 4, "unit": "服饰穿搭", "example": "Fasten your leather belt.", "gradeName": "四年级", "meaning": "皮带；腰带", "pos": "n."}, {"id": "pep_278", "word": "raincoat", "phonetic": "/ˈreɪnkəʊt/", "syllables": ["rain", "coat"], "chinese": "雨衣", "grade": 3, "unit": "服饰穿搭", "example": "Yellow waterproof raincoat.", "gradeName": "三年级", "meaning": "雨衣", "pos": "adj."}, {"id": "pep_279", "word": "umbrella", "phonetic": "/ʌmˈbrelə/", "syllables": ["um", "brel", "la"], "chinese": "雨伞", "grade": 3, "unit": "服饰穿搭", "example": "Carry an umbrella on rainy days.", "gradeName": "三年级", "meaning": "雨伞", "pos": "adj."}, {"id": "pep_280", "word": "glasses", "phonetic": "/ˈɡlɑːsɪz/", "syllables": ["glas", "ses"], "chinese": "眼镜", "grade": 3, "unit": "服饰穿搭", "example": "Read books with reading glasses.", "gradeName": "三年级", "meaning": "眼镜", "pos": "n."}, {"id": "pep_281", "word": "home", "phonetic": "/həʊm/", "syllables": ["home"], "chinese": "家；家庭", "grade": 1, "unit": "居家生活", "example": "East or west, home is best.", "gradeName": "一年级", "meaning": "家；家庭", "pos": "n."}, {"id": "pep_282", "word": "house", "phonetic": "/haʊs/", "syllables": ["house"], "chinese": "房屋；房子", "grade": 1, "unit": "居家生活", "example": "They built a lovely wooden house.", "gradeName": "一年级", "meaning": "房屋；房子", "pos": "n."}, {"id": "pep_283", "word": "room", "phonetic": "/ruːm/", "syllables": ["room"], "chinese": "房间", "grade": 2, "unit": "居家生活", "example": "Clean your bedroom.", "gradeName": "二年级", "meaning": "房间", "pos": "n."}, {"id": "pep_284", "word": "bedroom", "phonetic": "/ˈbedruːm/", "syllables": ["bed", "room"], "chinese": "卧室", "grade": 2, "unit": "居家生活", "example": "Go to sleep in the bedroom.", "gradeName": "二年级", "meaning": "卧室", "pos": "n."}, {"id": "pep_285", "word": "living-room", "phonetic": "/ˈlɪvɪŋ ruːm/", "syllables": ["liv", "ing", "room"], "chinese": "客厅", "grade": 2, "unit": "居家生活", "example": "We watch TV in the living-room.", "gradeName": "二年级", "meaning": "客厅", "pos": "n."}, {"id": "pep_286", "word": "kitchen", "phonetic": "/ˈkɪtʃɪn/", "syllables": ["kitch", "en"], "chinese": "厨房", "grade": 2, "unit": "居家生活", "example": "Dad is cooking in the kitchen.", "gradeName": "二年级", "meaning": "厨房", "pos": "n."}, {"id": "pep_287", "word": "bathroom", "phonetic": "/ˈbɑːθruːm/", "syllables": ["bath", "room"], "chinese": "浴室；卫生间", "grade": 2, "unit": "居家生活", "example": "Brush your teeth in the bathroom.", "gradeName": "二年级", "meaning": "浴室；卫生间", "pos": "n."}, {"id": "pep_288", "word": "study", "phonetic": "/ˈstʌdi/", "syllables": ["stud", "y"], "chinese": "书房；学习", "grade": 2, "unit": "居家生活", "example": "Quiet study filled with books.", "gradeName": "二年级", "meaning": "书房；学习", "pos": "n."}, {"id": "pep_289", "word": "balcony", "phonetic": "/ˈbælkəni/", "syllables": ["bal", "co", "ny"], "chinese": "阳台", "grade": 4, "unit": "居家生活", "example": "Potted flowers on the balcony.", "gradeName": "四年级", "meaning": "阳台", "pos": "n."}, {"id": "pep_290", "word": "garden", "phonetic": "/ˈɡɑːdn/", "syllables": ["gar", "den"], "chinese": "花园；院子", "grade": 2, "unit": "居家生活", "example": "Roses bloom in our garden.", "gradeName": "二年级", "meaning": "花园；院子", "pos": "n."}, {"id": "pep_291", "word": "bed", "phonetic": "/bed/", "syllables": ["bed"], "chinese": "床", "grade": 2, "unit": "居家生活", "example": "Make your bed every morning.", "gradeName": "二年级", "meaning": "床", "pos": "n."}, {"id": "pep_292", "word": "sofa", "phonetic": "/ˈsəʊfə/", "syllables": ["so", "fa"], "chinese": "沙发", "grade": 2, "unit": "居家生活", "example": "Sit on the soft sofa.", "gradeName": "二年级", "meaning": "沙发", "pos": "n."}, {"id": "pep_293", "word": "table", "phonetic": "/ˈteɪbl/", "syllables": ["ta", "ble"], "chinese": "桌子；餐桌", "grade": 2, "unit": "居家生活", "example": "Food is ready on table.", "gradeName": "二年级", "meaning": "桌子；餐桌", "pos": "n."}, {"id": "pep_294", "word": "window", "phonetic": "/ˈwɪndəʊ/", "syllables": ["win", "dow"], "chinese": "窗户", "grade": 2, "unit": "居家生活", "example": "Open the window for fresh air.", "gradeName": "二年级", "meaning": "窗户", "pos": "n."}, {"id": "pep_295", "word": "door", "phonetic": "/dɔː(r)/", "syllables": ["door"], "chinese": "门", "grade": 2, "unit": "居家生活", "example": "Knock at the door first.", "gradeName": "二年级", "meaning": "门", "pos": "n."}, {"id": "pep_296", "word": "wall", "phonetic": "/wɔːl/", "syllables": ["wall"], "chinese": "墙壁", "grade": 3, "unit": "居家生活", "example": "Paint the wall sky blue.", "gradeName": "三年级", "meaning": "墙壁", "pos": "n."}, {"id": "pep_297", "word": "floor", "phonetic": "/flɔː(r)/", "syllables": ["floor"], "chinese": "地板；楼层", "grade": 3, "unit": "居家生活", "example": "Sweep the dusty floor.", "gradeName": "三年级", "meaning": "地板；楼层", "pos": "n."}, {"id": "pep_298", "word": "light", "phonetic": "/laɪt/", "syllables": ["light"], "chinese": "电灯；光线", "grade": 2, "unit": "居家生活", "example": "Turn off the light when leaving.", "gradeName": "二年级", "meaning": "电灯；光线", "pos": "n."}, {"id": "pep_299", "word": "lamp", "phonetic": "/læmp/", "syllables": ["lamp"], "chinese": "台灯", "grade": 3, "unit": "居家生活", "example": "Turn on the reading desk lamp.", "gradeName": "三年级", "meaning": "台灯", "pos": "n."}, {"id": "pep_300", "word": "clock", "phonetic": "/klɒk/", "syllables": ["clock"], "chinese": "时钟", "grade": 2, "unit": "居家生活", "example": "The alarm clock rings.", "gradeName": "二年级", "meaning": "时钟", "pos": "n."}, {"id": "pep_301", "word": "phone", "phonetic": "/fəʊn/", "syllables": ["phone"], "chinese": "电话", "grade": 2, "unit": "居家生活", "example": "Answer the phone politely.", "gradeName": "二年级", "meaning": "电话", "pos": "n."}, {"id": "pep_302", "word": "fridge", "phonetic": "/frɪdʒ/", "syllables": ["fridge"], "chinese": "电冰箱", "grade": 3, "unit": "居家生活", "example": "Keep milk cold in the fridge.", "gradeName": "三年级", "meaning": "电冰箱", "pos": "n."}, {"id": "pep_303", "word": "shelf", "phonetic": "/ʃelf/", "syllables": ["shelf"], "chinese": "书架；隔板", "grade": 4, "unit": "居家生活", "example": "Books arranged on the shelf.", "gradeName": "四年级", "meaning": "书架；隔板", "pos": "n."}, {"id": "pep_304", "word": "box", "phonetic": "/bɒks/", "syllables": ["box"], "chinese": "盒子；箱子", "grade": 2, "unit": "居家生活", "example": "Open the magic gift box.", "gradeName": "二年级", "meaning": "盒子；箱子", "pos": "n."}, {"id": "pep_305", "word": "key", "phonetic": "/kiː/", "syllables": ["key"], "chinese": "钥匙；关键", "grade": 3, "unit": "居家生活", "example": "Keep your door key safe.", "gradeName": "三年级", "meaning": "钥匙；关键", "pos": "n."}, {"id": "pep_306", "word": "mirror", "phonetic": "/ˈmɪrə(r)/", "syllables": ["mir", "ror"], "chinese": "镜子", "grade": 4, "unit": "居家生活", "example": "Look in the mirror and smile.", "gradeName": "四年级", "meaning": "镜子", "pos": "n."}, {"id": "pep_307", "word": "fan", "phonetic": "/fæn/", "syllables": ["fan"], "chinese": "风扇；迷", "grade": 3, "unit": "居家生活", "example": "Electric fan cools the room.", "gradeName": "三年级", "meaning": "风扇；迷", "pos": "adj."}, {"id": "pep_308", "word": "curtain", "phonetic": "/ˈkɜːtn/", "syllables": ["cur", "tain"], "chinese": "窗帘", "grade": 4, "unit": "居家生活", "example": "Draw the curtains in evening.", "gradeName": "四年级", "meaning": "窗帘", "pos": "n."}, {"id": "pep_309", "word": "towel", "phonetic": "/ˈtaʊəl/", "syllables": ["tow", "el"], "chinese": "毛巾", "grade": 3, "unit": "居家生活", "example": "Dry your hands with a clean towel.", "gradeName": "三年级", "meaning": "毛巾", "pos": "n."}, {"id": "pep_310", "word": "soap", "phonetic": "/səʊp/", "syllables": ["soap"], "chinese": "肥皂", "grade": 3, "unit": "居家生活", "example": "Wash hands with scented soap.", "gradeName": "三年级", "meaning": "肥皂", "pos": "n."}, {"id": "pep_311", "word": "city", "phonetic": "/ˈsɪti/", "syllables": ["cit", "y"], "chinese": "城市", "grade": 3, "unit": "社会与交通", "example": "Beijing is a vibrant ancient city.", "gradeName": "三年级", "meaning": "城市", "pos": "n."}, {"id": "pep_312", "word": "town", "phonetic": "/taʊn/", "syllables": ["town"], "chinese": "小镇；城镇", "grade": 3, "unit": "社会与交通", "example": "A peaceful seaside town.", "gradeName": "三年级", "meaning": "小镇；城镇", "pos": "adj."}, {"id": "pep_313", "word": "village", "phonetic": "/ˈvɪlɪdʒ/", "syllables": ["vil", "lage"], "chinese": "村庄；乡村", "grade": 3, "unit": "社会与交通", "example": "Green fields surround the village.", "gradeName": "三年级", "meaning": "村庄；乡村", "pos": "n."}, {"id": "pep_314", "word": "street", "phonetic": "/striːt/", "syllables": ["street"], "chinese": "街道", "grade": 3, "unit": "社会与交通", "example": "Cross the street with care.", "gradeName": "三年级", "meaning": "街道", "pos": "n."}, {"id": "pep_315", "word": "road", "phonetic": "/rəʊd/", "syllables": ["road"], "chinese": "道路；马路", "grade": 3, "unit": "社会与交通", "example": "A winding mountain road.", "gradeName": "三年级", "meaning": "道路；马路", "pos": "n."}, {"id": "pep_316", "word": "park", "phonetic": "/pɑːk/", "syllables": ["park"], "chinese": "公园", "grade": 2, "unit": "社会与交通", "example": "We had a picnic in the park.", "gradeName": "二年级", "meaning": "公园", "pos": "n."}, {"id": "pep_317", "word": "zoo", "phonetic": "/zuː/", "syllables": ["zoo"], "chinese": "动物园", "grade": 1, "unit": "社会与交通", "example": "Let's visit the animals in the zoo.", "gradeName": "一年级", "meaning": "动物园", "pos": "n."}, {"id": "pep_318", "word": "farm", "phonetic": "/fɑːm/", "syllables": ["farm"], "chinese": "农场", "grade": 2, "unit": "社会与交通", "example": "Old MacDonald had a farm.", "gradeName": "二年级", "meaning": "农场", "pos": "n."}, {"id": "pep_319", "word": "shop", "phonetic": "/ʃɒp/", "syllables": ["shop"], "chinese": "商店", "grade": 2, "unit": "社会与交通", "example": "Buy fresh pencils at the shop.", "gradeName": "二年级", "meaning": "商店", "pos": "n."}, {"id": "pep_320", "word": "store", "phonetic": "/stɔː(r)/", "syllables": ["store"], "chinese": "百货商店", "grade": 3, "unit": "社会与交通", "example": "Convenience store on corner.", "gradeName": "三年级", "meaning": "百货商店", "pos": "n."}, {"id": "pep_321", "word": "supermarket", "phonetic": "/ˈsuːpəmɑːkɪt/", "syllables": ["su", "per", "mar", "ket"], "chinese": "超市", "grade": 2, "unit": "社会与交通", "example": "Fruits and milk in supermarket.", "gradeName": "二年级", "meaning": "超市", "pos": "n."}, {"id": "pep_322", "word": "hospital", "phonetic": "/ˈhɒspɪtl/", "syllables": ["hos", "pi", "tal"], "chinese": "医院", "grade": 2, "unit": "社会与交通", "example": "The doctor heals sick kids in hospital.", "gradeName": "二年级", "meaning": "医院", "pos": "n."}, {"id": "pep_323", "word": "cinema", "phonetic": "/ˈsɪnəmə/", "syllables": ["cin", "e", "ma"], "chinese": "电影院", "grade": 2, "unit": "社会与交通", "example": "Watch an animated film at cinema.", "gradeName": "二年级", "meaning": "电影院", "pos": "n."}, {"id": "pep_324", "word": "bank", "phonetic": "/bæŋk/", "syllables": ["bank"], "chinese": "银行", "grade": 3, "unit": "社会与交通", "example": "Save coins in the bank.", "gradeName": "三年级", "meaning": "银行", "pos": "n."}, {"id": "pep_325", "word": "hotel", "phonetic": "/həʊˈtel/", "syllables": ["ho", "tel"], "chinese": "宾馆；酒店", "grade": 4, "unit": "社会与交通", "example": "Stay at a comfortable hotel.", "gradeName": "四年级", "meaning": "宾馆；酒店", "pos": "n."}, {"id": "pep_326", "word": "post office", "phonetic": "/ˈpəʊst ɒfɪs/", "syllables": ["post", "of", "fice"], "chinese": "邮局", "grade": 3, "unit": "社会与交通", "example": "Mail a letter at post office.", "gradeName": "三年级", "meaning": "邮局", "pos": "n."}, {"id": "pep_327", "word": "museum", "phonetic": "/mjuˈziːəm/", "syllables": ["mu", "se", "um"], "chinese": "博物馆", "grade": 4, "unit": "社会与交通", "example": "Learn history at national museum.", "gradeName": "四年级", "meaning": "博物馆", "pos": "n."}, {"id": "pep_328", "word": "airport", "phonetic": "/ˈeəpɔːt/", "syllables": ["air", "port"], "chinese": "机场", "grade": 4, "unit": "社会与交通", "example": "Planes take off at the airport.", "gradeName": "四年级", "meaning": "机场", "pos": "adj."}, {"id": "pep_329", "word": "station", "phonetic": "/ˈsteɪʃn/", "syllables": ["sta", "tion"], "chinese": "车站", "grade": 3, "unit": "社会与交通", "example": "Meet friends at the train station.", "gradeName": "三年级", "meaning": "车站", "pos": "n."}, {"id": "pep_330", "word": "bus stop", "phonetic": "/bʌs stɒp/", "syllables": ["bus", "stop"], "chinese": "公交车站", "grade": 2, "unit": "社会与交通", "example": "Wait patiently at the bus stop.", "gradeName": "二年级", "meaning": "公交车站", "pos": "n."}, {"id": "pep_331", "word": "car", "phonetic": "/kɑː(r)/", "syllables": ["car"], "chinese": "小汽车", "grade": 1, "unit": "社会与交通", "example": "The toy car runs fast.", "gradeName": "一年级", "meaning": "小汽车", "pos": "adj."}, {"id": "pep_332", "word": "bus", "phonetic": "/bʌs/", "syllables": ["bus"], "chinese": "公共汽车", "grade": 1, "unit": "社会与交通", "example": "Take the number ten bus.", "gradeName": "一年级", "meaning": "公共汽车", "pos": "n."}, {"id": "pep_333", "word": "bike", "phonetic": "/baɪk/", "syllables": ["bike"], "chinese": "自行车", "grade": 1, "unit": "社会与交通", "example": "Ride a bike to school.", "gradeName": "一年级", "meaning": "自行车", "pos": "adj."}, {"id": "pep_334", "word": "bicycle", "phonetic": "/ˈbaɪsɪkl/", "syllables": ["bi", "cy", "cle"], "chinese": "自行车", "grade": 2, "unit": "社会与交通", "example": "Wear a helmet when riding a bicycle.", "gradeName": "二年级", "meaning": "自行车", "pos": "adj."}, {"id": "pep_335", "word": "train", "phonetic": "/treɪn/", "syllables": ["train"], "chinese": "火车", "grade": 2, "unit": "社会与交通", "example": "Hear the train whistle loudly.", "gradeName": "二年级", "meaning": "火车", "pos": "n."}, {"id": "pep_336", "word": "plane", "phonetic": "/pleɪn/", "syllables": ["plane"], "chinese": "飞机", "grade": 2, "unit": "社会与交通", "example": "The plane flies through clouds.", "gradeName": "二年级", "meaning": "飞机", "pos": "v."}, {"id": "pep_337", "word": "airplane", "phonetic": "/ˈeəpleɪn/", "syllables": ["air", "plane"], "chinese": "飞机", "grade": 3, "unit": "社会与交通", "example": "Look at the silver airplane.", "gradeName": "三年级", "meaning": "飞机", "pos": "v."}, {"id": "pep_338", "word": "boat", "phonetic": "/bəʊt/", "syllables": ["boat"], "chinese": "小船", "grade": 2, "unit": "社会与交通", "example": "Row your boat gently.", "gradeName": "二年级", "meaning": "小船", "pos": "adj."}, {"id": "pep_339", "word": "ship", "phonetic": "/ʃɪp/", "syllables": ["ship"], "chinese": "轮船；大船", "grade": 2, "unit": "社会与交通", "example": "A huge ship sails on ocean.", "gradeName": "二年级", "meaning": "轮船；大船", "pos": "n."}, {"id": "pep_340", "word": "subway", "phonetic": "/ˈsʌbweɪ/", "syllables": ["sub", "way"], "chinese": "地铁", "grade": 4, "unit": "社会与交通", "example": "Subway trains are fast and green.", "gradeName": "四年级", "meaning": "地铁", "pos": "n."}, {"id": "pep_341", "word": "taxi", "phonetic": "/ˈtæksi/", "syllables": ["tax", "i"], "chinese": "出租车", "grade": 3, "unit": "社会与交通", "example": "Hail a taxi at terminal.", "gradeName": "三年级", "meaning": "出租车", "pos": "n."}, {"id": "pep_342", "word": "truck", "phonetic": "/trʌk/", "syllables": ["truck"], "chinese": "卡车", "grade": 3, "unit": "社会与交通", "example": "Heavy truck carries cargo.", "gradeName": "三年级", "meaning": "卡车", "pos": "n."}, {"id": "pep_343", "word": "van", "phonetic": "/væn/", "syllables": ["van"], "chinese": "面包车；厢式货车", "grade": 3, "unit": "社会与交通", "example": "Delivery van drives by.", "gradeName": "三年级", "meaning": "面包车；厢式货车", "pos": "n."}, {"id": "pep_344", "word": "stop", "phonetic": "/stɒp/", "syllables": ["stop"], "chinese": "停止；站牌", "grade": 2, "unit": "社会与交通", "example": "Stop at red traffic light.", "gradeName": "二年级", "meaning": "停止；站牌", "pos": "n."}, {"id": "pep_345", "word": "traffic", "phonetic": "/ˈtræfɪk/", "syllables": ["traf", "fic"], "chinese": "交通；车流", "grade": 4, "unit": "社会与交通", "example": "Heavy traffic on bridge.", "gradeName": "四年级", "meaning": "交通；车流", "pos": "n."}, {"id": "pep_346", "word": "country", "phonetic": "/ˈkʌntri/", "syllables": ["coun", "try"], "chinese": "国家；乡村", "grade": 4, "unit": "社会与交通", "example": "I love my motherland country.", "gradeName": "四年级", "meaning": "国家；乡村", "pos": "n."}, {"id": "pep_347", "word": "China", "phonetic": "/ˈtʃaɪnə/", "syllables": ["Chi", "na"], "chinese": "中国", "grade": 2, "unit": "社会与交通", "example": "China has a long history.", "gradeName": "二年级", "meaning": "中国", "pos": "n."}, {"id": "pep_348", "word": "Canada", "phonetic": "/ˈkænədə/", "syllables": ["Can", "a", "da"], "chinese": "加拿大", "grade": 3, "unit": "社会与交通", "example": "Maple leaves in Canada.", "gradeName": "三年级", "meaning": "加拿大", "pos": "n."}, {"id": "pep_349", "word": "America", "phonetic": "/əˈmerɪkə/", "syllables": ["A", "mer", "i", "ca"], "chinese": "美国", "grade": 3, "unit": "社会与交通", "example": "Bald eagle represents America.", "gradeName": "三年级", "meaning": "美国", "pos": "adj."}, {"id": "pep_350", "word": "UK", "phonetic": "/ˌjuː ˈkeɪ/", "syllables": ["U", "K"], "chinese": "英国", "grade": 3, "unit": "社会与交通", "example": "Big Ben in UK.", "gradeName": "三年级", "meaning": "英国", "pos": "n."}, {"id": "pep_351", "word": "world", "phonetic": "/wɜːld/", "syllables": ["world"], "chinese": "世界", "grade": 4, "unit": "社会与交通", "example": "Explore the wonderful world.", "gradeName": "四年级", "meaning": "世界", "pos": "n."}, {"id": "pep_352", "word": "bridge", "phonetic": "/brɪdʒ/", "syllables": ["bridge"], "chinese": "桥梁", "grade": 4, "unit": "社会与交通", "example": "Cross the river via bridge.", "gradeName": "四年级", "meaning": "桥梁", "pos": "n."}, {"id": "pep_353", "word": "corner", "phonetic": "/ˈkɔːnə(r)/", "syllables": ["cor", "ner"], "chinese": "拐角；角落", "grade": 4, "unit": "社会与交通", "example": "Turn right at the corner.", "gradeName": "四年级", "meaning": "拐角；角落", "pos": "n."}, {"id": "pep_354", "word": "doctor", "phonetic": "/ˈdɒktə(r)/", "syllables": ["doc", "tor"], "chinese": "医生", "grade": 3, "unit": "职业理想", "example": "The gentle doctor helps sick people.", "gradeName": "三年级", "meaning": "医生", "pos": "n."}, {"id": "pep_355", "word": "nurse", "phonetic": "/nɜːs/", "syllables": ["nurse"], "chinese": "护士", "grade": 3, "unit": "职业理想", "example": "Nurses care for hospital patients.", "gradeName": "三年级", "meaning": "护士", "pos": "n."}, {"id": "pep_356", "word": "farmer", "phonetic": "/ˈfɑːmə(r)/", "syllables": ["farm", "er"], "chinese": "农民", "grade": 3, "unit": "职业理想", "example": "The farmer grows golden wheat.", "gradeName": "三年级", "meaning": "农民", "pos": "n."}, {"id": "pep_357", "word": "driver", "phonetic": "/ˈdraɪvə(r)/", "syllables": ["dri", "ver"], "chinese": "司机", "grade": 3, "unit": "职业理想", "example": "The careful bus driver stops on time.", "gradeName": "三年级", "meaning": "司机", "pos": "n."}, {"id": "pep_358", "word": "cook", "phonetic": "/kʊk/", "syllables": ["cook"], "chinese": "厨师；烹调", "grade": 3, "unit": "职业理想", "example": "The master cook prepares tasty food.", "gradeName": "三年级", "meaning": "厨师；烹调", "pos": "n."}, {"id": "pep_359", "word": "worker", "phonetic": "/ˈwɜːkə(r)/", "syllables": ["work", "er"], "chinese": "工人", "grade": 3, "unit": "职业理想", "example": "Factory workers make tools.", "gradeName": "三年级", "meaning": "工人", "pos": "n."}, {"id": "pep_360", "word": "policeman", "phonetic": "/pəˈliːsmən/", "syllables": ["po", "lice", "man"], "chinese": "男警察", "grade": 3, "unit": "职业理想", "example": "The policeman directs busy traffic.", "gradeName": "三年级", "meaning": "男警察", "pos": "n."}, {"id": "pep_361", "word": "policewoman", "phonetic": "/pəˈliːswʊmən/", "syllables": ["po", "lice", "wom", "an"], "chinese": "女警察", "grade": 3, "unit": "职业理想", "example": "Brave policewoman on duty.", "gradeName": "三年级", "meaning": "女警察", "pos": "n."}, {"id": "pep_362", "word": "postman", "phonetic": "/ˈpəʊstmən/", "syllables": ["post", "man"], "chinese": "邮递员", "grade": 3, "unit": "职业理想", "example": "The postman delivers fresh letters.", "gradeName": "三年级", "meaning": "邮递员", "pos": "n."}, {"id": "pep_363", "word": "firefighter", "phonetic": "/ˈfaɪəfaɪtə(r)/", "syllables": ["fire", "fight", "er"], "chinese": "消防员", "grade": 4, "unit": "职业理想", "example": "Brave firefighters put out blaze.", "gradeName": "四年级", "meaning": "消防员", "pos": "n."}, {"id": "pep_364", "word": "pilot", "phonetic": "/ˈpaɪlət/", "syllables": ["pi", "lot"], "chinese": "飞行员", "grade": 5, "unit": "职业理想", "example": "The brave pilot guides the airplane.", "gradeName": "五年级", "meaning": "飞行员", "pos": "v."}, {"id": "pep_365", "word": "astronaut", "phonetic": "/ˈæstrənɔːt/", "syllables": ["as", "tro", "naut"], "chinese": "航天员；宇航员", "grade": 6, "unit": "职业理想", "example": "Astronauts step into outer space.", "gradeName": "六年级", "meaning": "航天员；宇航员", "pos": "n."}, {"id": "pep_366", "word": "scientist", "phonetic": "/ˈsaɪəntɪst/", "syllables": ["sci", "en", "tist"], "chinese": "科学家", "grade": 6, "unit": "职业理想", "example": "Tu Youyou is a celebrated scientist.", "gradeName": "六年级", "meaning": "科学家", "pos": "n."}, {"id": "pep_367", "word": "engineer", "phonetic": "/ˌendʒɪˈnɪə(r)/", "syllables": ["en", "gi", "neer"], "chinese": "工程师", "grade": 6, "unit": "职业理想", "example": "The engineer built a long bridge.", "gradeName": "六年级", "meaning": "工程师", "pos": "n."}, {"id": "pep_368", "word": "artist", "phonetic": "/ˈɑːtɪst/", "syllables": ["ar", "tist"], "chinese": "艺术家；画家", "grade": 5, "unit": "职业理想", "example": "The artist captured the sunset glow.", "gradeName": "五年级", "meaning": "艺术家；画家", "pos": "n."}, {"id": "pep_369", "word": "singer", "phonetic": "/ˈsɪŋə(r)/", "syllables": ["sing", "er"], "chinese": "歌手", "grade": 4, "unit": "职业理想", "example": "The famous singer touches hearts.", "gradeName": "四年级", "meaning": "歌手", "pos": "n."}, {"id": "pep_370", "word": "dancer", "phonetic": "/ˈdɑːnsə(r)/", "syllables": ["dan", "cer"], "chinese": "舞蹈演员", "grade": 4, "unit": "职业理想", "example": "The dancer leaps like a swan.", "gradeName": "四年级", "meaning": "舞蹈演员", "pos": "n."}, {"id": "pep_371", "word": "musician", "phonetic": "/mjuˈzɪʃn/", "syllables": ["mu", "si", "cian"], "chinese": "音乐家", "grade": 6, "unit": "职业理想", "example": "Mozart was a gifted musician.", "gradeName": "六年级", "meaning": "音乐家", "pos": "n."}, {"id": "pep_372", "word": "writer", "phonetic": "/ˈraɪtə(r)/", "syllables": ["wri", "ter"], "chinese": "作家", "grade": 5, "unit": "职业理想", "example": "The writer publishes a bestseller.", "gradeName": "五年级", "meaning": "作家", "pos": "n."}, {"id": "pep_373", "word": "player", "phonetic": "/ˈpleɪə(r)/", "syllables": ["play", "er"], "chinese": "运动员；选手", "grade": 4, "unit": "职业理想", "example": "Basketball player shoots a hoop.", "gradeName": "四年级", "meaning": "运动员；选手", "pos": "n."}, {"id": "pep_374", "word": "coach", "phonetic": "/kəʊtʃ/", "syllables": ["coach"], "chinese": "教练", "grade": 5, "unit": "职业理想", "example": "The coach trains track team.", "gradeName": "五年级", "meaning": "教练", "pos": "v."}, {"id": "pep_375", "word": "cleaner", "phonetic": "/ˈkliːnə(r)/", "syllables": ["clean", "er"], "chinese": "保洁员", "grade": 4, "unit": "职业理想", "example": "Cleaners keep avenues tidy.", "gradeName": "四年级", "meaning": "保洁员", "pos": "n."}, {"id": "pep_376", "word": "job", "phonetic": "/dʒɒb/", "syllables": ["job"], "chinese": "职业；工作", "grade": 3, "unit": "职业理想", "example": "Find a rewarding dream job.", "gradeName": "三年级", "meaning": "职业；工作", "pos": "n."}, {"id": "pep_377", "word": "work", "phonetic": "/wɜːk/", "syllables": ["work"], "chinese": "工作；劳动", "grade": 3, "unit": "职业理想", "example": "Hard work brings fruitful success.", "gradeName": "三年级", "meaning": "工作；劳动", "pos": "n."}, {"id": "pep_378", "word": "spring", "phonetic": "/sprɪŋ/", "syllables": ["spring"], "chinese": "春天；春季", "grade": 4, "unit": "自然与时节", "example": "In spring, green leaves sprout.", "gradeName": "四年级", "meaning": "春天；春季", "pos": "n."}, {"id": "pep_379", "word": "summer", "phonetic": "/ˈsʌmə(r)/", "syllables": ["sum", "mer"], "chinese": "夏天；夏季", "grade": 4, "unit": "自然与时节", "example": "In summer, cicadas sing loudly.", "gradeName": "四年级", "meaning": "夏天；夏季", "pos": "n."}, {"id": "pep_380", "word": "autumn", "phonetic": "/ˈɔːtəm/", "syllables": ["au", "tumn"], "chinese": "秋天；秋季", "grade": 4, "unit": "自然与时节", "example": "Golden leaves drop in autumn.", "gradeName": "四年级", "meaning": "秋天；秋季", "pos": "n."}, {"id": "pep_381", "word": "winter", "phonetic": "/ˈwɪntə(r)/", "syllables": ["win", "ter"], "chinese": "冬天；冬季", "grade": 4, "unit": "自然与时节", "example": "Snow covers mountains in winter.", "gradeName": "四年级", "meaning": "冬天；冬季", "pos": "n."}, {"id": "pep_382", "word": "season", "phonetic": "/ˈsiːzn/", "syllables": ["sea", "son"], "chinese": "季节", "grade": 4, "unit": "自然与时节", "example": "There are four distinct seasons.", "gradeName": "四年级", "meaning": "季节", "pos": "n."}, {"id": "pep_383", "word": "sun", "phonetic": "/sʌn/", "syllables": ["sun"], "chinese": "太阳", "grade": 1, "unit": "自然与时节", "example": "The sun rises in the east.", "gradeName": "一年级", "meaning": "太阳", "pos": "n."}, {"id": "pep_384", "word": "moon", "phonetic": "/muːn/", "syllables": ["moon"], "chinese": "月亮", "grade": 4, "unit": "自然与时节", "example": "The full moon shines brightly.", "gradeName": "四年级", "meaning": "月亮", "pos": "n."}, {"id": "pep_385", "word": "star", "phonetic": "/stɑː(r)/", "syllables": ["star"], "chinese": "星星；恒星", "grade": 4, "unit": "自然与时节", "example": "Count sparkling stars in evening.", "gradeName": "四年级", "meaning": "星星；恒星", "pos": "n."}, {"id": "pep_386", "word": "sky", "phonetic": "/skaɪ/", "syllables": ["sky"], "chinese": "天空", "grade": 4, "unit": "自然与时节", "example": "Kites soar into high sky.", "gradeName": "四年级", "meaning": "天空", "pos": "n."}, {"id": "pep_387", "word": "cloud", "phonetic": "/klaʊd/", "syllables": ["cloud"], "chinese": "云朵", "grade": 3, "unit": "自然与时节", "example": "White clouds drift across blue sky.", "gradeName": "三年级", "meaning": "云朵", "pos": "n."}, {"id": "pep_388", "word": "rain", "phonetic": "/reɪn/", "syllables": ["rain"], "chinese": "雨；下雨", "grade": 3, "unit": "自然与时节", "example": "April showers bring May flowers.", "gradeName": "三年级", "meaning": "雨；下雨", "pos": "adj."}, {"id": "pep_389", "word": "snow", "phonetic": "/snəʊ/", "syllables": ["snow"], "chinese": "雪；下雪", "grade": 3, "unit": "自然与时节", "example": "Pure white snow falls quietly.", "gradeName": "三年级", "meaning": "雪；下雪", "pos": "adj."}, {"id": "pep_390", "word": "wind", "phonetic": "/wɪnd/", "syllables": ["wind"], "chinese": "风", "grade": 3, "unit": "自然与时节", "example": "The north wind blows chilly.", "gradeName": "三年级", "meaning": "风", "pos": "adj."}, {"id": "pep_391", "word": "rainbow", "phonetic": "/ˈreɪnbəʊ/", "syllables": ["rain", "bow"], "chinese": "彩虹", "grade": 3, "unit": "自然与时节", "example": "A bright rainbow appears after rain.", "gradeName": "三年级", "meaning": "彩虹", "pos": "n."}, {"id": "pep_392", "word": "tree", "phonetic": "/triː/", "syllables": ["tree"], "chinese": "树木", "grade": 4, "unit": "自然与时节", "example": "Birds nest on tall oak tree.", "gradeName": "四年级", "meaning": "树木", "pos": "n."}, {"id": "pep_393", "word": "flower", "phonetic": "/ˈflaʊə(r)/", "syllables": ["flow", "er"], "chinese": "花朵", "grade": 4, "unit": "自然与时节", "example": "The jasmine flower smells sweet.", "gradeName": "四年级", "meaning": "花朵", "pos": "n."}, {"id": "pep_394", "word": "grass", "phonetic": "/ɡrɑːs/", "syllables": ["grass"], "chinese": "草坪；青草", "grade": 4, "unit": "自然与时节", "example": "Do not step on green grass.", "gradeName": "四年级", "meaning": "草坪；青草", "pos": "n."}, {"id": "pep_395", "word": "leaf", "phonetic": "/liːf/", "syllables": ["leaf"], "chinese": "树叶（单数）", "grade": 4, "unit": "自然与时节", "example": "A maple leaf falls gently.", "gradeName": "四年级", "meaning": "树叶（单数）", "pos": "n."}, {"id": "pep_396", "word": "leaves", "phonetic": "/liːvz/", "syllables": ["leaves"], "chinese": "树叶（复数）", "grade": 4, "unit": "自然与时节", "example": "Golden leaves flutter down.", "gradeName": "四年级", "meaning": "树叶（复数）", "pos": "n."}, {"id": "pep_397", "word": "river", "phonetic": "/ˈrɪvə(r)/", "syllables": ["riv", "er"], "chinese": "河流", "grade": 4, "unit": "自然与时节", "example": "Boats float down the wide river.", "gradeName": "四年级", "meaning": "河流", "pos": "n."}, {"id": "pep_398", "word": "lake", "phonetic": "/leɪk/", "syllables": ["lake"], "chinese": "湖泊", "grade": 4, "unit": "自然与时节", "example": "The lake is smooth as glass.", "gradeName": "四年级", "meaning": "湖泊", "pos": "n."}, {"id": "pep_399", "word": "sea", "phonetic": "/siː/", "syllables": ["sea"], "chinese": "海洋；大海", "grade": 4, "unit": "自然与时节", "example": "Waves crash against the blue sea.", "gradeName": "四年级", "meaning": "海洋；大海", "pos": "n."}, {"id": "pep_400", "word": "ocean", "phonetic": "/ˈəʊʃn/", "syllables": ["o", "cean"], "chinese": "大洋；大洋洲", "grade": 5, "unit": "自然与时节", "example": "Pacific Ocean is enormous.", "gradeName": "五年级", "meaning": "大洋；大洋洲", "pos": "adj."}, {"id": "pep_401", "word": "mountain", "phonetic": "/ˈmaʊntən/", "syllables": ["moun", "tain"], "chinese": "高山；山峰", "grade": 4, "unit": "自然与时节", "example": "Climb to the top of the mountain.", "gradeName": "四年级", "meaning": "高山；山峰", "pos": "adj."}, {"id": "pep_402", "word": "hill", "phonetic": "/hɪl/", "syllables": ["hill"], "chinese": "小山；丘陵", "grade": 4, "unit": "自然与时节", "example": "Sheep graze on the green hill.", "gradeName": "四年级", "meaning": "小山；丘陵", "pos": "adj."}, {"id": "pep_403", "word": "forest", "phonetic": "/ˈfɒrɪst/", "syllables": ["for", "est"], "chinese": "森林", "grade": 4, "unit": "自然与时节", "example": "Deer live in lush forest.", "gradeName": "四年级", "meaning": "森林", "pos": "n."}, {"id": "pep_404", "word": "earth", "phonetic": "/ɜːθ/", "syllables": ["earth"], "chinese": "地球；大地", "grade": 5, "unit": "自然与时节", "example": "Protect our shared mother Earth.", "gradeName": "五年级", "meaning": "地球；大地", "pos": "n."}, {"id": "pep_405", "word": "weather", "phonetic": "/ˈweðə(r)/", "syllables": ["weath", "er"], "chinese": "天气", "grade": 3, "unit": "自然与时节", "example": "What is the weather like?", "gradeName": "三年级", "meaning": "天气", "pos": "n."}, {"id": "pep_406", "word": "sunny", "phonetic": "/ˈsʌni/", "syllables": ["sun", "ny"], "chinese": "晴朗的", "grade": 3, "unit": "自然与时节", "example": "It is a sunny Sunday.", "gradeName": "三年级", "meaning": "晴朗的", "pos": "adj."}, {"id": "pep_407", "word": "rainy", "phonetic": "/ˈreɪni/", "syllables": ["rain", "y"], "chinese": "下雨的", "grade": 3, "unit": "自然与时节", "example": "Take an umbrella on rainy days.", "gradeName": "三年级", "meaning": "下雨的", "pos": "n."}, {"id": "pep_408", "word": "windy", "phonetic": "/ˈwɪndi/", "syllables": ["wind", "y"], "chinese": "刮风的", "grade": 3, "unit": "自然与时节", "example": "Fly a kite on a windy afternoon.", "gradeName": "三年级", "meaning": "刮风的", "pos": "n."}, {"id": "pep_409", "word": "cloudy", "phonetic": "/ˈklaʊdi/", "syllables": ["cloud", "y"], "chinese": "多云的", "grade": 3, "unit": "自然与时节", "example": "The sky is overcast and cloudy.", "gradeName": "三年级", "meaning": "多云的", "pos": "adj."}, {"id": "pep_410", "word": "snowy", "phonetic": "/ˈsnəʊi/", "syllables": ["snow", "y"], "chinese": "下雪的", "grade": 3, "unit": "自然与时节", "example": "Build a snowman on snowy days.", "gradeName": "三年级", "meaning": "下雪的", "pos": "n."}, {"id": "pep_411", "word": "warm", "phonetic": "/wɔːm/", "syllables": ["warm"], "chinese": "温暖的", "grade": 3, "unit": "自然与时节", "example": "Spring days are sunny and warm.", "gradeName": "三年级", "meaning": "温暖的", "pos": "n."}, {"id": "pep_412", "word": "hot", "phonetic": "/hɒt/", "syllables": ["hot"], "chinese": "炎热的", "grade": 3, "unit": "自然与时节", "example": "Summer afternoons are very hot.", "gradeName": "三年级", "meaning": "炎热的", "pos": "n."}, {"id": "pep_413", "word": "cool", "phonetic": "/kuːl/", "syllables": ["cool"], "chinese": "凉爽的", "grade": 3, "unit": "自然与时节", "example": "Autumn breeze is nice and cool.", "gradeName": "三年级", "meaning": "凉爽的", "pos": "adj."}, {"id": "pep_414", "word": "today", "phonetic": "/təˈdeɪ/", "syllables": ["to", "day"], "chinese": "今天", "grade": 3, "unit": "时间日历", "example": "Today is full of new hope.", "gradeName": "三年级", "meaning": "今天", "pos": "n."}, {"id": "pep_415", "word": "tomorrow", "phonetic": "/təˈmɒrəʊ/", "syllables": ["to", "mor", "row"], "chinese": "明天", "grade": 3, "unit": "时间日历", "example": "Tomorrow will be brighter.", "gradeName": "三年级", "meaning": "明天", "pos": "n."}, {"id": "pep_416", "word": "yesterday", "phonetic": "/ˈjestədeɪ/", "syllables": ["yes", "ter", "day"], "chinese": "昨天", "grade": 3, "unit": "时间日历", "example": "Yesterday all my troubles seemed away.", "gradeName": "三年级", "meaning": "昨天", "pos": "n."}, {"id": "pep_417", "word": "day", "phonetic": "/deɪ/", "syllables": ["day"], "chinese": "天；白天", "grade": 3, "unit": "时间日历", "example": "Have a wonderful day!", "gradeName": "三年级", "meaning": "天；白天", "pos": "n."}, {"id": "pep_418", "word": "week", "phonetic": "/wiːk/", "syllables": ["week"], "chinese": "星期；周", "grade": 3, "unit": "时间日历", "example": "Seven days in a week.", "gradeName": "三年级", "meaning": "星期；周", "pos": "n."}, {"id": "pep_419", "word": "month", "phonetic": "/mʌnθ/", "syllables": ["month"], "chinese": "月份", "grade": 5, "unit": "时间日历", "example": "Twelve months in one year.", "gradeName": "五年级", "meaning": "月份", "pos": "n."}, {"id": "pep_420", "word": "year", "phonetic": "/jɪə(r)/", "syllables": ["year"], "chinese": "年；年度", "grade": 5, "unit": "时间日历", "example": "Wish you a prosperous year.", "gradeName": "五年级", "meaning": "年；年度", "pos": "adj."}, {"id": "pep_421", "word": "time", "phonetic": "/taɪm/", "syllables": ["time"], "chinese": "时间", "grade": 3, "unit": "时间日历", "example": "Time flies like an arrow.", "gradeName": "三年级", "meaning": "时间", "pos": "n."}, {"id": "pep_422", "word": "o'clock", "phonetic": "/əˈklɒk/", "syllables": ["o", "clock"], "chinese": "……点钟", "grade": 3, "unit": "时间日历", "example": "Class begins at eight o'clock.", "gradeName": "三年级", "meaning": "……点钟", "pos": "n."}, {"id": "pep_423", "word": "hour", "phonetic": "/ˈaʊə(r)/", "syllables": ["hour"], "chinese": "小时", "grade": 4, "unit": "时间日历", "example": "Sixty minutes in an hour.", "gradeName": "四年级", "meaning": "小时", "pos": "adj."}, {"id": "pep_424", "word": "minute", "phonetic": "/ˈmɪnɪt/", "syllables": ["min", "ute"], "chinese": "分钟", "grade": 4, "unit": "时间日历", "example": "Wait for just one minute.", "gradeName": "四年级", "meaning": "分钟", "pos": "n."}, {"id": "pep_425", "word": "Monday", "phonetic": "/ˈmʌndeɪ/", "syllables": ["Mon", "day"], "chinese": "星期一", "grade": 3, "unit": "时间日历", "example": "School starts on Monday.", "gradeName": "三年级", "meaning": "星期一", "pos": "n."}, {"id": "pep_426", "word": "Tuesday", "phonetic": "/ˈtjuːzdeɪ/", "syllables": ["Tues", "day"], "chinese": "星期二", "grade": 3, "unit": "时间日历", "example": "We have English on Tuesday.", "gradeName": "三年级", "meaning": "星期二", "pos": "n."}, {"id": "pep_427", "word": "Wednesday", "phonetic": "/ˈwenzdeɪ/", "syllables": ["Wednes", "day"], "chinese": "星期三", "grade": 3, "unit": "时间日历", "example": "Wednesday is middle of week.", "gradeName": "三年级", "meaning": "星期三", "pos": "n."}, {"id": "pep_428", "word": "Thursday", "phonetic": "/ˈθɜːzdeɪ/", "syllables": ["Thurs", "day"], "chinese": "星期四", "grade": 3, "unit": "时间日历", "example": "Math test is on Thursday.", "gradeName": "三年级", "meaning": "星期四", "pos": "n."}, {"id": "pep_429", "word": "Friday", "phonetic": "/ˈfraɪdeɪ/", "syllables": ["Fri", "day"], "chinese": "星期五", "grade": 3, "unit": "时间日历", "example": "Friday evening is relaxing.", "gradeName": "三年级", "meaning": "星期五", "pos": "n."}, {"id": "pep_430", "word": "Saturday", "phonetic": "/ˈsætədeɪ/", "syllables": ["Sat", "ur", "day"], "chinese": "星期六", "grade": 3, "unit": "时间日历", "example": "We go camping on Saturday.", "gradeName": "三年级", "meaning": "星期六", "pos": "n."}, {"id": "pep_431", "word": "Sunday", "phonetic": "/ˈsʌndeɪ/", "syllables": ["Sun", "day"], "chinese": "星期日", "grade": 3, "unit": "时间日历", "example": "Visit grandparents on Sunday.", "gradeName": "三年级", "meaning": "星期日", "pos": "n."}, {"id": "pep_432", "word": "weekend", "phonetic": "/ˌwiːkˈend/", "syllables": ["week", "end"], "chinese": "周末", "grade": 3, "unit": "时间日历", "example": "Enjoy your restful weekend.", "gradeName": "三年级", "meaning": "周末", "pos": "n."}, {"id": "pep_433", "word": "January", "phonetic": "/ˈdʒænjuəri/", "syllables": ["Jan", "u", "ar", "y"], "chinese": "一月", "grade": 5, "unit": "时间日历", "example": "New Year arrives in January.", "gradeName": "五年级", "meaning": "一月", "pos": "n."}, {"id": "pep_434", "word": "February", "phonetic": "/ˈfebruəri/", "syllables": ["Feb", "ru", "ar", "y"], "chinese": "二月", "grade": 5, "unit": "时间日历", "example": "Spring Festival is in February.", "gradeName": "五年级", "meaning": "二月", "pos": "n."}, {"id": "pep_435", "word": "March", "phonetic": "/mɑːtʃ/", "syllables": ["March"], "chinese": "三月", "grade": 5, "unit": "时间日历", "example": "Plant green trees in March.", "gradeName": "五年级", "meaning": "三月", "pos": "n."}, {"id": "pep_436", "word": "April", "phonetic": "/ˈeɪprəl/", "syllables": ["A", "pril"], "chinese": "四月", "grade": 5, "unit": "时间日历", "example": "Warm April winds bring blooming flora.", "gradeName": "五年级", "meaning": "四月", "pos": "n."}, {"id": "pep_437", "word": "May", "phonetic": "/meɪ/", "syllables": ["May"], "chinese": "五月", "grade": 5, "unit": "时间日历", "example": "Labor Day is in early May.", "gradeName": "五年级", "meaning": "五月", "pos": "n."}, {"id": "pep_438", "word": "June", "phonetic": "/dʒuːn/", "syllables": ["June"], "chinese": "六月", "grade": 5, "unit": "时间日历", "example": "Children's Day is in June.", "gradeName": "五年级", "meaning": "六月", "pos": "n."}, {"id": "pep_439", "word": "July", "phonetic": "/dʒuˈlaɪ/", "syllables": ["Ju", "ly"], "chinese": "七月", "grade": 5, "unit": "时间日历", "example": "Summer holiday starts in July.", "gradeName": "五年级", "meaning": "七月", "pos": "n."}, {"id": "pep_440", "word": "August", "phonetic": "/ɔːˈɡʌst/", "syllables": ["Au", "gust"], "chinese": "八月", "grade": 5, "unit": "时间日历", "example": "Camp by the lakes in August.", "gradeName": "五年级", "meaning": "八月", "pos": "n."}, {"id": "pep_441", "word": "September", "phonetic": "/sepˈtembə(r)/", "syllables": ["Sep", "tem", "ber"], "chinese": "九月", "grade": 5, "unit": "时间日历", "example": "New school term opens September.", "gradeName": "五年级", "meaning": "九月", "pos": "n."}, {"id": "pep_442", "word": "October", "phonetic": "/ɒkˈtəʊbə(r)/", "syllables": ["Oc", "to", "ber"], "chinese": "十月", "grade": 5, "unit": "时间日历", "example": "National Day is in October.", "gradeName": "五年级", "meaning": "十月", "pos": "n."}, {"id": "pep_443", "word": "November", "phonetic": "/nəʊˈvembə(r)/", "syllables": ["No", "vem", "ber"], "chinese": "十一月", "grade": 5, "unit": "时间日历", "example": "Leaves tumble down in November.", "gradeName": "五年级", "meaning": "十一月", "pos": "n."}, {"id": "pep_444", "word": "December", "phonetic": "/dɪˈsembə(r)/", "syllables": ["De", "cem", "ber"], "chinese": "十二月", "grade": 5, "unit": "时间日历", "example": "December concludes a good year.", "gradeName": "五年级", "meaning": "十二月", "pos": "n."}, {"id": "pep_445", "word": "play", "phonetic": "/pleɪ/", "syllables": ["play"], "chinese": "玩耍；演奏", "grade": 3, "unit": "动作与日常", "example": "Play soccer in playground.", "gradeName": "三年级", "meaning": "玩耍；演奏", "pos": "v."}, {"id": "pep_446", "word": "sing", "phonetic": "/sɪŋ/", "syllables": ["sing"], "chinese": "唱歌", "grade": 3, "unit": "动作与日常", "example": "Sing an English song aloud.", "gradeName": "三年级", "meaning": "唱歌", "pos": "v."}, {"id": "pep_447", "word": "dance", "phonetic": "/dɑːns/", "syllables": ["dance"], "chinese": "跳舞", "grade": 3, "unit": "动作与日常", "example": "Dance with the happy rhythm.", "gradeName": "三年级", "meaning": "跳舞", "pos": "v."}, {"id": "pep_448", "word": "draw", "phonetic": "/drɔː/", "syllables": ["draw"], "chinese": "绘画；画画", "grade": 3, "unit": "动作与日常", "example": "Draw a picture with colors.", "gradeName": "三年级", "meaning": "绘画；画画", "pos": "n."}, {"id": "pep_449", "word": "read", "phonetic": "/riːd/", "syllables": ["read"], "chinese": "阅读；读书", "grade": 3, "unit": "动作与日常", "example": "Read good books every evening.", "gradeName": "三年级", "meaning": "阅读；读书", "pos": "n."}, {"id": "pep_450", "word": "write", "phonetic": "/raɪt/", "syllables": ["write"], "chinese": "写；书写", "grade": 3, "unit": "动作与日常", "example": "Write neatly with your pencil.", "gradeName": "三年级", "meaning": "写；书写", "pos": "v."}, {"id": "pep_451", "word": "swim", "phonetic": "/swɪm/", "syllables": ["swim"], "chinese": "游泳", "grade": 3, "unit": "动作与日常", "example": "Swim fast like a little fish.", "gradeName": "三年级", "meaning": "游泳", "pos": "v."}, {"id": "pep_452", "word": "run", "phonetic": "/rʌn/", "syllables": ["run"], "chinese": "跑步", "grade": 3, "unit": "动作与日常", "example": "Run three rounds every morning.", "gradeName": "三年级", "meaning": "跑步", "pos": "v."}, {"id": "pep_453", "word": "jump", "phonetic": "/dʒʌmp/", "syllables": ["jump"], "chinese": "跳跃", "grade": 3, "unit": "动作与日常", "example": "Jump over the low fence.", "gradeName": "三年级", "meaning": "跳跃", "pos": "v."}, {"id": "pep_454", "word": "fly", "phonetic": "/flaɪ/", "syllables": ["fly"], "chinese": "飞；放飞", "grade": 3, "unit": "动作与日常", "example": "Birds fly high in the air.", "gradeName": "三年级", "meaning": "飞；放飞", "pos": "v."}, {"id": "pep_455", "word": "walk", "phonetic": "/wɔːk/", "syllables": ["walk"], "chinese": "步行；散步", "grade": 3, "unit": "动作与日常", "example": "Take a peaceful walk in garden.", "gradeName": "三年级", "meaning": "步行；散步", "pos": "n."}, {"id": "pep_456", "word": "sleep", "phonetic": "/sliːp/", "syllables": ["sleep"], "chinese": "睡眠；睡觉", "grade": 3, "unit": "动作与日常", "example": "Sleep eight hours every night.", "gradeName": "三年级", "meaning": "睡眠；睡觉", "pos": "v."}, {"id": "pep_457", "word": "wake", "phonetic": "/weɪk/", "syllables": ["wake"], "chinese": "醒来；唤醒", "grade": 4, "unit": "动作与日常", "example": "Wake up early at sunrise.", "gradeName": "四年级", "meaning": "醒来；唤醒", "pos": "n."}, {"id": "pep_458", "word": "wash", "phonetic": "/wɒʃ/", "syllables": ["wash"], "chinese": "清洗；洗手", "grade": 3, "unit": "动作与日常", "example": "Wash your hands before eating.", "gradeName": "三年级", "meaning": "清洗；洗手", "pos": "n."}, {"id": "pep_459", "word": "clean", "phonetic": "/kliːn/", "syllables": ["clean"], "chinese": "打扫；干净的", "grade": 3, "unit": "动作与日常", "example": "Clean the classroom chalkboard.", "gradeName": "三年级", "meaning": "打扫；干净的", "pos": "v."}, {"id": "pep_460", "word": "listen", "phonetic": "/ˈlɪsn/", "syllables": ["lis", "ten"], "chinese": "倾听；听", "grade": 3, "unit": "动作与日常", "example": "Listen carefully in the lecture.", "gradeName": "三年级", "meaning": "倾听；听", "pos": "n."}, {"id": "pep_461", "word": "hear", "phonetic": "/hɪə(r)/", "syllables": ["hear"], "chinese": "听见；听到", "grade": 4, "unit": "动作与日常", "example": "Hear melodic birdsong outside.", "gradeName": "四年级", "meaning": "听见；听到", "pos": "v."}, {"id": "pep_462", "word": "speak", "phonetic": "/spiːk/", "syllables": ["speak"], "chinese": "说；讲（语言）", "grade": 3, "unit": "动作与日常", "example": "Speak English with confidence.", "gradeName": "三年级", "meaning": "说；讲（语言）", "pos": "v."}, {"id": "pep_463", "word": "talk", "phonetic": "/tɔːk/", "syllables": ["talk"], "chinese": "谈话；交谈", "grade": 3, "unit": "动作与日常", "example": "Talk with your good teacher.", "gradeName": "三年级", "meaning": "谈话；交谈", "pos": "n."}, {"id": "pep_464", "word": "tell", "phonetic": "/tel/", "syllables": ["tell"], "chinese": "告诉；讲述", "grade": 3, "unit": "动作与日常", "example": "Tell an interesting bedtime tale.", "gradeName": "三年级", "meaning": "告诉；讲述", "pos": "n."}, {"id": "pep_465", "word": "say", "phonetic": "/seɪ/", "syllables": ["say"], "chinese": "说；讲", "grade": 2, "unit": "动作与日常", "example": "Say thank you politely.", "gradeName": "二年级", "meaning": "说；讲", "pos": "v."}, {"id": "pep_466", "word": "ask", "phonetic": "/ɑːsk/", "syllables": ["ask"], "chinese": "询问；请求", "grade": 3, "unit": "动作与日常", "example": "Ask teacher for assistance.", "gradeName": "三年级", "meaning": "询问；请求", "pos": "n."}, {"id": "pep_467", "word": "answer", "phonetic": "/ˈɑːnsə(r)/", "syllables": ["an", "swer"], "chinese": "回答；答案", "grade": 3, "unit": "动作与日常", "example": "Answer questions correctly.", "gradeName": "三年级", "meaning": "回答；答案", "pos": "n."}, {"id": "pep_468", "word": "watch", "phonetic": "/wɒtʃ/", "syllables": ["watch"], "chinese": "观看；手表", "grade": 3, "unit": "动作与日常", "example": "Watch interesting science videos.", "gradeName": "三年级", "meaning": "观看；手表", "pos": "n."}, {"id": "pep_469", "word": "look", "phonetic": "/lʊk/", "syllables": ["look"], "chinese": "看；瞧", "grade": 1, "unit": "动作与日常", "example": "Look at the flying plane!", "gradeName": "一年级", "meaning": "看；瞧", "pos": "v."}, {"id": "pep_470", "word": "see", "phonetic": "/siː/", "syllables": ["see"], "chinese": "看见；明白", "grade": 1, "unit": "动作与日常", "example": "See you again next Monday.", "gradeName": "一年级", "meaning": "看见；明白", "pos": "v."}, {"id": "pep_471", "word": "smell", "phonetic": "/smel/", "syllables": ["smell"], "chinese": "闻；嗅；气味", "grade": 4, "unit": "动作与日常", "example": "Smell the sweet jasmine.", "gradeName": "四年级", "meaning": "闻；嗅；气味", "pos": "n."}, {"id": "pep_472", "word": "taste", "phonetic": "/teɪst/", "syllables": ["taste"], "chinese": "品尝；味道", "grade": 4, "unit": "动作与日常", "example": "Taste the crispy cookies.", "gradeName": "四年级", "meaning": "品尝；味道", "pos": "n."}, {"id": "pep_473", "word": "touch", "phonetic": "/tʌtʃ/", "syllables": ["touch"], "chinese": "触摸；接触", "grade": 2, "unit": "动作与日常", "example": "Touch your nose softly.", "gradeName": "二年级", "meaning": "触摸；接触", "pos": "n."}, {"id": "pep_474", "word": "feel", "phonetic": "/fiːl/", "syllables": ["feel"], "chinese": "感觉；觉得", "grade": 5, "unit": "动作与日常", "example": "I feel healthy and vibrant.", "gradeName": "五年级", "meaning": "感觉；觉得", "pos": "n."}, {"id": "pep_475", "word": "think", "phonetic": "/θɪŋk/", "syllables": ["think"], "chinese": "思考；认为", "grade": 4, "unit": "动作与日常", "example": "Think twice before acting.", "gradeName": "四年级", "meaning": "思考；认为", "pos": "n."}, {"id": "pep_476", "word": "know", "phonetic": "/nəʊ/", "syllables": ["know"], "chinese": "知道；了解", "grade": 3, "unit": "动作与日常", "example": "Do you know the answer?", "gradeName": "三年级", "meaning": "知道；了解", "pos": "n."}, {"id": "pep_477", "word": "learn", "phonetic": "/lɜːn/", "syllables": ["learn"], "chinese": "学习；学会", "grade": 3, "unit": "动作与日常", "example": "Learn new skills enthusiastically.", "gradeName": "三年级", "meaning": "学习；学会", "pos": "v."}, {"id": "pep_478", "word": "teach", "phonetic": "/tiːtʃ/", "syllables": ["teach"], "chinese": "教学；教授", "grade": 3, "unit": "动作与日常", "example": "Teach children with patience.", "gradeName": "三年级", "meaning": "教学；教授", "pos": "v."}, {"id": "pep_479", "word": "help", "phonetic": "/help/", "syllables": ["help"], "chinese": "帮助；援助", "grade": 2, "unit": "动作与日常", "example": "Help peers overcome difficulty.", "gradeName": "二年级", "meaning": "帮助；援助", "pos": "v."}, {"id": "pep_480", "word": "make", "phonetic": "/meɪk/", "syllables": ["make"], "chinese": "制作；使得", "grade": 3, "unit": "动作与日常", "example": "Make a birthday greeting card.", "gradeName": "三年级", "meaning": "制作；使得", "pos": "n."}, {"id": "pep_481", "word": "do", "phonetic": "/duː/", "syllables": ["do"], "chinese": "做；干", "grade": 2, "unit": "动作与日常", "example": "Do your morning exercises.", "gradeName": "二年级", "meaning": "做；干", "pos": "v."}, {"id": "pep_482", "word": "have", "phonetic": "/hæv/", "syllables": ["have"], "chinese": "有；吃；举行", "grade": 1, "unit": "动作与日常", "example": "Have a cup of warm tea.", "gradeName": "一年级", "meaning": "有；吃；举行", "pos": "v."}, {"id": "pep_483", "word": "give", "phonetic": "/ɡɪv/", "syllables": ["give"], "chinese": "给予；递给", "grade": 2, "unit": "动作与日常", "example": "Give flowers to your mother.", "gradeName": "二年级", "meaning": "给予；递给", "pos": "v."}, {"id": "pep_484", "word": "take", "phonetic": "/teɪk/", "syllables": ["take"], "chinese": "带走；花费；拍照", "grade": 2, "unit": "动作与日常", "example": "Take an umbrella on trip.", "gradeName": "二年级", "meaning": "带走；花费；拍照", "pos": "v."}, {"id": "pep_485", "word": "bring", "phonetic": "/brɪŋ/", "syllables": ["bring"], "chinese": "带来；拿来", "grade": 3, "unit": "动作与日常", "example": "Bring your dictionary tomorrow.", "gradeName": "三年级", "meaning": "带来；拿来", "pos": "v."}, {"id": "pep_486", "word": "buy", "phonetic": "/baɪ/", "syllables": ["buy"], "chinese": "购买；买", "grade": 3, "unit": "动作与日常", "example": "Buy fresh apples at supermarket.", "gradeName": "三年级", "meaning": "购买；买", "pos": "n."}, {"id": "pep_487", "word": "sell", "phonetic": "/sel/", "syllables": ["sell"], "chinese": "卖；出售", "grade": 4, "unit": "动作与日常", "example": "Sell homemade lemonade.", "gradeName": "四年级", "meaning": "卖；出售", "pos": "n."}, {"id": "pep_488", "word": "find", "phonetic": "/faɪnd/", "syllables": ["find"], "chinese": "找到；发现", "grade": 3, "unit": "动作与日常", "example": "Find the lost keys quickly.", "gradeName": "三年级", "meaning": "找到；发现", "pos": "v."}, {"id": "pep_489", "word": "lose", "phonetic": "/luːz/", "syllables": ["lose"], "chinese": "丢失；失败", "grade": 4, "unit": "动作与日常", "example": "Do not lose courage.", "gradeName": "四年级", "meaning": "丢失；失败", "pos": "n."}, {"id": "pep_490", "word": "win", "phonetic": "/wɪn/", "syllables": ["win"], "chinese": "获胜；赢取", "grade": 4, "unit": "动作与日常", "example": "Win the championship trophy.", "gradeName": "四年级", "meaning": "获胜；赢取", "pos": "n."}, {"id": "pep_491", "word": "pass", "phonetic": "/pɑːs/", "syllables": ["pass"], "chinese": "传递；通过", "grade": 3, "unit": "动作与日常", "example": "Please pass me the salt.", "gradeName": "三年级", "meaning": "传递；通过", "pos": "n."}, {"id": "pep_492", "word": "kick", "phonetic": "/kɪk/", "syllables": ["kick"], "chinese": "踢", "grade": 2, "unit": "动作与日常", "example": "Kick soccer ball into goal.", "gradeName": "二年级", "meaning": "踢", "pos": "v."}, {"id": "pep_493", "word": "catch", "phonetic": "/kætʃ/", "syllables": ["catch"], "chinese": "抓住；赶上", "grade": 3, "unit": "动作与日常", "example": "Catch the flying frisbee.", "gradeName": "三年级", "meaning": "抓住；赶上", "pos": "v."}, {"id": "pep_494", "word": "throw", "phonetic": "/θrəʊ/", "syllables": ["throw"], "chinese": "投掷；扔", "grade": 3, "unit": "动作与日常", "example": "Throw the ball to your teammate.", "gradeName": "三年级", "meaning": "投掷；扔", "pos": "n."}, {"id": "pep_495", "word": "hit", "phonetic": "/hɪt/", "syllables": ["hit"], "chinese": "击打；撞击", "grade": 4, "unit": "动作与日常", "example": "Hit the baseball with bat.", "gradeName": "四年级", "meaning": "击打；撞击", "pos": "n."}, {"id": "pep_496", "word": "climb", "phonetic": "/klaɪm/", "syllables": ["climb"], "chinese": "攀爬；爬山", "grade": 3, "unit": "动作与日常", "example": "Climb the hill to watch sunrise.", "gradeName": "三年级", "meaning": "攀爬；爬山", "pos": "n."}, {"id": "pep_497", "word": "skate", "phonetic": "/skeɪt/", "syllables": ["skate"], "chinese": "滑冰；溜冰", "grade": 4, "unit": "动作与日常", "example": "Skate on frozen winter lake.", "gradeName": "四年级", "meaning": "滑冰；溜冰", "pos": "v."}, {"id": "pep_498", "word": "ski", "phonetic": "/skiː/", "syllables": ["ski"], "chinese": "滑雪", "grade": 4, "unit": "动作与日常", "example": "Ski down the snowy slope.", "gradeName": "四年级", "meaning": "滑雪", "pos": "v."}, {"id": "pep_499", "word": "ride", "phonetic": "/raɪd/", "syllables": ["ride"], "chinese": "骑乘（车或马）", "grade": 3, "unit": "动作与日常", "example": "Ride your bike with helmet.", "gradeName": "三年级", "meaning": "骑乘（车或马）", "pos": "v."}, {"id": "pep_500", "word": "drive", "phonetic": "/draɪv/", "syllables": ["drive"], "chinese": "驾驶；开车", "grade": 3, "unit": "动作与日常", "example": "Drive safely on wet roads.", "gradeName": "三年级", "meaning": "驾驶；开车", "pos": "n."}, {"id": "pep_501", "word": "travel", "phonetic": "/ˈtrævl/", "syllables": ["trav", "el"], "chinese": "旅游；旅行", "grade": 5, "unit": "动作与日常", "example": "Travel broadens youthful horizons.", "gradeName": "五年级", "meaning": "旅游；旅行", "pos": "v."}, {"id": "pep_502", "word": "visit", "phonetic": "/ˈvɪzɪt/", "syllables": ["vis", "it"], "chinese": "拜访；参观", "grade": 5, "unit": "动作与日常", "example": "Visit historic museums in Beijing.", "gradeName": "五年级", "meaning": "拜访；参观", "pos": "n."}, {"id": "pep_503", "word": "stay", "phonetic": "/steɪ/", "syllables": ["stay"], "chinese": "停留；暂住", "grade": 4, "unit": "动作与日常", "example": "Stay healthy and active.", "gradeName": "四年级", "meaning": "停留；暂住", "pos": "n."}, {"id": "pep_504", "word": "live", "phonetic": "/lɪv/", "syllables": ["live"], "chinese": "居住；生活", "grade": 3, "unit": "动作与日常", "example": "Live in a peaceful community.", "gradeName": "三年级", "meaning": "居住；生活", "pos": "n."}, {"id": "pep_505", "word": "wait", "phonetic": "/weɪt/", "syllables": ["wait"], "chinese": "等待；等候", "grade": 3, "unit": "动作与日常", "example": "Wait for the green light.", "gradeName": "三年级", "meaning": "等待；等候", "pos": "v."}, {"id": "pep_506", "word": "open", "phonetic": "/ˈəʊpən/", "syllables": ["o", "pen"], "chinese": "打开；开着的", "grade": 1, "unit": "动作与日常", "example": "Open the door for guests.", "gradeName": "一年级", "meaning": "打开；开着的", "pos": "v."}, {"id": "pep_507", "word": "close", "phonetic": "/kləʊz/", "syllables": ["close"], "chinese": "关闭；合上", "grade": 1, "unit": "动作与日常", "example": "Close your textbooks now.", "gradeName": "一年级", "meaning": "关闭；合上", "pos": "v."}, {"id": "pep_508", "word": "cut", "phonetic": "/kʌt/", "syllables": ["cut"], "chinese": "剪切；切开", "grade": 2, "unit": "动作与日常", "example": "Cut paper into star shapes.", "gradeName": "二年级", "meaning": "剪切；切开", "pos": "n."}, {"id": "pep_509", "word": "put", "phonetic": "/pʊt/", "syllables": ["put"], "chinese": "放置；安置", "grade": 2, "unit": "动作与日常", "example": "Put pencils inside the box.", "gradeName": "二年级", "meaning": "放置；安置", "pos": "v."}, {"id": "pep_510", "word": "pick", "phonetic": "/pɪk/", "syllables": ["pick"], "chinese": "采摘；挑选", "grade": 3, "unit": "动作与日常", "example": "Pick sweet ripe apples.", "gradeName": "三年级", "meaning": "采摘；挑选", "pos": "n."}, {"id": "pep_511", "word": "plant", "phonetic": "/plɑːnt/", "syllables": ["plant"], "chinese": "种植；植物", "grade": 3, "unit": "动作与日常", "example": "Plant a leafy green tree.", "gradeName": "三年级", "meaning": "种植；植物", "pos": "v."}, {"id": "pep_512", "word": "grow", "phonetic": "/ɡrəʊ/", "syllables": ["grow"], "chinese": "生长；种植", "grade": 4, "unit": "动作与日常", "example": "Sunflowers grow towards sun.", "gradeName": "四年级", "meaning": "生长；种植", "pos": "adj."}, {"id": "pep_513", "word": "feed", "phonetic": "/fiːd/", "syllables": ["feed"], "chinese": "喂养；饲育", "grade": 3, "unit": "动作与日常", "example": "Feed the fluffy ducks grain.", "gradeName": "三年级", "meaning": "喂养；饲育", "pos": "v."}, {"id": "pep_514", "word": "bake", "phonetic": "/beɪk/", "syllables": ["bake"], "chinese": "烘烤；烤制", "grade": 4, "unit": "动作与日常", "example": "Bake crispy cookies.", "gradeName": "四年级", "meaning": "烘烤；烤制", "pos": "n."}, {"id": "pep_515", "word": "sweep", "phonetic": "/swiːp/", "syllables": ["sweep"], "chinese": "扫除；打扫", "grade": 3, "unit": "动作与日常", "example": "Sweep the porch floor.", "gradeName": "三年级", "meaning": "扫除；打扫", "pos": "v."}, {"id": "pep_516", "word": "mop", "phonetic": "/mɒp/", "syllables": ["mop"], "chinese": "拖地；拖把", "grade": 4, "unit": "动作与日常", "example": "Mop the kitchen tiles.", "gradeName": "四年级", "meaning": "拖地；拖把", "pos": "v."}, {"id": "pep_517", "word": "tidy", "phonetic": "/ˈtaɪdi/", "syllables": ["ti", "dy"], "chinese": "整理；整洁的", "grade": 4, "unit": "动作与日常", "example": "Tidy up your study desk.", "gradeName": "四年级", "meaning": "整理；整洁的", "pos": "n."}, {"id": "pep_518", "word": "show", "phonetic": "/ʃəʊ/", "syllables": ["show"], "chinese": "展示；出示", "grade": 2, "unit": "动作与日常", "example": "Show me your drawings.", "gradeName": "二年级", "meaning": "展示；出示", "pos": "v."}, {"id": "pep_519", "word": "send", "phonetic": "/send/", "syllables": ["send"], "chinese": "发送；邮寄", "grade": 4, "unit": "动作与日常", "example": "Send a warm holiday greeting.", "gradeName": "四年级", "meaning": "发送；邮寄", "pos": "n."}, {"id": "pep_520", "word": "smile", "phonetic": "/smaɪl/", "syllables": ["smile"], "chinese": "微笑", "grade": 3, "unit": "动作与日常", "example": "Smile brightly at everyone.", "gradeName": "三年级", "meaning": "微笑", "pos": "n."}, {"id": "pep_521", "word": "laugh", "phonetic": "/lɑːf/", "syllables": ["laugh"], "chinese": "发笑；大笑", "grade": 3, "unit": "动作与日常", "example": "Laugh cheerfully at the joke.", "gradeName": "三年级", "meaning": "发笑；大笑", "pos": "n."}, {"id": "pep_522", "word": "cry", "phonetic": "/kraɪ/", "syllables": ["cry"], "chinese": "哭泣；喊叫", "grade": 3, "unit": "动作与日常", "example": "Do not cry over spilled milk.", "gradeName": "三年级", "meaning": "哭泣；喊叫", "pos": "v."}, {"id": "pep_523", "word": "shout", "phonetic": "/ʃaʊt/", "syllables": ["shout"], "chinese": "呼喊；大叫", "grade": 4, "unit": "动作与日常", "example": "Never shout in library.", "gradeName": "四年级", "meaning": "呼喊；大叫", "pos": "n."}, {"id": "pep_524", "word": "start", "phonetic": "/stɑːt/", "syllables": ["start"], "chinese": "开始；出发", "grade": 3, "unit": "动作与日常", "example": "Start your morning journey.", "gradeName": "三年级", "meaning": "开始；出发", "pos": "v."}, {"id": "pep_525", "word": "begin", "phonetic": "/bɪˈɡɪn/", "syllables": ["be", "gin"], "chinese": "开始；着手", "grade": 4, "unit": "动作与日常", "example": "Begin reading the first chapter.", "gradeName": "四年级", "meaning": "开始；着手", "pos": "v."}, {"id": "pep_526", "word": "finish", "phonetic": "/ˈfɪnɪʃ/", "syllables": ["fin", "ish"], "chinese": "完成；结束", "grade": 4, "unit": "动作与日常", "example": "Finish assignments early.", "gradeName": "四年级", "meaning": "完成；结束", "pos": "n."}, {"id": "pep_527", "word": "end", "phonetic": "/end/", "syllables": ["end"], "chinese": "结束；末端", "grade": 3, "unit": "动作与日常", "example": "The happy story has an end.", "gradeName": "三年级", "meaning": "结束；末端", "pos": "v."}, {"id": "pep_528", "word": "try", "phonetic": "/traɪ/", "syllables": ["try"], "chinese": "尝试；努力", "grade": 3, "unit": "动作与日常", "example": "Try your best every time.", "gradeName": "三年级", "meaning": "尝试；努力", "pos": "n."}, {"id": "pep_529", "word": "hope", "phonetic": "/həʊp/", "syllables": ["hope"], "chinese": "希望；期盼", "grade": 6, "unit": "动作与日常", "example": "Never lose hope in tough times.", "gradeName": "六年级", "meaning": "希望；期盼", "pos": "v."}, {"id": "pep_530", "word": "wish", "phonetic": "/wɪʃ/", "syllables": ["wish"], "chinese": "愿望；祝福", "grade": 6, "unit": "动作与日常", "example": "Make a silent wish under stars.", "gradeName": "六年级", "meaning": "愿望；祝福", "pos": "v."}, {"id": "pep_531", "word": "want", "phonetic": "/wɒnt/", "syllables": ["want"], "chinese": "想要；需要", "grade": 2, "unit": "动作与日常", "example": "What do you want for lunch?", "gradeName": "二年级", "meaning": "想要；需要", "pos": "v."}, {"id": "pep_532", "word": "like", "phonetic": "/laɪk/", "syllables": ["like"], "chinese": "喜欢；像", "grade": 1, "unit": "动作与日常", "example": "I like sweet green grapes.", "gradeName": "一年级", "meaning": "喜欢；像", "pos": "v."}, {"id": "pep_533", "word": "love", "phonetic": "/lʌv/", "syllables": ["love"], "chinese": "热爱；关爱", "grade": 1, "unit": "动作与日常", "example": "Love your family and peers.", "gradeName": "一年级", "meaning": "热爱；关爱", "pos": "adj."}, {"id": "pep_534", "word": "need", "phonetic": "/niːd/", "syllables": ["need"], "chinese": "需要；必须", "grade": 3, "unit": "动作与日常", "example": "Plants need water and light.", "gradeName": "三年级", "meaning": "需要；必须", "pos": "v."}, {"id": "pep_535", "word": "can", "phonetic": "/kæn/", "syllables": ["can"], "chinese": "能；能够；罐头", "grade": 1, "unit": "情态动词", "example": "I can speak clear English.", "gradeName": "一年级", "meaning": "能；能够；罐头", "pos": "v."}, {"id": "pep_536", "word": "must", "phonetic": "/mʌst/", "syllables": ["must"], "chinese": "必须；务必", "grade": 4, "unit": "情态动词", "example": "You must obey safety rules.", "gradeName": "四年级", "meaning": "必须；务必", "pos": "v."}, {"id": "pep_537", "word": "should", "phonetic": "/ʃʊd/", "syllables": ["should"], "chinese": "应当；应该", "grade": 5, "unit": "情态动词", "example": "You should eat more veggies.", "gradeName": "五年级", "meaning": "应当；应该", "pos": "v."}, {"id": "pep_538", "word": "will", "phonetic": "/wɪl/", "syllables": ["will"], "chinese": "将要；会", "grade": 5, "unit": "情态动词", "example": "We will visit the museum.", "gradeName": "五年级", "meaning": "将要；会", "pos": "v."}, {"id": "pep_539", "word": "shall", "phonetic": "/ʃæl/", "syllables": ["shall"], "chinese": "将要；会", "grade": 5, "unit": "情态动词", "example": "Shall we begin our reading?", "gradeName": "五年级", "meaning": "将要；会", "pos": "v."}, {"id": "pep_540", "word": "would", "phonetic": "/wʊd/", "syllables": ["would"], "chinese": "将要；愿意", "grade": 4, "unit": "情态动词", "example": "Would you like a fresh pear?", "gradeName": "四年级", "meaning": "将要；愿意", "pos": "v."}, {"id": "pep_541", "word": "could", "phonetic": "/kʊd/", "syllables": ["could"], "chinese": "能够（can过去式）", "grade": 5, "unit": "情态动词", "example": "Could you lend me a hand?", "gradeName": "五年级", "meaning": "能够（can过去式）", "pos": "v."}, {"id": "pep_542", "word": "went", "phonetic": "/went/", "syllables": ["went"], "chinese": "去（go过去式）", "grade": 6, "unit": "不规则过去式", "example": "We went to Shanghai last summer.", "gradeName": "六年级", "meaning": "去（go过去式）", "pos": "v."}, {"id": "pep_543", "word": "saw", "phonetic": "/sɔː/", "syllables": ["saw"], "chinese": "看见（see过去式）", "grade": 6, "unit": "不规则过去式", "example": "I saw a magnificent rainbow.", "gradeName": "六年级", "meaning": "看见（see过去式）", "pos": "v."}, {"id": "pep_544", "word": "ate", "phonetic": "/eɪt/", "syllables": ["ate"], "chinese": "吃（eat过去式）", "grade": 6, "unit": "不规则过去式", "example": "He ate three dumplings for dinner.", "gradeName": "六年级", "meaning": "吃（eat过去式）", "pos": "v."}, {"id": "pep_545", "word": "had", "phonetic": "/hæd/", "syllables": ["had"], "chinese": "有；吃（have过去式）", "grade": 6, "unit": "不规则过去式", "example": "We had a wonderful picnic.", "gradeName": "六年级", "meaning": "有；吃（have过去式）", "pos": "v."}, {"id": "pep_546", "word": "did", "phonetic": "/dɪd/", "syllables": ["did"], "chinese": "做（do过去式）", "grade": 6, "unit": "不规则过去式", "example": "She did all her homework neatly.", "gradeName": "六年级", "meaning": "做（do过去式）", "pos": "v."}, {"id": "pep_547", "word": "was", "phonetic": "/wɒz/", "syllables": ["was"], "chinese": "是（am/is过去式）", "grade": 6, "unit": "不规则过去式", "example": "The weather was sunny yesterday.", "gradeName": "六年级", "meaning": "是（am/is过去式）", "pos": "v."}, {"id": "pep_548", "word": "were", "phonetic": "/wɜː(r)/", "syllables": ["were"], "chinese": "是（are过去式）", "grade": 6, "unit": "不规则过去式", "example": "They were joyful at concert.", "gradeName": "六年级", "meaning": "是（are过去式）", "pos": "v."}, {"id": "pep_549", "word": "bought", "phonetic": "/bɔːt/", "syllables": ["bought"], "chinese": "买（buy过去式）", "grade": 6, "unit": "不规则过去式", "example": "Dad bought a new tablet.", "gradeName": "六年级", "meaning": "买（buy过去式）", "pos": "v."}, {"id": "pep_550", "word": "took", "phonetic": "/tʊk/", "syllables": ["took"], "chinese": "带走（take过去式）", "grade": 6, "unit": "不规则过去式", "example": "He took lots of pictures on trip.", "gradeName": "六年级", "meaning": "带走（take过去式）", "pos": "v."}, {"id": "pep_551", "word": "came", "phonetic": "/keɪm/", "syllables": ["came"], "chinese": "来（come过去式）", "grade": 6, "unit": "不规则过去式", "example": "My cousins came to visit us.", "gradeName": "六年级", "meaning": "来（come过去式）", "pos": "v."}, {"id": "pep_552", "word": "made", "phonetic": "/meɪd/", "syllables": ["made"], "chinese": "做；制造（make过去式）", "grade": 6, "unit": "不规则过去式", "example": "Mom made a honey sponge cake.", "gradeName": "六年级", "meaning": "做；制造（make过去式）", "pos": "v."}, {"id": "pep_553", "word": "wrote", "phonetic": "/rəʊt/", "syllables": ["wrote"], "chinese": "写（write过去式）", "grade": 6, "unit": "不规则过去式", "example": "She wrote a thank-you note.", "gradeName": "六年级", "meaning": "写（write过去式）", "pos": "v."}, {"id": "pep_554", "word": "visited", "phonetic": "/ˈvɪzɪtɪd/", "syllables": ["vis", "it", "ed"], "chinese": "拜访（visit过去式）", "grade": 6, "unit": "规则过去式", "example": "We visited Great Wall in May.", "gradeName": "六年级", "meaning": "拜访（visit过去式）", "pos": "n."}, {"id": "pep_555", "word": "played", "phonetic": "/pleɪd/", "syllables": ["played"], "chinese": "玩（play过去式）", "grade": 6, "unit": "规则过去式", "example": "They played football in rain.", "gradeName": "六年级", "meaning": "玩（play过去式）", "pos": "v."}, {"id": "pep_556", "word": "cleaned", "phonetic": "/kliːnd/", "syllables": ["cleaned"], "chinese": "打扫（clean过去式）", "grade": 6, "unit": "规则过去式", "example": "We cleaned the school garden.", "gradeName": "六年级", "meaning": "打扫（clean过去式）", "pos": "v."}, {"id": "pep_557", "word": "stayed", "phonetic": "/steɪd/", "syllables": ["stayed"], "chinese": "停留（stay过去式）", "grade": 6, "unit": "规则过去式", "example": "I stayed at home and practiced piano.", "gradeName": "六年级", "meaning": "停留（stay过去式）", "pos": "n."}, {"id": "pep_558", "word": "watched", "phonetic": "/wɒtʃt/", "syllables": ["watched"], "chinese": "观看（watch过去式）", "grade": 6, "unit": "规则过去式", "example": "We watched the lunar eclipse.", "gradeName": "六年级", "meaning": "观看（watch过去式）", "pos": "n."}, {"id": "pep_559", "word": "learned", "phonetic": "/lɜːnd/", "syllables": ["learned"], "chinese": "学习（learn过去式）", "grade": 6, "unit": "规则过去式", "example": "He learned forty new words.", "gradeName": "六年级", "meaning": "学习（learn过去式）", "pos": "v."}, {"id": "pep_560", "word": "helped", "phonetic": "/helpt/", "syllables": ["helped"], "chinese": "帮助（help过去式）", "grade": 6, "unit": "规则过去式", "example": "She helped grandma cross the street.", "gradeName": "六年级", "meaning": "帮助（help过去式）", "pos": "v."}, {"id": "pep_561", "word": "big", "phonetic": "/bɪɡ/", "syllables": ["big"], "chinese": "大的", "grade": 1, "unit": "性质与感受", "example": "The elephant has big ears.", "gradeName": "一年级", "meaning": "大的", "pos": "adj."}, {"id": "pep_562", "word": "small", "phonetic": "/smɔːl/", "syllables": ["small"], "chinese": "小的", "grade": 1, "unit": "性质与感受", "example": "The mouse is very small.", "gradeName": "一年级", "meaning": "小的", "pos": "adj."}, {"id": "pep_563", "word": "long", "phonetic": "/lɒŋ/", "syllables": ["long"], "chinese": "长的", "grade": 1, "unit": "性质与感受", "example": "The snake has a long body.", "gradeName": "一年级", "meaning": "长的", "pos": "adj."}, {"id": "pep_564", "word": "short", "phonetic": "/ʃɔːt/", "syllables": ["short"], "chinese": "短的；矮的", "grade": 1, "unit": "性质与感受", "example": "The baby is cute and short.", "gradeName": "一年级", "meaning": "短的；矮的", "pos": "adj."}, {"id": "pep_565", "word": "tall", "phonetic": "/tɔːl/", "syllables": ["tall"], "chinese": "高的", "grade": 1, "unit": "性质与感受", "example": "Giraffes are very tall.", "gradeName": "一年级", "meaning": "高的", "pos": "adj."}, {"id": "pep_566", "word": "high", "phonetic": "/haɪ/", "syllables": ["high"], "chinese": "高度的；崇高的", "grade": 3, "unit": "性质与感受", "example": "Soar high into the sky.", "gradeName": "三年级", "meaning": "高度的；崇高的", "pos": "adj."}, {"id": "pep_567", "word": "low", "phonetic": "/ləʊ/", "syllables": ["low"], "chinese": "低矮的", "grade": 3, "unit": "性质与感受", "example": "Fly over low fences.", "gradeName": "三年级", "meaning": "低矮的", "pos": "adj."}, {"id": "pep_568", "word": "fat", "phonetic": "/fæt/", "syllables": ["fat"], "chinese": "胖的", "grade": 1, "unit": "性质与感受", "example": "The little panda looks fat.", "gradeName": "一年级", "meaning": "胖的", "pos": "adj."}, {"id": "pep_569", "word": "thin", "phonetic": "/θɪn/", "syllables": ["thin"], "chinese": "瘦的；薄的", "grade": 1, "unit": "性质与感受", "example": "The monkey is thin and agile.", "gradeName": "一年级", "meaning": "瘦的；薄的", "pos": "adj."}, {"id": "pep_570", "word": "heavy", "phonetic": "/ˈhevi/", "syllables": ["heav", "y"], "chinese": "沉重的", "grade": 4, "unit": "性质与感受", "example": "The luggage is too heavy to lift.", "gradeName": "四年级", "meaning": "沉重的", "pos": "n."}, {"id": "pep_571", "word": "strong", "phonetic": "/strɒŋ/", "syllables": ["strong"], "chinese": "强壮的", "grade": 4, "unit": "性质与感受", "example": "A strong body withstands chills.", "gradeName": "四年级", "meaning": "强壮的", "pos": "adj."}, {"id": "pep_572", "word": "weak", "phonetic": "/wiːk/", "syllables": ["weak"], "chinese": "虚弱的", "grade": 4, "unit": "性质与感受", "example": "Rest when you feel weak.", "gradeName": "四年级", "meaning": "虚弱的", "pos": "n."}, {"id": "pep_573", "word": "fast", "phonetic": "/fɑːst/", "syllables": ["fast"], "chinese": "迅速的；快的", "grade": 3, "unit": "性质与感受", "example": "Run fast towards goal line.", "gradeName": "三年级", "meaning": "迅速的；快的", "pos": "n."}, {"id": "pep_574", "word": "quick", "phonetic": "/kwɪk/", "syllables": ["quick"], "chinese": "敏捷的；快速的", "grade": 3, "unit": "性质与感受", "example": "Take a quick morning shower.", "gradeName": "三年级", "meaning": "敏捷的；快速的", "pos": "n."}, {"id": "pep_575", "word": "slow", "phonetic": "/sləʊ/", "syllables": ["slow"], "chinese": "缓慢的", "grade": 3, "unit": "性质与感受", "example": "Turtles walk slow and steady.", "gradeName": "三年级", "meaning": "缓慢的", "pos": "n."}, {"id": "pep_576", "word": "new", "phonetic": "/njuː/", "syllables": ["new"], "chinese": "崭新的", "grade": 1, "unit": "性质与感受", "example": "Wear a brand new sweater.", "gradeName": "一年级", "meaning": "崭新的", "pos": "n."}, {"id": "pep_577", "word": "old", "phonetic": "/əʊld/", "syllables": ["old"], "chinese": "陈旧的；年老的", "grade": 1, "unit": "性质与感受", "example": "An old oak tree in village.", "gradeName": "一年级", "meaning": "陈旧的；年老的", "pos": "n."}, {"id": "pep_578", "word": "young", "phonetic": "/jʌŋ/", "syllables": ["young"], "chinese": "年轻的；幼小的", "grade": 2, "unit": "性质与感受", "example": "Young saplings sprout.", "gradeName": "二年级", "meaning": "年轻的；幼小的", "pos": "adj."}, {"id": "pep_579", "word": "good", "phonetic": "/ɡʊd/", "syllables": ["good"], "chinese": "优良的；好的", "grade": 1, "unit": "性质与感受", "example": "You did a very good job.", "gradeName": "一年级", "meaning": "优良的；好的", "pos": "n."}, {"id": "pep_580", "word": "bad", "phonetic": "/bæd/", "syllables": ["bad"], "chinese": "糟糕的；坏的", "grade": 2, "unit": "性质与感受", "example": "Never form bad habits.", "gradeName": "二年级", "meaning": "糟糕的；坏的", "pos": "n."}, {"id": "pep_581", "word": "happy", "phonetic": "/ˈhæpi/", "syllables": ["hap", "py"], "chinese": "高兴的；开心的", "grade": 1, "unit": "性质与感受", "example": "Happy birthday to you!", "gradeName": "一年级", "meaning": "高兴的；开心的", "pos": "adj."}, {"id": "pep_582", "word": "glad", "phonetic": "/ɡlæd/", "syllables": ["glad"], "chinese": "欣慰的；高兴的", "grade": 3, "unit": "性质与感受", "example": "Glad to see your big improvement.", "gradeName": "三年级", "meaning": "欣慰的；高兴的", "pos": "adj."}, {"id": "pep_583", "word": "sad", "phonetic": "/sæd/", "syllables": ["sad"], "chinese": "伤心的；难过的", "grade": 5, "unit": "性质与感受", "example": "Do not be sad, tomorrow is new.", "gradeName": "五年级", "meaning": "伤心的；难过的", "pos": "adj."}, {"id": "pep_584", "word": "angry", "phonetic": "/ˈæŋɡri/", "syllables": ["an", "gry"], "chinese": "生气的", "grade": 5, "unit": "性质与感受", "example": "Calm down before you get angry.", "gradeName": "五年级", "meaning": "生气的", "pos": "adj."}, {"id": "pep_585", "word": "tired", "phonetic": "/ˈtaɪəd/", "syllables": ["tired"], "chinese": "疲劳的；累的", "grade": 5, "unit": "性质与感受", "example": "Take a rest when you feel tired.", "gradeName": "五年级", "meaning": "疲劳的；累的", "pos": "n."}, {"id": "pep_586", "word": "excited", "phonetic": "/ɪkˈsaɪtɪd/", "syllables": ["ex", "cit", "ed"], "chinese": "兴奋的；激动的", "grade": 5, "unit": "性质与感受", "example": "Students were excited for excursion.", "gradeName": "五年级", "meaning": "兴奋的；激动的", "pos": "adj."}, {"id": "pep_587", "word": "bored", "phonetic": "/bɔːd/", "syllables": ["bored"], "chinese": "无聊的", "grade": 5, "unit": "性质与感受", "example": "Read a novel if you feel bored.", "gradeName": "五年级", "meaning": "无聊的", "pos": "adj."}, {"id": "pep_588", "word": "scared", "phonetic": "/skeəd/", "syllables": ["scared"], "chinese": "害怕的", "grade": 5, "unit": "性质与感受", "example": "The puppy was scared of thunder.", "gradeName": "五年级", "meaning": "害怕的", "pos": "adj."}, {"id": "pep_589", "word": "proud", "phonetic": "/praʊd/", "syllables": ["proud"], "chinese": "自豪的", "grade": 5, "unit": "性质与感受", "example": "Parents are proud of your progress.", "gradeName": "五年级", "meaning": "自豪的", "pos": "adj."}, {"id": "pep_590", "word": "quiet", "phonetic": "/ˈkwaɪət/", "syllables": ["qui", "et"], "chinese": "安静的", "grade": 4, "unit": "性质与感受", "example": "Keep quiet in public reading room.", "gradeName": "四年级", "meaning": "安静的", "pos": "adj."}, {"id": "pep_591", "word": "noisy", "phonetic": "/ˈnɔɪzi/", "syllables": ["nois", "y"], "chinese": "嘈杂的；喧闹的", "grade": 4, "unit": "性质与感受", "example": "The busy marketplace is noisy.", "gradeName": "四年级", "meaning": "嘈杂的；喧闹的", "pos": "adj."}, {"id": "pep_592", "word": "loud", "phonetic": "/laʊd/", "syllables": ["loud"], "chinese": "大声的；响亮的", "grade": 4, "unit": "性质与感受", "example": "A loud whistle blew.", "gradeName": "四年级", "meaning": "大声的；响亮的", "pos": "adj."}, {"id": "pep_593", "word": "dirty", "phonetic": "/ˈdɜːti/", "syllables": ["dir", "ty"], "chinese": "肮脏的", "grade": 3, "unit": "性质与感受", "example": "Wash dirty soccer shoes.", "gradeName": "三年级", "meaning": "肮脏的", "pos": "n."}, {"id": "pep_594", "word": "easy", "phonetic": "/ˈiːzi/", "syllables": ["ea", "sy"], "chinese": "容易的", "grade": 3, "unit": "性质与感受", "example": "Practice makes the quiz easy.", "gradeName": "三年级", "meaning": "容易的", "pos": "adj."}, {"id": "pep_595", "word": "hard", "phonetic": "/hɑːd/", "syllables": ["hard"], "chinese": "困难的；坚硬的", "grade": 3, "unit": "性质与感受", "example": "Work hard to conquer difficulties.", "gradeName": "三年级", "meaning": "困难的；坚硬的", "pos": "n."}, {"id": "pep_596", "word": "difficult", "phonetic": "/ˈdɪfɪkəlt/", "syllables": ["dif", "fi", "cult"], "chinese": "困难的", "grade": 4, "unit": "性质与感受", "example": "Solve the difficult riddle.", "gradeName": "四年级", "meaning": "困难的", "pos": "n."}, {"id": "pep_597", "word": "soft", "phonetic": "/sɒft/", "syllables": ["soft"], "chinese": "柔软的", "grade": 3, "unit": "性质与感受", "example": "The bunny has soft fur.", "gradeName": "三年级", "meaning": "柔软的", "pos": "n."}, {"id": "pep_598", "word": "beautiful", "phonetic": "/ˈbjuːtɪfl/", "syllables": ["beau", "ti", "ful"], "chinese": "美丽的；优美的", "grade": 3, "unit": "性质与感受", "example": "What a beautiful sunrise!", "gradeName": "三年级", "meaning": "美丽的；优美的", "pos": "adj."}, {"id": "pep_599", "word": "pretty", "phonetic": "/ˈprɪti/", "syllables": ["pret", "ty"], "chinese": "俊俏的；漂亮的", "grade": 4, "unit": "性质与感受", "example": "What a pretty spring dress!", "gradeName": "四年级", "meaning": "俊俏的；漂亮的", "pos": "adj."}, {"id": "pep_600", "word": "cute", "phonetic": "/kjuːt/", "syllables": ["cute"], "chinese": "可爱的；乖巧的", "grade": 2, "unit": "性质与感受", "example": "A cute furry kitten.", "gradeName": "二年级", "meaning": "可爱的；乖巧的", "pos": "v."}, {"id": "pep_601", "word": "lovely", "phonetic": "/ˈlʌvli/", "syllables": ["love", "ly"], "chinese": "可爱的；愉快的", "grade": 2, "unit": "性质与感受", "example": "Spend a lovely picnic afternoon.", "gradeName": "二年级", "meaning": "可爱的；愉快的", "pos": "v."}, {"id": "pep_602", "word": "clever", "phonetic": "/ˈklevə(r)/", "syllables": ["clev", "er"], "chinese": "聪颖的；机敏的", "grade": 4, "unit": "性质与感受", "example": "The clever fox escaped hunter.", "gradeName": "四年级", "meaning": "聪颖的；机敏的", "pos": "adj."}, {"id": "pep_603", "word": "smart", "phonetic": "/smɑːt/", "syllables": ["smart"], "chinese": "聪明的；潇洒的", "grade": 3, "unit": "性质与感受", "example": "Smart kids study persistently.", "gradeName": "三年级", "meaning": "聪明的；潇洒的", "pos": "adj."}, {"id": "pep_604", "word": "brave", "phonetic": "/breɪv/", "syllables": ["brave"], "chinese": "勇敢的", "grade": 4, "unit": "性质与感受", "example": "Brave heroes protect city.", "gradeName": "四年级", "meaning": "勇敢的", "pos": "adj."}, {"id": "pep_605", "word": "polite", "phonetic": "/pəˈlaɪt/", "syllables": ["po", "lite"], "chinese": "有礼貌的", "grade": 4, "unit": "性质与感受", "example": "Always be polite to elders.", "gradeName": "四年级", "meaning": "有礼貌的", "pos": "v."}, {"id": "pep_606", "word": "helpful", "phonetic": "/ˈhelpfl/", "syllables": ["help", "ful"], "chinese": "乐于助人的", "grade": 4, "unit": "性质与感受", "example": "Students are kind and helpful.", "gradeName": "四年级", "meaning": "乐于助人的", "pos": "n."}, {"id": "pep_607", "word": "kind", "phonetic": "/kaɪnd/", "syllables": ["kind"], "chinese": "善良的；仁慈的", "grade": 3, "unit": "性质与感受", "example": "Be kind to animals.", "gradeName": "三年级", "meaning": "善良的；仁慈的", "pos": "adj."}, {"id": "pep_608", "word": "careful", "phonetic": "/ˈkeəfl/", "syllables": ["care", "ful"], "chinese": "细心的；仔细的", "grade": 3, "unit": "性质与感受", "example": "Be careful when crossing street.", "gradeName": "三年级", "meaning": "细心的；仔细的", "pos": "adj."}, {"id": "pep_609", "word": "safe", "phonetic": "/seɪf/", "syllables": ["safe"], "chinese": "安全的", "grade": 3, "unit": "性质与感受", "example": "Keep safe in playground.", "gradeName": "三年级", "meaning": "安全的", "pos": "adj."}, {"id": "pep_610", "word": "dangerous", "phonetic": "/ˈdeɪndʒərəs/", "syllables": ["dan", "ger", "ous"], "chinese": "危险的", "grade": 4, "unit": "性质与感受", "example": "Do not touch dangerous chemicals.", "gradeName": "四年级", "meaning": "危险的", "pos": "adj."}, {"id": "pep_611", "word": "same", "phonetic": "/seɪm/", "syllables": ["same"], "chinese": "相同的", "grade": 3, "unit": "性质与感受", "example": "We share the same dream.", "gradeName": "三年级", "meaning": "相同的", "pos": "n."}, {"id": "pep_612", "word": "different", "phonetic": "/ˈdɪfrənt/", "syllables": ["dif", "fer", "ent"], "chinese": "不同的", "grade": 4, "unit": "性质与感受", "example": "Everyone has different talents.", "gradeName": "四年级", "meaning": "不同的", "pos": "adj."}, {"id": "pep_613", "word": "busy", "phonetic": "/ˈbɪzi/", "syllables": ["bus", "y"], "chinese": "忙碌的", "grade": 3, "unit": "性质与感受", "example": "The bees are busy collecting honey.", "gradeName": "三年级", "meaning": "忙碌的", "pos": "adj."}, {"id": "pep_614", "word": "free", "phonetic": "/friː/", "syllables": ["free"], "chinese": "空闲的；自由的", "grade": 3, "unit": "性质与感受", "example": "Are you free this weekend?", "gradeName": "三年级", "meaning": "空闲的；自由的", "pos": "adj."}, {"id": "pep_615", "word": "rich", "phonetic": "/rɪtʃ/", "syllables": ["rich"], "chinese": "丰富的；富裕的", "grade": 4, "unit": "性质与感受", "example": "Fruit is rich in vitamins.", "gradeName": "四年级", "meaning": "丰富的；富裕的", "pos": "n."}, {"id": "pep_616", "word": "poor", "phonetic": "/pɔː(r)/", "syllables": ["poor"], "chinese": "贫穷的；可怜的", "grade": 4, "unit": "性质与感受", "example": "Help the poor puppy.", "gradeName": "四年级", "meaning": "贫穷的；可怜的", "pos": "adj."}, {"id": "pep_617", "word": "cheap", "phonetic": "/tʃiːp/", "syllables": ["cheap"], "chinese": "廉价的", "grade": 4, "unit": "性质与感受", "example": "This notebook is very cheap.", "gradeName": "四年级", "meaning": "廉价的", "pos": "n."}, {"id": "pep_618", "word": "expensive", "phonetic": "/ɪkˈspensɪv/", "syllables": ["ex", "pen", "sive"], "chinese": "昂贵的", "grade": 4, "unit": "性质与感受", "example": "Diamonds are rare and expensive.", "gradeName": "四年级", "meaning": "昂贵的", "pos": "adj."}, {"id": "pep_619", "word": "where", "phonetic": "/weə(r)/", "syllables": ["where"], "chinese": "哪里", "grade": 2, "unit": "功能词汇", "example": "Where is my English book?", "gradeName": "二年级", "meaning": "哪里", "pos": "n."}, {"id": "pep_620", "word": "when", "phonetic": "/wen/", "syllables": ["when"], "chinese": "何时；当……时", "grade": 3, "unit": "功能词汇", "example": "When does the train arrive?", "gradeName": "三年级", "meaning": "何时；当……时", "pos": "n."}, {"id": "pep_621", "word": "why", "phonetic": "/waɪ/", "syllables": ["why"], "chinese": "为什么", "grade": 3, "unit": "功能词汇", "example": "Why are you late today?", "gradeName": "三年级", "meaning": "为什么", "pos": "n."}, {"id": "pep_622", "word": "which", "phonetic": "/wɪtʃ/", "syllables": ["which"], "chinese": "哪一个", "grade": 3, "unit": "功能词汇", "example": "Which colour do you prefer?", "gradeName": "三年级", "meaning": "哪一个", "pos": "n."}, {"id": "pep_623", "word": "whose", "phonetic": "/huːz/", "syllables": ["whose"], "chinese": "谁的", "grade": 4, "unit": "功能词汇", "example": "Whose umbrella is this?", "gradeName": "四年级", "meaning": "谁的", "pos": "n."}, {"id": "pep_624", "word": "in", "phonetic": "/ɪn/", "syllables": ["in"], "chinese": "在……里", "grade": 1, "unit": "功能词汇", "example": "Pencils are in the box.", "gradeName": "一年级", "meaning": "在……里", "pos": "n."}, {"id": "pep_625", "word": "on", "phonetic": "/ɒn/", "syllables": ["on"], "chinese": "在……上", "grade": 1, "unit": "功能词汇", "example": "Book is on the desk.", "gradeName": "一年级", "meaning": "在……上", "pos": "n."}, {"id": "pep_626", "word": "under", "phonetic": "/ˈʌndə(r)/", "syllables": ["un", "der"], "chinese": "在……下", "grade": 1, "unit": "功能词汇", "example": "The cat hides under the bed.", "gradeName": "一年级", "meaning": "在……下", "pos": "n."}, {"id": "pep_627", "word": "near", "phonetic": "/nɪə(r)/", "syllables": ["near"], "chinese": "在……附近", "grade": 2, "unit": "功能词汇", "example": "My house is near the park.", "gradeName": "二年级", "meaning": "在……附近", "pos": "n."}, {"id": "pep_628", "word": "behind", "phonetic": "/bɪˈhaɪnd/", "syllables": ["be", "hind"], "chinese": "在……后", "grade": 2, "unit": "功能词汇", "example": "Stand behind the line.", "gradeName": "二年级", "meaning": "在……后", "pos": "n."}, {"id": "pep_629", "word": "beside", "phonetic": "/bɪˈsaɪd/", "syllables": ["be", "side"], "chinese": "在……旁边", "grade": 3, "unit": "功能词汇", "example": "Sit beside your friend.", "gradeName": "三年级", "meaning": "在……旁边", "pos": "n."}, {"id": "pep_630", "word": "between", "phonetic": "/bɪˈtwiːn/", "syllables": ["be", "tween"], "chinese": "在……之间", "grade": 3, "unit": "功能词汇", "example": "Sit between two trees.", "gradeName": "三年级", "meaning": "在……之间", "pos": "n."}, {"id": "pep_631", "word": "in front of", "phonetic": "/ɪn frʌnt əv/", "syllables": ["in", "front", "of"], "chinese": "在……前面", "grade": 3, "unit": "功能词汇", "example": "A tree in front of our house.", "gradeName": "三年级", "meaning": "在……前面", "pos": "n."}, {"id": "pep_632", "word": "with", "phonetic": "/wɪð/", "syllables": ["with"], "chinese": "和……一起；用", "grade": 2, "unit": "功能词汇", "example": "Play with your classmates.", "gradeName": "二年级", "meaning": "和……一起；用", "pos": "n."}, {"id": "pep_633", "word": "without", "phonetic": "/wɪˈðaʊt/", "syllables": ["with", "out"], "chinese": "没有；不带", "grade": 4, "unit": "功能词汇", "example": "Fish cannot live without water.", "gradeName": "四年级", "meaning": "没有；不带", "pos": "n."}, {"id": "pep_634", "word": "for", "phonetic": "/fɔː(r)/", "syllables": ["for"], "chinese": "为了；给", "grade": 2, "unit": "功能词汇", "example": "A gift for your birthday.", "gradeName": "二年级", "meaning": "为了；给", "pos": "n."}, {"id": "pep_635", "word": "from", "phonetic": "/frɒm/", "syllables": ["from"], "chinese": "来自；从", "grade": 2, "unit": "功能词汇", "example": "Where are you from?", "gradeName": "二年级", "meaning": "来自；从", "pos": "v."}, {"id": "pep_636", "word": "about", "phonetic": "/əˈbaʊt/", "syllables": ["a", "bout"], "chinese": "关于；大约", "grade": 3, "unit": "功能词汇", "example": "A story about astronauts.", "gradeName": "三年级", "meaning": "关于；大约", "pos": "v."}, {"id": "pep_637", "word": "up", "phonetic": "/ʌp/", "syllables": ["up"], "chinese": "向上", "grade": 2, "unit": "功能词汇", "example": "Hands up high.", "gradeName": "二年级", "meaning": "向上", "pos": "n."}, {"id": "pep_638", "word": "down", "phonetic": "/daʊn/", "syllables": ["down"], "chinese": "向下", "grade": 2, "unit": "功能词汇", "example": "Sit down quietly.", "gradeName": "二年级", "meaning": "向下", "pos": "n."}, {"id": "pep_639", "word": "into", "phonetic": "/ˈɪntu/", "syllables": ["in", "to"], "chinese": "进入……里", "grade": 3, "unit": "功能词汇", "example": "Walk into the classroom.", "gradeName": "三年级", "meaning": "进入……里", "pos": "n."}, {"id": "pep_640", "word": "out of", "phonetic": "/aʊt əv/", "syllables": ["out", "of"], "chinese": "走出；从……出", "grade": 3, "unit": "功能词汇", "example": "Step out of the building.", "gradeName": "三年级", "meaning": "走出；从……出", "pos": "n."}, {"id": "pep_641", "word": "and", "phonetic": "/ænd/", "syllables": ["and"], "chinese": "和；并且", "grade": 1, "unit": "功能词汇", "example": "Apples and bananas.", "gradeName": "一年级", "meaning": "和；并且", "pos": "n."}, {"id": "pep_642", "word": "but", "phonetic": "/bʌt/", "syllables": ["but"], "chinese": "但是", "grade": 2, "unit": "功能词汇", "example": "I like sports, but not swimming.", "gradeName": "二年级", "meaning": "但是", "pos": "n."}, {"id": "pep_643", "word": "or", "phonetic": "/ɔː(r)/", "syllables": ["or"], "chinese": "或者；还是", "grade": 2, "unit": "功能词汇", "example": "Tea or coffee?", "gradeName": "二年级", "meaning": "或者；还是", "pos": "n."}, {"id": "pep_644", "word": "so", "phonetic": "/səʊ/", "syllables": ["so"], "chinese": "因此；如此", "grade": 3, "unit": "功能词汇", "example": "It was rainy, so we stayed home.", "gradeName": "三年级", "meaning": "因此；如此", "pos": "n."}, {"id": "pep_645", "word": "because", "phonetic": "/bɪˈkɒz/", "syllables": ["be", "cause"], "chinese": "因为", "grade": 4, "unit": "功能词汇", "example": "I like spring because flowers bloom.", "gradeName": "四年级", "meaning": "因为", "pos": "n."}, {"id": "pep_646", "word": "if", "phonetic": "/ɪf/", "syllables": ["if"], "chinese": "如果；假如", "grade": 4, "unit": "功能词汇", "example": "If you work hard, you succeed.", "gradeName": "四年级", "meaning": "如果；假如", "pos": "n."}, {"id": "pep_647", "word": "then", "phonetic": "/ðen/", "syllables": ["then"], "chinese": "然后；当时", "grade": 3, "unit": "功能词汇", "example": "Wash hands, then eat lunch.", "gradeName": "三年级", "meaning": "然后；当时", "pos": "n."}, {"id": "pep_648", "word": "also", "phonetic": "/ˈɔːlsəʊ/", "syllables": ["al", "so"], "chinese": "也；并且", "grade": 3, "unit": "功能词汇", "example": "She also enjoys music.", "gradeName": "三年级", "meaning": "也；并且", "pos": "n."}, {"id": "pep_649", "word": "too", "phonetic": "/tuː/", "syllables": ["too"], "chinese": "也；太", "grade": 1, "unit": "功能词汇", "example": "Nice to meet you, too.", "gradeName": "一年级", "meaning": "也；太", "pos": "n."}, {"id": "pep_650", "word": "beach", "phonetic": "/biːtʃ/", "syllables": ["beach"], "chinese": "沙滩；海滩", "grade": 4, "unit": "自然与时节", "example": "Build sandcastles on the beach.", "gradeName": "四年级", "meaning": "沙滩；海滩", "pos": "n."}, {"id": "pep_651", "word": "sand", "phonetic": "/sænd/", "syllables": ["sand"], "chinese": "沙子", "grade": 4, "unit": "自然与时节", "example": "Golden sand warm in summer sun.", "gradeName": "四年级", "meaning": "沙子", "pos": "n."}, {"id": "pep_652", "word": "island", "phonetic": "/ˈaɪlənd/", "syllables": ["is", "land"], "chinese": "岛屿", "grade": 5, "unit": "自然与时节", "example": "Tropical green island in ocean.", "gradeName": "五年级", "meaning": "岛屿", "pos": "n."}, {"id": "pep_653", "word": "space", "phonetic": "/speɪs/", "syllables": ["space"], "chinese": "太空；空间", "grade": 5, "unit": "自然与时节", "example": "Astronauts travel into outer space.", "gradeName": "五年级", "meaning": "太空；空间", "pos": "n."}, {"id": "pep_654", "word": "planet", "phonetic": "/ˈplænɪt/", "syllables": ["plan", "et"], "chinese": "行星", "grade": 5, "unit": "自然与时节", "example": "Earth is our home planet.", "gradeName": "五年级", "meaning": "行星", "pos": "n."}, {"id": "pep_655", "word": "sunlight", "phonetic": "/ˈsʌnlaɪt/", "syllables": ["sun", "light"], "chinese": "阳光", "grade": 3, "unit": "自然与时节", "example": "Morning sunlight warms the room.", "gradeName": "三年级", "meaning": "阳光", "pos": "n."}, {"id": "pep_656", "word": "shadow", "phonetic": "/ˈʃædəʊ/", "syllables": ["shad", "ow"], "chinese": "影子", "grade": 3, "unit": "自然与时节", "example": "My shadow follows me around.", "gradeName": "三年级", "meaning": "影子", "pos": "n."}, {"id": "pep_657", "word": "fog", "phonetic": "/fɒɡ/", "syllables": ["fog"], "chinese": "雾气", "grade": 4, "unit": "自然与时节", "example": "Dense morning fog over river.", "gradeName": "四年级", "meaning": "雾气", "pos": "n."}, {"id": "pep_658", "word": "foggy", "phonetic": "/ˈfɒɡi/", "syllables": ["fog", "gy"], "chinese": "有雾的；多雾的", "grade": 4, "unit": "自然与时节", "example": "Drive carefully on a foggy morning.", "gradeName": "四年级", "meaning": "有雾的；多雾的", "pos": "v."}, {"id": "pep_659", "word": "thunder", "phonetic": "/ˈθʌndə(r)/", "syllables": ["thun", "der"], "chinese": "雷鸣；雷声", "grade": 4, "unit": "自然与时节", "example": "Hear distant rumbling thunder.", "gradeName": "四年级", "meaning": "雷鸣；雷声", "pos": "n."}, {"id": "pep_660", "word": "lightning", "phonetic": "/ˈlaɪtnɪŋ/", "syllables": ["light", "ning"], "chinese": "闪电", "grade": 4, "unit": "自然与时节", "example": "Flashes of bright lightning.", "gradeName": "四年级", "meaning": "闪电", "pos": "n."}, {"id": "pep_661", "word": "storm", "phonetic": "/stɔːm/", "syllables": ["storm"], "chinese": "暴风雨", "grade": 4, "unit": "自然与时节", "example": "A sudden heavy summer storm.", "gradeName": "四年级", "meaning": "暴风雨", "pos": "n."}, {"id": "pep_662", "word": "stone", "phonetic": "/stəʊn/", "syllables": ["stone"], "chinese": "石头", "grade": 3, "unit": "自然与时节", "example": "Skip smooth stones across lake.", "gradeName": "三年级", "meaning": "石头", "pos": "n."}, {"id": "pep_663", "word": "rock", "phonetic": "/rɒk/", "syllables": ["rock"], "chinese": "岩石", "grade": 3, "unit": "自然与时节", "example": "Climb the big gray rock.", "gradeName": "三年级", "meaning": "岩石", "pos": "n."}, {"id": "pep_664", "word": "desert", "phonetic": "/ˈdezət/", "syllables": ["des", "ert"], "chinese": "沙漠", "grade": 5, "unit": "自然与时节", "example": "Camels walk across desert sands.", "gradeName": "五年级", "meaning": "沙漠", "pos": "n."}, {"id": "pep_665", "word": "cave", "phonetic": "/keɪv/", "syllables": ["cave"], "chinese": "洞穴", "grade": 5, "unit": "自然与时节", "example": "Bats rest in the cool cave.", "gradeName": "五年级", "meaning": "洞穴", "pos": "n."}, {"id": "pep_666", "word": "shore", "phonetic": "/ʃɔː(r)/", "syllables": ["shore"], "chinese": "岸边；滨", "grade": 5, "unit": "自然与时节", "example": "Waves lap against the shore.", "gradeName": "五年级", "meaning": "岸边；滨", "pos": "n."}, {"id": "pep_667", "word": "breeze", "phonetic": "/briːz/", "syllables": ["breeze"], "chinese": "微风", "grade": 4, "unit": "自然与时节", "example": "A refreshing spring breeze.", "gradeName": "四年级", "meaning": "微风", "pos": "n."}, {"id": "pep_668", "word": "frost", "phonetic": "/frɒst/", "syllables": ["frost"], "chinese": "霜；霜冻", "grade": 5, "unit": "自然与时节", "example": "Winter frost on glass windows.", "gradeName": "五年级", "meaning": "霜；霜冻", "pos": "n."}, {"id": "pep_669", "word": "nature", "phonetic": "/ˈneɪtʃə(r)/", "syllables": ["na", "ture"], "chinese": "大自然；自然界", "grade": 4, "unit": "自然与时节", "example": "Protect nature and wildlife.", "gradeName": "四年级", "meaning": "大自然；自然界", "pos": "adj."}, {"id": "pep_670", "word": "bowl", "phonetic": "/bəʊl/", "syllables": ["bowl"], "chinese": "碗", "grade": 2, "unit": "生活用品", "example": "A bowl of warm noodles.", "gradeName": "二年级", "meaning": "碗", "pos": "n."}, {"id": "pep_671", "word": "plate", "phonetic": "/pleɪt/", "syllables": ["plate"], "chinese": "盘子；碟子", "grade": 2, "unit": "生活用品", "example": "Put sweet fruits on the plate.", "gradeName": "二年级", "meaning": "盘子；碟子", "pos": "n."}, {"id": "pep_672", "word": "fork", "phonetic": "/fɔːk/", "syllables": ["fork"], "chinese": "叉子", "grade": 2, "unit": "生活用品", "example": "Eat spaghetti with a fork.", "gradeName": "二年级", "meaning": "叉子", "pos": "n."}, {"id": "pep_673", "word": "spoon", "phonetic": "/spuːn/", "syllables": ["spoon"], "chinese": "勺子；匙", "grade": 2, "unit": "生活用品", "example": "Stir hot soup with a spoon.", "gradeName": "二年级", "meaning": "勺子；匙", "pos": "n."}, {"id": "pep_674", "word": "knife", "phonetic": "/naɪf/", "syllables": ["knife"], "chinese": "餐刀；小刀", "grade": 2, "unit": "生活用品", "example": "Butter your bread with a knife.", "gradeName": "二年级", "meaning": "餐刀；小刀", "pos": "n."}, {"id": "pep_675", "word": "chopsticks", "phonetic": "/ˈtʃɒpstɪks/", "syllables": ["chop", "sticks"], "chinese": "筷子", "grade": 2, "unit": "生活用品", "example": "Use bamboo chopsticks skillfully.", "gradeName": "二年级", "meaning": "筷子", "pos": "n."}, {"id": "pep_676", "word": "cup", "phonetic": "/kʌp/", "syllables": ["cup"], "chinese": "茶杯；杯子", "grade": 1, "unit": "生活用品", "example": "A cup of warm green tea.", "gradeName": "一年级", "meaning": "茶杯；杯子", "pos": "n."}, {"id": "pep_677", "word": "glass", "phonetic": "/ɡlɑːs/", "syllables": ["glass"], "chinese": "玻璃杯；玻璃", "grade": 2, "unit": "生活用品", "example": "A tall glass of orange juice.", "gradeName": "二年级", "meaning": "玻璃杯；玻璃", "pos": "n."}, {"id": "pep_678", "word": "bottle", "phonetic": "/ˈbɒtl/", "syllables": ["bot", "tle"], "chinese": "水瓶；瓶子", "grade": 2, "unit": "生活用品", "example": "A reusable water bottle.", "gradeName": "二年级", "meaning": "水瓶；瓶子", "pos": "n."}, {"id": "pep_679", "word": "pot", "phonetic": "/pɒt/", "syllables": ["pot"], "chinese": "锅；壶", "grade": 3, "unit": "生活用品", "example": "Cook stew in an iron pot.", "gradeName": "三年级", "meaning": "锅；壶", "pos": "n."}, {"id": "pep_680", "word": "ticket", "phonetic": "/ˈtɪkɪt/", "syllables": ["tick", "et"], "chinese": "车票；门票", "grade": 3, "unit": "生活用品", "example": "Show your museum entrance ticket.", "gradeName": "三年级", "meaning": "车票；门票", "pos": "n."}, {"id": "pep_681", "word": "passport", "phonetic": "/ˈpɑːspɔːt/", "syllables": ["pass", "port"], "chinese": "护照", "grade": 5, "unit": "生活用品", "example": "Keep your passport secure.", "gradeName": "五年级", "meaning": "护照", "pos": "n."}, {"id": "pep_682", "word": "camera", "phonetic": "/ˈkæmrə/", "syllables": ["cam", "er", "a"], "chinese": "照相机", "grade": 3, "unit": "生活用品", "example": "Take photos with digital camera.", "gradeName": "三年级", "meaning": "照相机", "pos": "n."}, {"id": "pep_683", "word": "wallet", "phonetic": "/ˈwɒlɪt/", "syllables": ["wal", "let"], "chinese": "钱包", "grade": 4, "unit": "生活用品", "example": "Keep coins in your wallet.", "gradeName": "四年级", "meaning": "钱包", "pos": "n."}, {"id": "pep_684", "word": "letter", "phonetic": "/ˈletə(r)/", "syllables": ["let", "ter"], "chinese": "信件；字母", "grade": 2, "unit": "生活用品", "example": "Write a letter to grandpa.", "gradeName": "二年级", "meaning": "信件；字母", "pos": "n."}, {"id": "pep_685", "word": "postcard", "phonetic": "/ˈpəʊstkɑːd/", "syllables": ["post", "card"], "chinese": "明信片", "grade": 3, "unit": "生活用品", "example": "Send a scenic holiday postcard.", "gradeName": "三年级", "meaning": "明信片", "pos": "n."}, {"id": "pep_686", "word": "envelope", "phonetic": "/ˈenvələʊp/", "syllables": ["en", "ve", "lope"], "chinese": "信封", "grade": 4, "unit": "生活用品", "example": "Put the letter into an envelope.", "gradeName": "四年级", "meaning": "信封", "pos": "n."}, {"id": "pep_687", "word": "email", "phonetic": "/ˈiːmeɪl/", "syllables": ["e", "mail"], "chinese": "电子邮件", "grade": 4, "unit": "生活用品", "example": "Send a quick email to teacher.", "gradeName": "四年级", "meaning": "电子邮件", "pos": "n."}, {"id": "pep_688", "word": "message", "phonetic": "/ˈmesɪdʒ/", "syllables": ["mes", "sage"], "chinese": "消息；口信", "grade": 4, "unit": "生活用品", "example": "Leave a polite voice message.", "gradeName": "四年级", "meaning": "消息；口信", "pos": "n."}, {"id": "pep_689", "word": "radio", "phonetic": "/ˈreɪdiəʊ/", "syllables": ["ra", "di", "o"], "chinese": "收音机", "grade": 3, "unit": "生活用品", "example": "Listen to English news on radio.", "gradeName": "三年级", "meaning": "收音机", "pos": "n."}, {"id": "pep_690", "word": "invite", "phonetic": "/ɪnˈvaɪt/", "syllables": ["in", "vite"], "chinese": "邀请", "grade": 4, "unit": "动作与日常", "example": "Invite peers to birthday party.", "gradeName": "四年级", "meaning": "邀请", "pos": "n."}, {"id": "pep_691", "word": "borrow", "phonetic": "/ˈbɒrəʊ/", "syllables": ["bor", "row"], "chinese": "借入；借用", "grade": 3, "unit": "动作与日常", "example": "Borrow three books from library.", "gradeName": "三年级", "meaning": "借入；借用", "pos": "n."}, {"id": "pep_692", "word": "lend", "phonetic": "/lend/", "syllables": ["lend"], "chinese": "借给；借出", "grade": 4, "unit": "动作与日常", "example": "Lend a pencil to your friend.", "gradeName": "四年级", "meaning": "借给；借出", "pos": "n."}, {"id": "pep_693", "word": "pack", "phonetic": "/pæk/", "syllables": ["pack"], "chinese": "打包；收拾行李", "grade": 4, "unit": "动作与日常", "example": "Pack your luggage for travel.", "gradeName": "四年级", "meaning": "打包；收拾行李", "pos": "v."}, {"id": "pep_694", "word": "arrive", "phonetic": "/əˈraɪv/", "syllables": ["ar", "rive"], "chinese": "到达；抵达", "grade": 4, "unit": "动作与日常", "example": "The train will arrive on time.", "gradeName": "四年级", "meaning": "到达；抵达", "pos": "n."}, {"id": "pep_695", "word": "leave", "phonetic": "/liːv/", "syllables": ["leave"], "chinese": "离开；留下", "grade": 4, "unit": "动作与日常", "example": "Leave for school at seven thirty.", "gradeName": "四年级", "meaning": "离开；留下", "pos": "n."}, {"id": "pep_696", "word": "choose", "phonetic": "/tʃuːz/", "syllables": ["choose"], "chinese": "选择；挑选", "grade": 4, "unit": "动作与日常", "example": "Choose your favorite English book.", "gradeName": "四年级", "meaning": "选择；挑选", "pos": "n."}, {"id": "pep_697", "word": "agree", "phonetic": "/əˈɡriː/", "syllables": ["a", "gree"], "chinese": "赞同；同意", "grade": 5, "unit": "动作与日常", "example": "I agree with your brilliant plan.", "gradeName": "五年级", "meaning": "赞同；同意", "pos": "n."}, {"id": "pep_698", "word": "refuse", "phonetic": "/rɪˈfjuːz/", "syllables": ["re", "fuse"], "chinese": "拒绝", "grade": 5, "unit": "动作与日常", "example": "Politely refuse unhealthy snacks.", "gradeName": "五年级", "meaning": "拒绝", "pos": "n."}, {"id": "pep_699", "word": "explain", "phonetic": "/ɪkˈspleɪn/", "syllables": ["ex", "plain"], "chinese": "解释；说明", "grade": 5, "unit": "动作与日常", "example": "Explain the math solution clearly.", "gradeName": "五年级", "meaning": "解释；说明", "pos": "n."}, {"id": "pep_700", "word": "describe", "phonetic": "/dɪˈskraɪb/", "syllables": ["de", "scribe"], "chinese": "描述；描绘", "grade": 5, "unit": "动作与日常", "example": "Describe your dream bedroom.", "gradeName": "五年级", "meaning": "描述；描绘", "pos": "n."}, {"id": "pep_701", "word": "practice", "phonetic": "/ˈpræktɪs/", "syllables": ["prac", "tice"], "chinese": "练习；操练", "grade": 3, "unit": "动作与日常", "example": "Practice spoken English daily.", "gradeName": "三年级", "meaning": "练习；操练", "pos": "n."}, {"id": "pep_702", "word": "review", "phonetic": "/rɪˈvjuː/", "syllables": ["re", "view"], "chinese": "复习；温习", "grade": 3, "unit": "动作与日常", "example": "Review vocabulary before bed.", "gradeName": "三年级", "meaning": "复习；温习", "pos": "n."}, {"id": "pep_703", "word": "prepare", "phonetic": "/prɪˈpeə(r)/", "syllables": ["pre", "pare"], "chinese": "准备；预备", "grade": 4, "unit": "动作与日常", "example": "Prepare for the coming term.", "gradeName": "四年级", "meaning": "准备；预备", "pos": "n."}, {"id": "pep_704", "word": "protect", "phonetic": "/prəˈtekt/", "syllables": ["pro", "tect"], "chinese": "保护；保卫", "grade": 5, "unit": "动作与日常", "example": "Protect endangered animals.", "gradeName": "五年级", "meaning": "保护；保卫", "pos": "n."}, {"id": "pep_705", "word": "save", "phonetic": "/seɪv/", "syllables": ["save"], "chinese": "拯救；节约", "grade": 3, "unit": "动作与日常", "example": "Save water and electricity.", "gradeName": "三年级", "meaning": "拯救；节约", "pos": "n."}, {"id": "pep_706", "word": "waste", "phonetic": "/weɪst/", "syllables": ["waste"], "chinese": "浪费", "grade": 4, "unit": "动作与日常", "example": "Never waste delicious food.", "gradeName": "四年级", "meaning": "浪费", "pos": "n."}, {"id": "pep_707", "word": "share", "phonetic": "/ʃeə(r)/", "syllables": ["share"], "chinese": "分享；分担", "grade": 2, "unit": "动作与日常", "example": "Share sweet apples with friends.", "gradeName": "二年级", "meaning": "分享；分担", "pos": "n."}, {"id": "pep_708", "word": "care", "phonetic": "/keə(r)/", "syllables": ["care"], "chinese": "关心；在乎", "grade": 3, "unit": "动作与日常", "example": "Care for younger schoolmates.", "gradeName": "三年级", "meaning": "关心；在乎", "pos": "v."}, {"id": "pep_709", "word": "celebrate", "phonetic": "/ˈselɪbreɪt/", "syllables": ["cel", "e", "brate"], "chinese": "庆祝；祝贺", "grade": 4, "unit": "动作与日常", "example": "Celebrate the New Year joyfully.", "gradeName": "四年级", "meaning": "庆祝；祝贺", "pos": "n."}, {"id": "pep_710", "word": "compete", "phonetic": "/kəmˈpiːt/", "syllables": ["com", "pete"], "chinese": "竞争；竞赛", "grade": 5, "unit": "动作与日常", "example": "Compete fairly in track sports.", "gradeName": "五年级", "meaning": "竞争；竞赛", "pos": "n."}, {"id": "pep_711", "word": "score", "phonetic": "/skɔː(r)/", "syllables": ["score"], "chinese": "得分；进球", "grade": 4, "unit": "动作与日常", "example": "Score the winning goal in soccer.", "gradeName": "四年级", "meaning": "得分；进球", "pos": "n."}, {"id": "pep_712", "word": "miss", "phonetic": "/mɪs/", "syllables": ["miss"], "chinese": "思念；错过", "grade": 3, "unit": "动作与日常", "example": "I miss my grandparents dearly.", "gradeName": "三年级", "meaning": "思念；错过", "pos": "n."}, {"id": "pep_713", "word": "cross", "phonetic": "/krɒs/", "syllables": ["cross"], "chinese": "横过；穿过", "grade": 3, "unit": "动作与日常", "example": "Cross zebra crossing with care.", "gradeName": "三年级", "meaning": "横过；穿过", "pos": "n."}, {"id": "pep_714", "word": "turn", "phonetic": "/tɜːn/", "syllables": ["turn"], "chinese": "转向；转弯", "grade": 2, "unit": "动作与日常", "example": "Turn right at the bookstore.", "gradeName": "二年级", "meaning": "转向；转弯", "pos": "n."}, {"id": "pep_715", "word": "curious", "phonetic": "/ˈkjʊəriəs/", "syllables": ["cu", "ri", "ous"], "chinese": "好奇的", "grade": 4, "unit": "性格与品质", "example": "Children are curious about nature.", "gradeName": "四年级", "meaning": "好奇的", "pos": "adj."}, {"id": "pep_716", "word": "patient", "phonetic": "/ˈpeɪʃnt/", "syllables": ["pa", "tient"], "chinese": "有耐心的；病人", "grade": 4, "unit": "性格与品质", "example": "Teachers are gentle and patient.", "gradeName": "四年级", "meaning": "有耐心的；病人", "pos": "v."}, {"id": "pep_717", "word": "honest", "phonetic": "/ˈɒnɪst/", "syllables": ["hon", "est"], "chinese": "诚实的", "grade": 4, "unit": "性格与品质", "example": "An honest boy speaks the truth.", "gradeName": "四年级", "meaning": "诚实的", "pos": "n."}, {"id": "pep_718", "word": "cheerful", "phonetic": "/ˈtʃɪəfl/", "syllables": ["cheer", "ful"], "chinese": "开朗的；愉快的", "grade": 4, "unit": "性格与品质", "example": "A cheerful and friendly smile.", "gradeName": "四年级", "meaning": "开朗的；愉快的", "pos": "v."}, {"id": "pep_719", "word": "humorous", "phonetic": "/ˈhjuːmərəs/", "syllables": ["hu", "mor", "ous"], "chinese": "幽默的", "grade": 5, "unit": "性格与品质", "example": "The story was very humorous.", "gradeName": "五年级", "meaning": "幽默的", "pos": "n."}, {"id": "pep_720", "word": "gentle", "phonetic": "/ˈdʒentl/", "syllables": ["gen", "tle"], "chinese": "温和的；温柔的", "grade": 4, "unit": "性格与品质", "example": "A gentle autumn breeze.", "gradeName": "四年级", "meaning": "温和的；温柔的", "pos": "n."}, {"id": "pep_721", "word": "peaceful", "phonetic": "/ˈpiːsfl/", "syllables": ["peace", "ful"], "chinese": "和平的；安宁的", "grade": 5, "unit": "性格与品质", "example": "A peaceful countryside morning.", "gradeName": "五年级", "meaning": "和平的；安宁的", "pos": "n."}, {"id": "pep_722", "word": "generous", "phonetic": "/ˈdʒenərəs/", "syllables": ["gen", "er", "ous"], "chinese": "大方的；慷慨的", "grade": 5, "unit": "性格与品质", "example": "Generous hearts help others.", "gradeName": "五年级", "meaning": "大方的；慷慨的", "pos": "adj."}, {"id": "pep_723", "word": "confident", "phonetic": "/ˈkɒnfɪdənt/", "syllables": ["con", "fi", "dent"], "chinese": "自信的", "grade": 5, "unit": "性格与品质", "example": "Speak with confident voice.", "gradeName": "五年级", "meaning": "自信的", "pos": "adj."}, {"id": "pep_724", "word": "nervous", "phonetic": "/ˈnɜːvəs/", "syllables": ["ner", "vous"], "chinese": "紧张的", "grade": 4, "unit": "性格与品质", "example": "Take a deep breath if nervous.", "gradeName": "四年级", "meaning": "紧张的", "pos": "n."}, {"id": "pep_725", "word": "surprised", "phonetic": "/səˈpraɪzd/", "syllables": ["sur", "prised"], "chinese": "感到惊讶的", "grade": 4, "unit": "性格与品质", "example": "Surprised by the secret party.", "gradeName": "四年级", "meaning": "感到惊讶的", "pos": "n."}, {"id": "pep_726", "word": "gift", "phonetic": "/ɡɪft/", "syllables": ["gift"], "chinese": "礼物；天赋", "grade": 2, "unit": "性格与品质", "example": "A special birthday gift.", "gradeName": "二年级", "meaning": "礼物；天赋", "pos": "adj."}, {"id": "pep_727", "word": "prize", "phonetic": "/praɪz/", "syllables": ["prize"], "chinese": "奖品；奖项", "grade": 3, "unit": "性格与品质", "example": "Win first prize in speech contest.", "gradeName": "三年级", "meaning": "奖品；奖项", "pos": "n."}, {"id": "pep_728", "word": "medal", "phonetic": "/ˈmedl/", "syllables": ["med", "al"], "chinese": "奖牌；勋章", "grade": 4, "unit": "性格与品质", "example": "A shining gold medal.", "gradeName": "四年级", "meaning": "奖牌；勋章", "pos": "n."}];

  window.GD_VOCABULARY = GD_VOCABULARY;
  window.PEP_VOCABULARY = PEP_VOCABULARY;
  window.WORD_DATABASE = GD_VOCABULARY;
  let RAW_VOCABULARY = window.WORD_DATABASE;

  // 每日元气励志鼓励语库 (每次打开随机一条)
  const DAILY_QUOTES = [
    '🌟 每一个背会的新单词，都是点亮未来星空的小火苗！',
    '🚀 今天也是超能词域小探险家，准备好出发了吗？',
    '💪 坚持每天一小步，小小的你也能拥有大大的词汇宇宙！',
    '✨ 专注记忆 20 分钟，你的大脑神经元正在快速生长！',
    '🎯 不怕单词长，只要音节拆得细，一口一口吃掉它！',
    '🦁 勇敢的小勇士，今天又有一波词界小怪兽等着你击溃！',
    '🌈 英语是通向更广阔世界的钥匙，今天又拿下一把钥匙！',
    '⚡ 聚精会神，你的记忆反射速度比闪电还要迅猛！'
  ];

  // ================= 2. 离线音频与音效引擎 =================
  class SoundEngine {
    constructor() {
      this.ctx = null;
      this.speechSynth = window.speechSynthesis;
      this.voice = null;
      this.speechRate = 0.85;
      this.initCtx();
      this.initVoice();
    }

    initCtx() {
      try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (AudioCtx) this.ctx = new AudioCtx();
      } catch (e) {
        console.warn('AudioContext not supported');
      }
    }

    initVoice() {
      if (!this.speechSynth) return;
      const setVoice = () => {
        const voices = this.speechSynth.getVoices();
        this.voice = voices.find(v => v.lang.startsWith('en-US') || v.lang.startsWith('en-GB') || v.lang.startsWith('en')) || null;
      };
      setVoice();
      if (this.speechSynth.onvoiceschanged !== undefined) {
        this.speechSynth.onvoiceschanged = setVoice;
      }
    }

    resumeCtx() {
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
    }

    speak(text, rate = null, onEnd = null) {
      if (!text) return;
      this.resumeCtx();

      const cleanText = text.trim();
      // 智能双轨发音：针对手机端(华为/安卓)及长句例句缺少本地英文音库的问题，优先/降级调用标准真人音频
      const playFallbackAudio = () => {
        try {
          const audioUrl = `https://dict.youdao.com/dictvoice?audio=${encodeURIComponent(cleanText)}&type=2`;
          const audio = new Audio(audioUrl);
          if (rate) audio.playbackRate = rate;
          audio.onended = () => { if (onEnd) onEnd(); };
          audio.onerror = () => {
            if (this.speechSynth) {
              const utter = new SpeechSynthesisUtterance(cleanText);
              utter.lang = 'en-US';
              if (onEnd) utter.onend = onEnd;
              this.speechSynth.speak(utter);
            }
          };
          const p = audio.play();
          if (p !== undefined) {
            p.catch(() => {
              if (this.speechSynth) {
                const utter = new SpeechSynthesisUtterance(cleanText);
                utter.lang = 'en-US';
                if (onEnd) utter.onend = onEnd;
                this.speechSynth.speak(utter);
              }
            });
          }
        } catch (err) {
          console.warn('Audio fallback error:', err);
        }
      };

      const isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
      if (isMobile) {
        playFallbackAudio();
        return;
      }

      // 电脑端优先本地 TTS 极速朗读，异常则自动降级
      if (this.speechSynth) {
        try {
          this.speechSynth.cancel();
          const utter = new SpeechSynthesisUtterance(cleanText);
          utter.lang = 'en-US';
          utter.rate = rate || this.speechRate;
          utter.pitch = 1.0;
          if (this.voice) utter.voice = this.voice;
          if (onEnd) utter.onend = onEnd;
          utter.onerror = () => playFallbackAudio();
          this.speechSynth.speak(utter);
        } catch (e) {
          playFallbackAudio();
        }
      } else {
        playFallbackAudio();
      }
    }

    playTone(type) {
      this.resumeCtx();
      if (!this.ctx) return;
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.connect(gain);
      gain.connect(this.ctx.destination);

      if (type === 'correct') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, t);
        osc.frequency.setValueAtTime(659.25, t + 0.1);
        gain.gain.setValueAtTime(0.3, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.35);
        osc.start(t);
        osc.stop(t + 0.35);
      } else if (type === 'wrong') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(180, t);
        osc.frequency.setValueAtTime(140, t + 0.12);
        gain.gain.setValueAtTime(0.25, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.3);
        osc.start(t);
        osc.stop(t + 0.3);
      } else if (type === 'combo') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, t);
        osc.frequency.setValueAtTime(554.37, t + 0.08);
        osc.frequency.setValueAtTime(659.25, t + 0.16);
        gain.gain.setValueAtTime(0.3, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.4);
        osc.start(t);
        osc.stop(t + 0.4);
      } else if (type === 'laser') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(880, t);
        osc.frequency.exponentialRampToValueAtTime(110, t + 0.2);
        gain.gain.setValueAtTime(0.35, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.2);
        osc.start(t);
        osc.stop(t + 0.2);
      } else if (type === 'ultimate') {
        osc.type = 'square';
        osc.frequency.setValueAtTime(300, t);
        osc.frequency.linearRampToValueAtTime(900, t + 0.4);
        gain.gain.setValueAtTime(0.35, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.7);
        osc.start(t);
        osc.stop(t + 0.7);
      } else if (type === 'troop') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(400, t);
        osc.frequency.exponentialRampToValueAtTime(600, t + 0.15);
        gain.gain.setValueAtTime(0.2, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.2);
        osc.start(t);
        osc.stop(t + 0.2);
      }
    }
  }

  // ================= 3. 数据存储与学习履历管理 =================
  class StorageManager {
    constructor() {
      this.STORAGE_KEY = 'word_explorer_state_v4';
      this.state = this.loadState();
    }

    getDefaultState() {
      return {
        pet: 'sprite',
        petExp: 60,
        petLevel: 1,
        combo: 0,
        masteredIds: [],
        mistakes: [
          { id: 'g1_003', word: 'pencil', phonetic: '/ˈpensl/', meaning: '铅笔', grade: 1, count: 2, lastTime: new Date().toLocaleDateString('zh-CN') },
          { id: 'g6_004', word: 'astronaut', phonetic: '/ˈæstrənɔːt/', meaning: '宇航员；航天员', grade: 6, count: 3, lastTime: new Date().toLocaleDateString('zh-CN') }
        ],
        parentSettings: {
          grades: [1, 2, 3, 4, 5, 6],
          targetMinutes: 60,
          includeMistakes: false,
          customVocabIds: [],
          targetWordCount: 20,
          preventRepeat7Days: true,
          textbookVersion: 'pep'
        },
        customVocabs: {},
        wordTestLogs: {},
        gameSettings: {
          followParent: true,
          grades: [1, 2, 3, 4, 5, 6],
          onlyMistakes: false
        },
        todayProgress: {
          step1: false, // 考听力
          step2: false, // 考读音
          step3: false, // 考书写
          step4: false, // 考总结
          step1Count: 0,
          step2Count: 0,
          step3Count: 0,
        },
        timerSeconds: 0,
        isTimerRunning: true
      };
    }

    loadState() {
      try {
        const raw = localStorage.getItem(this.STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw);
          return Object.assign(this.getDefaultState(), parsed);
        }
      } catch (e) {
        console.warn('Load storage error, fallback to default');
      }
      return this.getDefaultState();
    }

    save() {
      try {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.state));
      } catch (e) {
        console.warn('Save storage error', e);
      }
    }

    recordWordTested(word) {
      if (!this.state.wordTestLogs) this.state.wordTestLogs = {};
      this.state.wordTestLogs[word] = Date.now();
      this.save();
    }

    recordMistake(wordObj) {
      const existing = this.state.mistakes.find(m => m.id === wordObj.id);
      if (existing) {
        existing.count += 1;
        existing.lastTime = new Date().toLocaleDateString('zh-CN');
      } else {
        this.state.mistakes.push({
          id: wordObj.id,
          word: wordObj.word,
          phonetic: wordObj.phonetic,
          meaning: wordObj.meaning,
          grade: wordObj.grade,
          count: 1,
          lastTime: new Date().toLocaleDateString('zh-CN')
        });
      }
      this.save();
    }

    markMastered(wordId) {
      if (!this.state.masteredIds.includes(wordId)) {
        this.state.masteredIds.push(wordId);
        this.save();
      }
    }

    clearAllData() {
      localStorage.removeItem(this.STORAGE_KEY);
      this.state = this.getDefaultState();
      this.save();
    }
  }

  // ================= 4. 主应用程序 =================
  class WordExplorerApp {
    constructor() {
      this.sound = new SoundEngine();
      this.storage = new StorageManager();
      this.currentView = 'training';
      this.currentStep = 1;
      this.activeGameTab = 'igloo';

      this.challengePool = [];
      this.gamePool = [];
      this.currentWord = null;
      this.stage1Input = '';
      this.stage1TypingSuccess = false;
      this.stage2Input = '';
      this.stage3Input = '';

      // 关卡 2 读音 3 遍跟读计数
      this.readStreak = 0;

      // 冰原对战
      this.iglooPlayerHp = 100;
      this.iglooEnemyHp = 100;
      this.iglooEnergy = 0;
      this.iglooTimer = 120;
      this.iglooInterval = null;

      // 星际消陨石
      this.meteorScore = 0;
      this.meteorShield = 100;
      this.meteorWord = null;

      // 连连看
      this.matchSelected = null;
      this.matchPairsCount = 0;
      this.matchScore = 0;
      this.matchCountdown = 60;
      this.matchInterval = null;

      this.timerInterval = null;

      this.init();
    }

    init() {
      try {
        this.applyTheme(this.storage.state.pet);
        this.pickDailyQuote();
      } catch(e) { console.warn('Theme/Quote init error:', e); }

      // 核心：优先绑定全局点击与交互事件，确保开屏按钮与切换按钮百分之百可用
      try {
        this.bindEvents();
      } catch(e) { console.error('BindEvents error:', e); }

      try {
        this.initCanvasParticle();
        this.startGlobalTimer();
      } catch(e) { console.warn('Particle/Timer error:', e); }

      // 核心数据渲染，全部加上保护避免未定义字段阻断流程
      try {
        this.initTextbookVersion();
      } catch(e) { console.warn('initTextbookVersion error:', e); }

      try {
        this.renderCustomVocabManager();
        this.renderParentCustomPools();
        this.refreshChallengePool();
        this.updateGamePool();
      } catch(e) { console.warn('Pool/CustomVocab init error:', e); }

      try {
        this.renderFullWordList();
        this.renderMistakesTable();
        this.renderGradeAnalytics();
        this.updateHudStats();
        this.renderParentDailyReport();
      } catch(e) { console.warn('Render table/analytics error:', e); }

      try {
        this.setStep(1, false);
      } catch(e) { console.warn('setStep(1) error:', e); }
    }

    pickDailyQuote() {
      const qEl = document.getElementById('splashDailyQuote');
      if (qEl) {
        const randQ = DAILY_QUOTES[Math.floor(Math.random() * DAILY_QUOTES.length)];
        qEl.textContent = randQ;
      }
    }

    // 主题大世界切换 (背景、粒子色与胶囊完全联动)
    applyTheme(pet) {
      this.storage.state.pet = pet;
      this.storage.save();

      // 同步 body 类
      document.body.classList.remove('theme-fox', 'theme-drake', 'theme-sprite', 'theme-unicorn');
      const themeClass = pet === 'fox' ? 'theme-fox' : (pet === 'drake' ? 'theme-drake' : (pet === 'unicorn' ? 'theme-unicorn' : 'theme-sprite'));
      document.body.classList.add(themeClass);

      // 同步欢迎幕的大世界动态背景类
      const splash = document.getElementById('splashScreen');
      if (splash) {
        splash.classList.remove('theme-fox', 'theme-drake', 'theme-sprite', 'theme-unicorn');
        splash.classList.add(themeClass);
      }

      // 同步欢迎幕高清奇幻壁纸背景
      const splashBgLayer = document.getElementById('splashBgLayer');
      if (splashBgLayer) {
        if (pet === 'drake') {
          splashBgLayer.style.backgroundImage = "url('assets/bg/castle.jpg')";
        } else if (pet === 'fox') {
          splashBgLayer.style.backgroundImage = "url('assets/bg/whale.jpg')";
        } else if (pet === 'unicorn') {
          splashBgLayer.style.backgroundImage = "url('assets/bg/unicorn.jpg')";
        } else {
          splashBgLayer.style.backgroundImage = "url('assets/bg/jungle.jpg')";
        }
      }

      // 同步胶囊
      document.querySelectorAll('.capsule-theme-btn').forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-pet') === pet);
      });

      const splashIcon = document.getElementById('splashPetIcon');
      const splashWorldName = document.getElementById('splashWorldName');
      const topAvatar = document.getElementById('topPetAvatar');
      const topName = document.getElementById('topPetName');
      const topThemePill = document.getElementById('topThemePill');

      if (pet === 'fox') {
        if (splashIcon) splashIcon.textContent = '🐋';
        if (splashWorldName) splashWorldName.textContent = '星空巨鲸世界';
        if (topAvatar) topAvatar.textContent = '🐋';
        if (topName) topName.textContent = `星空巨鲸 (Lv.${this.storage.state.petLevel})`;
        if (topThemePill) topThemePill.textContent = '星空巨鲸版 v2.2.0';
      } else if (pet === 'drake') {
        if (splashIcon) splashIcon.textContent = '🏰';
        if (splashWorldName) splashWorldName.textContent = '云端城堡世界';
        if (topAvatar) topAvatar.textContent = '🏰';
        if (topName) topName.textContent = `云端守护 (Lv.${this.storage.state.petLevel})`;
        if (topThemePill) topThemePill.textContent = '云端城堡版 v2.2.0';
      } else if (pet === 'unicorn') {
        if (splashIcon) splashIcon.textContent = '🦄';
        if (splashWorldName) splashWorldName.textContent = '糖果仙境世界';
        if (topAvatar) topAvatar.textContent = '🦄';
        if (topName) topName.textContent = `梦幻独角兽 (Lv.${this.storage.state.petLevel})`;
        if (topThemePill) topThemePill.textContent = '糖果仙境版 v2.2.0';
      } else {
        if (splashIcon) splashIcon.textContent = '🍃';
        if (splashWorldName) splashWorldName.textContent = '恐龙雨林世界';
        if (topAvatar) topAvatar.textContent = '🍃';
        if (topName) topName.textContent = `森之精灵 (Lv.${this.storage.state.petLevel})`;
        if (topThemePill) topThemePill.textContent = '恐龙雨林版 v2.2.0';
      }
    }

    selectPet(pet) {
      this.applyTheme(pet);
    }

    // 粒子动效画布 (支持随大世界变换色彩)
    initCanvasParticle() {
      const canvas = document.getElementById('splashCanvas');
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      let w = canvas.width = window.innerWidth;
      let h = canvas.height = window.innerHeight;

      window.addEventListener('resize', () => {
        w = canvas.width = window.innerWidth;
        h = canvas.height = window.innerHeight;
      });

      const particles = [];
      for (let i = 0; i < 50; i++) {
        particles.push({
          x: Math.random() * w,
          y: Math.random() * h,
          r: Math.random() * 3 + 1,
          vx: (Math.random() - 0.5) * 0.8,
          vy: (Math.random() - 0.5) * 0.8
        });
      }

      const getParticleColor = () => {
        const pet = this.storage.state.pet;
        if (pet === 'drake') return ['#f87171', '#f59e0b', '#fbbf24', '#ef4444'][Math.floor(Math.random() * 4)];
        if (pet === 'fox') return ['#a78bfa', '#38bdf8', '#818cf8', '#60a5fa'][Math.floor(Math.random() * 4)];
        return ['#34d399', '#10b981', '#6ee7b7', '#fde047'][Math.floor(Math.random() * 4)];
      };

      const draw = () => {
        ctx.clearRect(0, 0, w, h);
        particles.forEach(p => {
          p.x += p.vx;
          p.y += p.vy;
          if (p.x < 0) p.x = w;
          if (p.x > w) p.x = 0;
          if (p.y < 0) p.y = h;
          if (p.y > h) p.y = 0;

          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fillStyle = getParticleColor();
          ctx.globalAlpha = 0.55;
          ctx.fill();
        });
        requestAnimationFrame(draw);
      };
      draw();
    }

    // ---------------- 词库版本与出词大盘核心架构 ----------------
    initTextbookVersion() {
      const ver = (this.storage.state.parentSettings && this.storage.state.parentSettings.textbookVersion) || 'pep';
      const sel = document.getElementById('settingTextbookVersion');
      if (sel) sel.value = ver;
      this.switchTextbookVersion(ver, false);
    }

    switchTextbookVersion(version, shouldSave = true) {
      if (version === 'pep') {
        window.WORD_DATABASE = window.PEP_VOCABULARY || [];
      } else {
        window.WORD_DATABASE = window.GD_VOCABULARY || [];
      }
      RAW_VOCABULARY = window.WORD_DATABASE;

      if (shouldSave) {
        this.storage.state.parentSettings.textbookVersion = version;
        this.storage.save();
      }

      const badge = document.getElementById('settingVocabCountBadge');
      if (badge) {
        const name = version === 'pep' ? '人教版 PEP' : '广东教科版';
        badge.textContent = `${name} · 实装 ${window.WORD_DATABASE.length} 词`;
      }

      this.refreshChallengePool();
      this.updateGamePool();
      this.renderFullWordList();
      this.renderGradeAnalytics();
    }

    exportCurrentVocab() {
      const ver = (this.storage.state.parentSettings && this.storage.state.parentSettings.textbookVersion) || 'pep';
      const verName = ver === 'pep' ? '人教版PEP' : (ver === 'gd' ? '广东教科版' : '官方英语教材');
      const list = window.WORD_DATABASE || [];
      const filename = `${verName}_小学1-6年级考纲核心词汇表(${list.length}词)`;

      if (window.XLSX) {
        try {
          const rows = list.map((item, idx) => ({
            '序号': idx + 1,
            '适用年级': item.grade || '小学',
            '单元/主题': item.unit || '核心考纲',
            '英文单词': item.word,
            '国际音标': item.phonetic || '',
            '音节切分': Array.isArray(item.syllables) ? item.syllables.join('·') : (item.syllables || ''),
            '规范中文释义': item.chinese || item.meaning || '',
            '核心例句': item.example || ''
          }));
          const ws = XLSX.utils.json_to_sheet(rows);
          ws['!cols'] = [
            { wch: 8 },
            { wch: 12 },
            { wch: 14 },
            { wch: 18 },
            { wch: 18 },
            { wch: 20 },
            { wch: 24 },
            { wch: 45 }
          ];
          const wb = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wb, ws, '核心词汇表');
          XLSX.writeFile(wb, `${filename}.xlsx`);
          alert(`✅ 成功导出标准 Excel 词汇表！\n文件名称：${filename}.xlsx\n共包含 ${list.length} 个考纲单词，双击即可在 Excel / WPS 中秒开查看与打印！`);
          return;
        } catch (err) {
          console.warn('XLSX export failed, falling back to CSV', err);
        }
      }

      // Fallback CSV with UTF-8 BOM
      const headers = ['序号', '适用年级', '单元/主题', '英文单词', '国际音标', '音节切分', '规范中文释义', '核心例句'];
      const csvRows = [headers.join(',')];
      list.forEach((item, idx) => {
        const row = [
          idx + 1,
          `"${(item.grade || '').replace(/"/g, '""')}"`,
          `"${(item.unit || '').replace(/"/g, '""')}"`,
          `"${(item.word || '').replace(/"/g, '""')}"`,
          `"${(item.phonetic || '').replace(/"/g, '""')}"`,
          `"${(Array.isArray(item.syllables) ? item.syllables.join('·') : (item.syllables || '')).replace(/"/g, '""')}"`,
          `"${(item.chinese || item.meaning || '').replace(/"/g, '""')}"`,
          `"${(item.example || '').replace(/"/g, '""')}"`
        ];
        csvRows.push(row.join(','));
      });
      const blob = new Blob(["\uFEFF" + csvRows.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filename}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      alert(`✅ 成功导出 Excel/CSV 词汇表！已下载 ${list.length} 个单词。`);
    }

    downloadExcelTemplate() {
      if (window.XLSX) {
        const sampleRows = [
          { '序号': 1, '适用年级': '三年级', '单元/主题': 'Unit 1', '英文单词': 'astronaut', '国际音标': '/ˈæstrənɔːt/', '音节切分': 'as·tro·naut', '规范中文释义': '航天员；宇航员', '核心例句': 'Astronauts travel into outer space.' },
          { '序号': 2, '适用年级': '三年级', '单元/主题': 'Unit 1', '英文单词': 'telescope', '国际音标': '/ˈtelɪskəʊp/', '音节切分': 'tel·e·scope', '规范中文释义': '望远镜', '核心例句': 'Look at the stars through a telescope.' },
          { '序号': 3, '适用年级': '四年级', '单元/主题': 'Unit 2', '英文单词': 'adventure', '国际音标': '/ədˈventʃə(r)/', '音节切分': 'ad·ven·ture', '规范中文释义': '探险；冒险', '核心例句': 'They set off on a jungle adventure.' }
        ];
        const ws = XLSX.utils.json_to_sheet(sampleRows);
        ws['!cols'] = [{ wch: 8 }, { wch: 12 }, { wch: 14 }, { wch: 18 }, { wch: 18 }, { wch: 20 }, { wch: 24 }, { wch: 45 }];
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, '自定义词库模板');
        XLSX.writeFile(wb, '词域探险家_自定义专属词库模板.xlsx');
        alert('✅ 成功下载专属词库 Excel 模板！\n您可以在 Excel 中按列填写单词，保存后直接点击“➕ 上传 Excel / CSV / JSON 词单”即可快速导入！');
        return;
      }
      alert('⚠️ 无法加载 Excel 处理引擎，请稍候重试。');
    }

    renderCustomVocabManager() {
      const vocabs = this.storage.state.customVocabs || {};
      const keys = Object.keys(vocabs);
      const badge = document.getElementById('customVocabBadge');
      if (badge) badge.textContent = `已上传 ${keys.length} 个自定义词库`;

      const container = document.getElementById('customVocabListContainer');
      if (!container) return;
      container.innerHTML = '';

      if (keys.length === 0) {
        container.innerHTML = '<div style="font-size: 12px; color: var(--text-muted); font-style: italic;" id="customVocabEmptyHint">暂无已上传的自定义词库，点击上方“➕ 上传新词库包”即可上传第一套专属词单。</div>';
        return;
      }

      keys.forEach(k => {
        const v = vocabs[k];
        const row = document.createElement('div');
        row.style.cssText = 'display: flex; justify-content: space-between; align-items: center; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px 14px;';
        row.innerHTML = `
          <div>
            <strong style="font-size: 13px; color: #0f172a;">📄 ${v.name}</strong>
            <span style="font-size: 11px; color: #64748b; margin-left: 8px;">共 ${v.words.length} 词 · 上传于 ${v.createdAt || '近期'}</span>
          </div>
          <div style="display: flex; gap: 8px;">
            <button class="btn-clean secondary" onclick="window.app.previewCustomVocab('${v.id}')" style="padding: 3px 10px; font-size: 11px; font-weight: 700;">👁️ 查看清单</button>
            <button class="btn-clean danger" onclick="window.app.deleteCustomVocab('${v.id}')" style="padding: 3px 10px; font-size: 11px; font-weight: 700;">🗑️ 删除</button>
          </div>
        `;
        container.appendChild(row);
      });
    }

    renderParentCustomPools() {
      const vocabs = this.storage.state.customVocabs || {};
      const keys = Object.keys(vocabs);
      const container = document.getElementById('parentCustomVocabPoolContainer');
      const mistakesCountLabel = document.getElementById('parentMistakesCountLabel');
      if (mistakesCountLabel) {
        mistakesCountLabel.textContent = this.storage.state.mistakes ? this.storage.state.mistakes.length : 0;
      }

      const cbMistakes = document.getElementById('cbIncludeMistakes');
      if (cbMistakes) {
        cbMistakes.checked = !!this.storage.state.parentSettings.includeMistakes;
      }

      const cb7Days = document.getElementById('cbPreventRepeat7Days');
      if (cb7Days) {
        cb7Days.checked = this.storage.state.parentSettings.preventRepeat7Days !== false;
      }

      const selCount = document.getElementById('parentTargetWordCount');
      if (selCount && this.storage.state.parentSettings.targetWordCount) {
        selCount.value = this.storage.state.parentSettings.targetWordCount;
      }

      const selDurationRestore = document.getElementById('parentTargetDuration');
      if (selDurationRestore && this.storage.state.parentSettings.targetDuration) {
        selDurationRestore.value = this.storage.state.parentSettings.targetDuration;
      }

      // 同步更新复核候选清单中的分类筛选下拉框
      const filterCatSel = document.getElementById('candidateFilterCategory');
      if (filterCatSel) {
        while (filterCatSel.options.length > 8) {
          filterCatSel.remove(8);
        }
        keys.forEach(k => {
          const v = vocabs[k];
          const opt = document.createElement('option');
          opt.value = `custom_${v.id}`;
          opt.textContent = `📁 分类: ${v.name} (${v.words.length}词)`;
          filterCatSel.appendChild(opt);
        });
      }

      if (!container) return;
      container.innerHTML = '';

      const checkedIds = this.storage.state.parentSettings.customVocabIds || [];
      keys.forEach(k => {
        const v = vocabs[k];
        const label = document.createElement('div');
        label.className = 'grade-cb-item custom-pool-chip';
        label.style.cssText = 'border-color: #0284c7; background: #f0f9ff; color: #0369a1; font-weight: 800; display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px; border-radius: 6px;';
        const isChecked = checkedIds.includes(v.id);
        label.innerHTML = `
          <label style="display: inline-flex; align-items: center; gap: 5px; cursor: pointer; margin: 0;">
            <input type="checkbox" name="parentCustomCombo" value="${v.id}" ${isChecked ? 'checked' : ''}>
            <span>📁 ${v.name} (${v.words.length}词)</span>
          </label>
          <button type="button" class="btn-del-custom-vocab" data-id="${v.id}" title="删除该词单" style="background: none; border: none; cursor: pointer; font-size: 11px; padding: 0 4px; color: #94a3b8; font-weight: 900;">✕</button>
        `;
        container.appendChild(label);
      });

      container.querySelectorAll('input[name="parentCustomCombo"]').forEach(cb => {
        cb.addEventListener('change', () => {
          const selected = Array.from(container.querySelectorAll('input[name="parentCustomCombo"]:checked'))
            .map(el => el.value);
          this.storage.state.parentSettings.customVocabIds = selected;
          this.storage.save();
          this.refreshChallengePool();
          this.updateGamePool();
        });
      });

      // 删除专属词单
      container.querySelectorAll('.btn-del-custom-vocab').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const vid = btn.getAttribute('data-id');
          const v = (this.storage.state.customVocabs || {})[vid];
          const name = v ? v.name : '该词单';
          if (confirm(`确定要删除特训词单【${name}】吗？删除后不可撤回。`)) {
            delete this.storage.state.customVocabs[vid];
            if (this.storage.state.parentSettings.customVocabIds) {
              this.storage.state.parentSettings.customVocabIds = this.storage.state.parentSettings.customVocabIds.filter(id => id !== vid);
            }
            this.storage.save();
            this.renderParentCustomPools();
            this.refreshChallengePool();
            this.updateGamePool();
            if (typeof this.renderCustomVocabManager === 'function') {
              this.renderCustomVocabManager();
            }
          }
        });
      });
    }

    previewCustomVocab(id) {
      const v = (this.storage.state.customVocabs || {})[id];
      if (!v) return;
      const previewList = v.words.map((w, i) => `${i+1}. ${w.word} (${w.meaning})`).slice(0, 30).join('\n');
      const suffix = v.words.length > 30 ? `\n... 共有 ${v.words.length} 个单词` : '';
      alert(`📖【${v.name}】词单明细预览：\n\n${previewList}${suffix}`);
    }

    deleteCustomVocab(id) {
      const v = (this.storage.state.customVocabs || {})[id];
      if (!v) return;
      if (confirm(`确定要删除自定义词库【${v.name}】吗？删除后出词池将不再包含这些词。`)) {
        delete this.storage.state.customVocabs[id];
        const customIds = this.storage.state.parentSettings.customVocabIds || [];
        this.storage.state.parentSettings.customVocabIds = customIds.filter(x => x !== id);
        this.storage.save();
        this.renderCustomVocabManager();
        this.renderParentCustomPools();
        this.refreshChallengePool();
        this.updateGamePool();
      }
    }

    refreshChallengePool() {
      const allowedGrades = (this.storage.state.parentSettings && this.storage.state.parentSettings.grades) || [1, 2, 3, 4, 5, 6];
      let pool = (window.WORD_DATABASE || RAW_VOCABULARY).filter(w => allowedGrades.includes(w.grade));

      // 纳入错题专项词库
      const mistakeWords = new Set();
      if (this.storage.state.parentSettings && this.storage.state.parentSettings.includeMistakes && this.storage.state.mistakes) {
        this.storage.state.mistakes.forEach(m => {
          mistakeWords.add(m.word);
          const found = (window.WORD_DATABASE || RAW_VOCABULARY).find(w => w.word === m.word);
          if (found) pool.push(found);
          else pool.push({ id: m.id || 'm_' + m.word, word: m.word, phonetic: m.phonetic || '', meaning: m.meaning || '错词攻坚', syllables: [m.word], grade: m.grade || 1, example: `Focus on: ${m.word}`, maskSentence: 'Focus on: _____', sceneImg: '🔥' });
        });
      }

      // 纳入已勾选自定义词单
      const customVocabs = this.storage.state.customVocabs || {};
      const checkedCustomIds = (this.storage.state.parentSettings && this.storage.state.parentSettings.customVocabIds) || [];
      checkedCustomIds.forEach(cid => {
        if (customVocabs[cid] && customVocabs[cid].words) {
          const marked = customVocabs[cid].words.map(w => ({ ...w, customVocabId: cid }));
          pool = pool.concat(marked);
        }
      });

      // 去重
      const map = new Map();
      pool.forEach(w => { if (!map.has(w.word)) map.set(w.word, w); });
      const candidateList = Array.from(map.values());

      // 7 天防重复算法
      const now = Date.now();
      const SEVEN_DAYS = 7 * 86400 * 1000;
      const logs = this.storage.state.wordTestLogs || {};

      const unseenWords = [];
      const recentWords = [];
      candidateList.forEach(w => {
        const lastTime = logs[w.word];
        if (!lastTime || (now - lastTime) > SEVEN_DAYS) {
          unseenWords.push(w);
        } else {
          recentWords.push(w);
        }
      });

      unseenWords.sort(() => Math.random() - 0.5);
      recentWords.sort(() => Math.random() - 0.5);

      let orderedPool = [];
      if (!this.storage.state.parentSettings || this.storage.state.parentSettings.preventRepeat7Days !== false) {
        orderedPool = unseenWords.concat(recentWords);
      } else {
        orderedPool = [...candidateList].sort(() => Math.random() - 0.5);
      }

      const targetCount = this.storage.state.parentSettings && this.storage.state.parentSettings.targetWordCount;
      if (targetCount === 'all') {
        this.challengePool = orderedPool;
      } else {
        const num = parseInt(targetCount, 10) || 20;
        this.challengePool = orderedPool.slice(0, Math.min(num, orderedPool.length));
      }
      if (this.challengePool.length === 0) {
        this.challengePool = window.WORD_DATABASE || RAW_VOCABULARY;
      }

      // 实时更新大盘统计与候选清单展示
      this.renderCandidateDashboard(candidateList, unseenWords, mistakeWords);
    }

    renderCandidateDashboard(candidateList, unseenWords, mistakeWords) {
      this.currentCandidateList = candidateList;
      const statTotal = document.getElementById('statCandidateTotal');
      const statUnseenPct = document.getElementById('statUnseenPercent');
      const statUnseenCnt = document.getElementById('statUnseenCount');
      const statMistakePct = document.getElementById('statMistakePercent');
      const statMistakeCnt = document.getElementById('statMistakeCount');

      const total = candidateList.length;
      let mistakeCount = 0;
      candidateList.forEach(w => {
        if (mistakeWords.has(w.word)) mistakeCount++;
      });

      if (statTotal) statTotal.textContent = total;
      if (statUnseenCnt) statUnseenCnt.textContent = unseenWords.length;
      if (statUnseenPct) statUnseenPct.textContent = total ? Math.round((unseenWords.length / total) * 100) + '%' : '0%';
      if (statMistakeCnt) statMistakeCnt.textContent = mistakeCount;
      if (statMistakePct) statMistakePct.textContent = total ? Math.round((mistakeCount / total) * 100) + '%' : '0%';

      const countBadge = document.getElementById('candidateCountBadge');
      if (countBadge) countBadge.textContent = total;
      const statDraw = document.getElementById('statDrawCount');
      if (statDraw) {
        const targetSel = document.getElementById('parentTargetWordCount');
        statDraw.textContent = (targetSel && targetSel.value !== 'all') ? targetSel.value : total;
      }

      const grid = document.getElementById('candidateWordListGrid');
      if (grid) {
        grid.innerHTML = '';
        const unseenSet = new Set(unseenWords.map(w => w.word));
        candidateList.forEach(w => {
          const isUnseen = unseenSet.has(w.word);
          const isMistake = mistakeWords.has(w.word);
          const label = document.createElement('label');
          label.className = 'candidate-chip';
          label.setAttribute('data-word', w.word);
          label.setAttribute('data-grade', String(w.grade || ''));
          label.setAttribute('data-mistake', isMistake ? '1' : '0');
          label.setAttribute('data-custom', String(w.customVocabId || ''));

          label.innerHTML = `
            <input type="checkbox" class="word-select-cb" data-word="${w.word}">
            <strong>${w.word}</strong>
            <span style="color: #64748b; font-size: 11px;">${w.meaning || w.chinese || ''}</span>
            <span style="font-size: 10px; color: #0284c7; background: #e0f2fe; padding: 1px 4px; border-radius: 4px;">${typeof w.grade === 'number' ? w.grade + '年级' : (w.grade || '')}</span>
            ${isMistake ? '<span style="font-size: 10px; color: #ea580c; font-weight: 800;">🔥错题</span>' : ''}
            ${isUnseen ? '<span style="font-size: 10px; color: #059669; font-weight: 800;">🌟7天未测</span>' : ''}
          `;

          const cb = label.querySelector('.word-select-cb');
          cb.addEventListener('change', () => {
            label.classList.toggle('selected', cb.checked);
            this.updateCandidateSelectedToolbar();
          });

          grid.appendChild(label);
        });

        this.filterCandidateList();
        this.updateCandidateSelectedToolbar();
      }
    }

    // 候选池勾选浮动工具栏刷新
    updateCandidateSelectedToolbar() {
      const toolbar = document.getElementById('candidateSelectedActionToolbar');
      const countEl = document.getElementById('selectedWordCount');
      const checkedCbs = document.querySelectorAll('#candidateWordListGrid .word-select-cb:checked');
      const cnt = checkedCbs.length;
      if (countEl) countEl.textContent = cnt;
      if (toolbar) toolbar.style.display = cnt > 0 ? 'flex' : 'none';
    }

    // 候选清单分类与关键词综合筛选 (支持年级分类与智能语义联想)
    filterCandidateList() {
      const catSel = document.getElementById('candidateFilterCategory');
      const cat = catSel ? catSel.value : 'all';
      const searchInput = document.getElementById('candidateListSearchInput');
      const q = searchInput ? searchInput.value.toLowerCase().trim() : '';

      // 常见小学英语主题语义字典扩展
      const SMART_CATEGORY_MAP = {
        '水果': ['fruit', 'apple', 'banana', 'pear', 'orange', 'grape', 'watermelon', 'strawberry', 'peach', 'lemon', 'mango', 'pineapple', 'cherry', 'melon'],
        '蔬菜': ['vegetable', 'tomato', 'potato', 'carrot', 'onion', 'cucumber', 'cabbage', 'bean'],
        '动物': ['animal', 'dog', 'cat', 'duck', 'pig', 'bird', 'bear', 'elephant', 'tiger', 'lion', 'monkey', 'panda', 'rabbit', 'fish', 'cow', 'horse', 'sheep', 'hen', 'zebra', 'giraffe', 'snake', 'whale', 'dolphin', 'shark', 'kangaroo', 'insect', 'butterfly', 'bee', 'ant', 'fox', 'wolf', 'goose', 'chick', 'dinosaur', 'pet'],
        '食物': ['food', 'eat', 'drink', 'bread', 'rice', 'noodles', 'egg', 'milk', 'meat', 'chicken', 'beef', 'cake', 'ice cream', 'hamburger', 'tea', 'water', 'juice', 'soup', 'breakfast', 'lunch', 'dinner'],
        '颜色': ['color', 'colour', 'red', 'green', 'blue', 'yellow', 'black', 'white', 'orange', 'brown', 'pink', 'purple', 'grey', 'gray', 'gold', 'silver'],
        '数字': ['number', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety', 'hundred', 'thousand', 'first', 'second', 'third'],
        '身体': ['body', 'head', 'face', 'eye', 'ear', 'nose', 'mouth', 'arm', 'hand', 'leg', 'foot', 'feet', 'finger', 'toe', 'hair', 'tooth', 'teeth'],
        '家庭': ['family', 'father', 'dad', 'mother', 'mum', 'mom', 'brother', 'sister', 'grandfather', 'grandpa', 'grandmother', 'grandma', 'uncle', 'aunt', 'cousin', 'parents', 'baby'],
        '家人': ['family', 'father', 'dad', 'mother', 'mum', 'mom', 'brother', 'sister', 'grandfather', 'grandpa', 'grandmother', 'grandma', 'uncle', 'aunt', 'cousin', 'parents', 'baby'],
        '学校': ['school', 'book', 'pen', 'pencil', 'ruler', 'eraser', 'bag', 'desk', 'chair', 'classroom', 'teacher', 'student', 'blackboard', 'homework', 'lesson', 'class'],
        '文具': ['book', 'pen', 'pencil', 'ruler', 'eraser', 'bag', 'pencil-box', 'pencil-case', 'sharpener', 'crayon'],
        '天气': ['weather', 'sunny', 'rainy', 'cloudy', 'windy', 'snowy', 'warm', 'cool', 'hot', 'cold', 'rain', 'snow', 'wind', 'cloud', 'sun'],
        '季节': ['season', 'spring', 'summer', 'autumn', 'fall', 'winter'],
        '衣服': ['clothes', 'shirt', 'T-shirt', 'skirt', 'dress', 'pants', 'shorts', 'socks', 'shoes', 'coat', 'jacket', 'hat', 'cap', 'sweater'],
        '服装': ['clothes', 'shirt', 'T-shirt', 'skirt', 'dress', 'pants', 'shorts', 'socks', 'shoes', 'coat', 'jacket', 'hat', 'cap', 'sweater'],
        '职业': ['job', 'doctor', 'nurse', 'teacher', 'student', 'driver', 'worker', 'farmer', 'singer', 'dancer', 'cleaner', 'writer', 'actor', 'artist', 'engineer', 'scientist', 'astronaut', 'coach', 'player', 'police', 'cook'],
        '交通': ['traffic', 'car', 'bus', 'bike', 'bicycle', 'train', 'plane', 'airplane', 'ship', 'boat', 'subway', 'taxi', 'drive', 'ride', 'fly']
      };

      let smartWords = [];
      for (const [k, vList] of Object.entries(SMART_CATEGORY_MAP)) {
        if (q && (q.includes(k) || k.includes(q))) {
          smartWords = smartWords.concat(vList);
        }
      }

      const chips = document.querySelectorAll('#candidateWordListGrid .candidate-chip');
      let visibleCount = 0;
      chips.forEach(chip => {
        const word = (chip.getAttribute('data-word') || '').toLowerCase();
        const meaning = (chip.textContent || '').toLowerCase();
        const grade = chip.getAttribute('data-grade');
        const isMistake = chip.getAttribute('data-mistake') === '1';
        const customId = chip.getAttribute('data-custom') || '';

        let matchCat = true;
        if (cat === 'all') matchCat = true;
        else if (cat === 'mistake') matchCat = isMistake;
        else if (cat.startsWith('custom_')) matchCat = customId === cat.replace('custom_', '');
        else matchCat = String(grade) === String(cat);

        let matchQuery = true;
        if (q) {
          matchQuery = word.includes(q) || meaning.includes(q) || smartWords.includes(word);
        }

        const visible = matchCat && matchQuery;
        chip.classList.toggle('chip-hidden', !visible);
        if (visible) {
          chip.style.display = 'inline-flex';
          visibleCount++;
        } else {
          chip.style.display = 'none';
        }
      });

      const countHint = document.getElementById('candidateFilteredCountBadge');
      if (countHint) {
        countHint.textContent = `${visibleCount} 词`;
      }
    }

    // 标准 Excel 单词表导出工具
    exportWordsToExcel(wordsList, defaultFilename) {
      if (!window.XLSX) {
        alert('⚠️ Excel 导出模块尚未就绪，请稍候重试。');
        return;
      }
      if (!wordsList || wordsList.length === 0) {
        alert('⚠️ 当前没有可导出的单词。');
        return;
      }
      const rows = wordsList.map((w, idx) => ({
        '序号': idx + 1,
        '英文单词': w.word,
        '国际音标': w.phonetic || '',
        '规范中文释义': w.chinese || w.meaning || '',
        '归属年级/分类': (typeof w.grade === 'number' ? w.grade + '年级' : (w.grade || '自定义')),
        '核心例句': w.example || '',
        '音节拆解': Array.isArray(w.syllables) ? w.syllables.join(' · ') : (w.syllables || '')
      }));
      const ws = XLSX.utils.json_to_sheet(rows);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, '词汇清单');
      XLSX.writeFile(wb, defaultFilename || `词域探险家_词汇清单_${new Date().toISOString().slice(0, 10)}.xlsx`);
    }

    updateGamePool() {
      const followParentCb = document.getElementById('gameFollowParentSettings');
      const onlyMistakesCb = document.getElementById('gameOnlyMistakes');
      const customGroup = document.getElementById('gameCustomGradeGroup');

      const isFollow = followParentCb ? followParentCb.checked : this.storage.state.gameSettings.followParent;
      const isOnlyMistakes = onlyMistakesCb ? onlyMistakesCb.checked : this.storage.state.gameSettings.onlyMistakes;

      if (customGroup) {
        customGroup.style.opacity = isFollow ? '0.5' : '1';
        customGroup.style.pointerEvents = isFollow ? 'none' : 'auto';
      }

      if (isFollow) {
        this.refreshChallengePool();
        this.gamePool = [...this.challengePool];
      } else if (isOnlyMistakes) {
        if (this.storage.state.mistakes.length > 0) {
          const mistakeIds = this.storage.state.mistakes.map(m => m.id);
          this.gamePool = RAW_VOCABULARY.filter(w => mistakeIds.includes(w.id));
          if (this.gamePool.length === 0) this.gamePool = RAW_VOCABULARY.slice(0, 8);
        } else {
          alert('当前错题本为空，已为您自动切换为全量词库！');
          if (onlyMistakesCb) onlyMistakesCb.checked = false;
          this.gamePool = [...RAW_VOCABULARY];
        }
      } else {
        const checkedGrades = Array.from(document.querySelectorAll('input[name="gameGradeChoice"]:checked'))
          .map(el => parseInt(el.value, 10));
        if (checkedGrades.length === 0) {
          this.gamePool = [...RAW_VOCABULARY];
        } else {
          this.gamePool = RAW_VOCABULARY.filter(w => checkedGrades.includes(w.grade));
        }
      }

      if (this.gamePool.length === 0) this.gamePool = RAW_VOCABULARY;
      this.storage.state.gameSettings.followParent = isFollow;
      this.storage.state.gameSettings.onlyMistakes = isOnlyMistakes;
      this.storage.save();
    }

    handleGameFollowParent(checked) {
      this.storage.state.gameSettings.followParent = checked;
      this.storage.save();
      this.updateGamePool();
      if (this.activeGameTab === 'match') this.startNewGame();
      else if (this.activeGameTab === 'igloo') this.initIglooBattle();
    }

    toggleGameSettingsDropdown() {
      const dd = document.getElementById('gameSettingsDropdown');
      if (dd) dd.classList.toggle('active');
    }

    toggleGameFullscreen() {
      document.body.classList.toggle('game-fullscreen-mode');
      const btn = document.getElementById('btnToggleGameFullscreen');
      const isFull = document.body.classList.contains('game-fullscreen-mode');
      if (btn) btn.textContent = isFull ? '✕ 退出全屏' : '🖥️ 全屏游戏';
      this.toggleHardwareFullscreen(); // 触发硬件级绝对全屏
    }

    startGlobalTimer() {
      if (this.timerInterval) clearInterval(this.timerInterval);
      const timerDisplay = document.getElementById('hudTimerDisplay');
      const focusTimerDisplay = document.getElementById('focusTimerDisplay');
      const btnToggle = document.getElementById('btnToggleTimer');

      this.timerInterval = setInterval(() => {
        if (this.storage.state.isTimerRunning) {
          this.storage.state.timerSeconds += 1;
          const mins = Math.floor(this.storage.state.timerSeconds / 60).toString().padStart(2, '0');
          const secs = (this.storage.state.timerSeconds % 60).toString().padStart(2, '0');
          const timeStr = `${mins}:${secs}`;
          if (timerDisplay) timerDisplay.textContent = timeStr;
          if (focusTimerDisplay) focusTimerDisplay.textContent = timeStr;

          if (this.storage.state.timerSeconds % 10 === 0) this.storage.save();
        }
      }, 1000);

      if (btnToggle) {
        btnToggle.addEventListener('click', () => {
          this.storage.state.isTimerRunning = !this.storage.state.isTimerRunning;
          btnToggle.textContent = this.storage.state.isTimerRunning ? '⏸️' : '▶️';
          this.storage.save();
        });
      }

      const btnReset = document.getElementById('btnResetTimer');
      if (btnReset) {
        btnReset.addEventListener('click', () => {
          if (confirm('确认将今日累计学习时间清零重新开始计时吗？')) {
            this.storage.state.timerSeconds = 0;
            if (timerDisplay) timerDisplay.textContent = '00:00';
            if (focusTimerDisplay) focusTimerDisplay.textContent = '00:00';
            this.storage.save();
          }
        });
      }
    }

    toggleHardwareFullscreen(forceOn = false) {
      try {
        const isFull = !!(document.fullscreenElement || document.webkitFullscreenElement);
        if (forceOn || !isFull) {
          const docEl = document.documentElement;
          if (docEl.requestFullscreen) {
            docEl.requestFullscreen().catch(() => {});
          } else if (docEl.webkitRequestFullscreen) {
            docEl.webkitRequestFullscreen();
          }
        } else {
          if (document.exitFullscreen) {
            document.exitFullscreen().catch(() => {});
          } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
          }
        }
      } catch (e) {
        console.warn('Hardware fullscreen error:', e);
      }
    }

    enterFocusMode() {
      document.body.classList.add('focus-mode');
      this.updateFocusStepper();
      this.toggleHardwareFullscreen(true); // 触发硬件级绝对全屏
    }

    exitFocusMode() {
      document.body.classList.remove('focus-mode');
      if (document.fullscreenElement || document.webkitFullscreenElement) {
        if (document.exitFullscreen) document.exitFullscreen().catch(() => {});
      }
    }

    updateFocusStepper() {
      document.querySelectorAll('.focus-step-dot').forEach(dot => {
        const step = parseInt(dot.getAttribute('data-step'), 10);
        dot.classList.toggle('active', step === this.currentStep);
        dot.classList.toggle('completed', step < this.currentStep);
      });
    }

    // 关卡跳转与足迹追踪 (三部曲：1.读写学词 ➔ 2.看图默写 ➔ 3.听音辨义)
    setStep(stepNum, autoSpeak = false) {
      this.currentStep = stepNum;
      this.updateFocusStepper();

      document.querySelectorAll('.quest-card-item').forEach(card => {
        const s = parseInt(card.getAttribute('data-step'), 10);
        card.classList.toggle('active', s === stepNum);
      });

      for (let i = 1; i <= 3; i++) {
        const el = document.getElementById(`stage${i}-container`);
        if (el) el.style.display = i === stepNum ? 'block' : 'none';
      }

      this.pickRandomWord();

      if (stepNum === 1) {
        this.renderStage1ReadAndWrite(autoSpeak);
      } else if (stepNum === 2) {
        this.renderStage2Writing();
      } else if (stepNum === 3) {
        this.renderStage3Listening(autoSpeak);
      }
    }

    pickRandomWord() {
      if (this.challengePool.length === 0) this.refreshChallengePool();
      const randIdx = Math.floor(Math.random() * this.challengePool.length);
      this.currentWord = this.challengePool[randIdx];
    }

    // 智能双联具象记忆图谱生成器 (为每个词生成主场景大图与联想记忆小图)
    getWordDualMnemonic(wordObj) {
      if (!wordObj) return { mainIcon: '🌟', mainTitle: '形象概念', subIcon: '💡', subTitle: '语境联想' };
      const w = (wordObj.word || '').toLowerCase();
      const m = wordObj.meaning || wordObj.chinese || '';
      const u = wordObj.unit || '';

      // 1. 职业与社会身份
      if (w === 'driver' || m.includes('司机')) {
        return { mainIcon: '🚌', mainTitle: '公交/客车司机正专注驾驶', subIcon: '🚦', subTitle: '方向盘与安全红绿灯' };
      }
      if (w === 'doctor' || m.includes('医生') || m.includes('大夫')) {
        return { mainIcon: '👨‍⚕️', mainTitle: '身穿白大褂的救人医生', subIcon: '🩺', subTitle: '听诊器与急救医药箱' };
      }
      if (w === 'nurse' || m.includes('护士')) {
        return { mainIcon: '👩‍⚕️', mainTitle: '温柔耐心的白衣护士', subIcon: '💉', subTitle: '护理针筒与体温计' };
      }
      if (w === 'teacher' || m.includes('老师') || m.includes('教师')) {
        return { mainIcon: '👩‍🏫', mainTitle: '讲台上耐心讲课的老师', subIcon: '📚', subTitle: '三尺讲台与教材课本' };
      }
      if (w === 'student' || w === 'pupil' || m.includes('学生')) {
        return { mainIcon: '🧑‍🎓', mainTitle: '认真听讲上课的少先队员', subIcon: '🎒', subTitle: '红领巾与双肩书包' };
      }
      if (w === 'farmer' || m.includes('农民')) {
        return { mainIcon: '👨‍🌾', mainTitle: '田野间辛勤耕作的农民', subIcon: '🌾', subTitle: '丰收麦穗与农作草帽' };
      }
      if (w === 'cook' || m.includes('厨师')) {
        return { mainIcon: '👨‍🍳', mainTitle: '烹饪美味佳肴的厨师', subIcon: '🍳', subTitle: '热腾炒锅与厨师白帽' };
      }
      if (w === 'policeman' || m.includes('警察')) {
        return { mainIcon: '👮', mainTitle: '守护街道安全的交通警察', subIcon: '🚔', subTitle: '警灯警车与安全哨子' };
      }
      if (w === 'postman' || m.includes('邮递员')) {
        return { mainIcon: '📬', mainTitle: '传递远方信件的邮递员', subIcon: '✉️', subTitle: '绿色邮袋与邮票明信片' };
      }

      // 2. 水果美食与饮品
      const foodDict = {
        apple: { mainIcon: '🍎', mainTitle: '红彤彤清甜脆爽的大苹果', subIcon: '🌳', subTitle: '果园苹果树丰收采摘' },
        banana: { mainIcon: '🍌', mainTitle: '弯弯金色香甜软糯大香蕉', subIcon: '🌴', subTitle: '热带雨林挺拔香蕉树' },
        orange: { mainIcon: '🍊', mainTitle: '多汁富含维生素的鲜橙子', subIcon: '🧃', subTitle: '鲜榨清凉解渴橙汁' },
        pear: { mainIcon: '🍐', mainTitle: '汁水充足甜润可口的大雪梨', subIcon: '🧺', subTitle: '果篮装满刚摘下的雪梨' },
        grape: { mainIcon: '🍇', mainTitle: '晶莹剔透紫宝石般的葡萄', subIcon: '🍇', subTitle: '绿荫葡萄藤架果实累累' },
        watermelon: { mainIcon: '🍉', mainTitle: '甘甜解暑清凉的红瓤大西瓜', subIcon: '☀️', subTitle: '炎热夏日吃西瓜纳凉' },
        strawberry: { mainIcon: '🍓', mainTitle: '鲜艳诱人香气扑鼻的草莓', subIcon: '🍰', subTitle: '草莓奶油点缀可口蛋糕' },
        bread: { mainIcon: '🍞', mainTitle: '金黄松软刚出炉的烘烤面包', subIcon: '🥖', subTitle: '飘散香气的街角面包工坊' },
        milk: { mainIcon: '🥛', mainTitle: '香浓纯白新鲜健康的纯牛奶', subIcon: '🐄', subTitle: '青草悠悠的牧场奶牛' },
        egg: { mainIcon: '🥚', mainTitle: '营养丰富的农家新鲜鸡蛋', subIcon: '🍳', subTitle: '滋滋作响的营养煎荷包蛋' },
        rice: { mainIcon: '🍚', mainTitle: '热气腾腾喷香软糯的大白米饭', subIcon: '🌾', subTitle: '金灿灿沉甸甸的稻谷水稻' },
        cake: { mainIcon: '🍰', mainTitle: '美味缤纷的生日奶油水果蛋糕', subIcon: '🎂', subTitle: '点亮蜡烛许愿分享甜蜜' },
        meat: { mainIcon: '🥩', mainTitle: '鲜嫩多汁提供能量的优质瘦肉', subIcon: '🍖', subTitle: '营养均衡的大口吃肉' },
        chicken: { mainIcon: '🍗', mainTitle: '金黄酥脆香嫩可口的炸鸡腿', subIcon: '🐓', subTitle: '农庄晨鸣的芦花公鸡' },
        fish: { mainIcon: '🐟', mainTitle: '清蒸鲜美高蛋白的新鲜游鱼', subIcon: '🌊', subTitle: '碧波水面畅快游弋' },
        juice: { mainIcon: '🧃', mainTitle: '鲜果压榨酸甜可口的果汁', subIcon: '🥤', subTitle: '插上吸管随时畅饮' },
        water: { mainIcon: '💧', mainTitle: '生命之源甘甜清澈的纯净水', subIcon: '🚰', subTitle: '运动后补水活力满满' }
      };
      if (foodDict[w]) return foodDict[w];
      if (u.includes('美食') || u.includes('水果') || m.includes('吃') || m.includes('喝')) {
        return { mainIcon: '🍽️', mainTitle: `美味丰盛的${m}`, subIcon: '🧺', subTitle: '厨房烹饪与餐桌共享' };
      }

      // 3. 动物天地
      const animalDict = {
        cat: { mainIcon: '🐱', mainTitle: '轻盈灵巧爱撒娇的温柔小猫咪', subIcon: '🐟', subTitle: '心心念念的小鱼干零食' },
        dog: { mainIcon: '🐶', mainTitle: '忠诚活泼摇尾巴的看家小狗狗', subIcon: '🦴', subTitle: '草地上追逐飞盘与肉骨头' },
        bird: { mainIcon: '🐦', mainTitle: '展翅飞向蓝天清脆鸣唱的小鸟', subIcon: '🪺', subTitle: '绿树枝头温暖搭建的小鸟巢' },
        duck: { mainIcon: '🦆', mainTitle: '扁嘴巴黄脚掌在水面戏水的小鸭', subIcon: '🌊', subTitle: '春江水暖鸭先知欢快泛波' },
        panda: { mainIcon: '🐼', mainTitle: '圆滚滚吃竹子的国宝大熊猫', subIcon: '🎋', subTitle: '青翠欲滴脆爽的鲜竹叶' },
        rabbit: { mainIcon: '🐰', mainTitle: '蹦蹦跳跳长耳朵红眼睛小白兔', subIcon: '🥕', subTitle: '抱着大胡萝卜咔嚓啃食' },
        monkey: { mainIcon: '🐒', mainTitle: '机灵淘气在林间荡秋千的小猴', subIcon: '🍌', subTitle: '高高树梢剥开成熟香蕉' },
        elephant: { mainIcon: '🐘', mainTitle: '长长象鼻大如蒲扇耳朵的大象', subIcon: '🌴', subTitle: '热带稀树草原庞大守护者' },
        tiger: { mainIcon: '🐯', mainTitle: '额头带有王字花纹的森林猛虎', subIcon: '🌲', subTitle: '山林巡视威风凛凛百兽之王' },
        lion: { mainIcon: '🦁', mainTitle: '长着威武雄壮金色鬃毛的雄狮', subIcon: '👑', subTitle: '广阔非洲草原的霸气王者' },
        bear: { mainIcon: '🐻', mainTitle: '憨厚强壮在溪流捉鱼的棕熊', subIcon: '🍯', subTitle: '大树洞里寻找甜美蜂蜜' },
        pig: { mainIcon: '🐷', mainTitle: '圆鼻子乐呵呵吃饱睡觉的小猪', subIcon: '🌾', subTitle: '农家小院享受慵懒午后' }
      };
      if (animalDict[w]) return animalDict[w];
      if (u.includes('动物') || m.includes('动物')) {
        return { mainIcon: '🐾', mainTitle: `大自然奇妙生灵：${m}`, subIcon: '🌿', subTitle: '森林原野间自在栖息' };
      }

      // 4. 文具学习用品
      const stationeryDict = {
        pen: { mainIcon: '🖊️', mainTitle: '出水顺滑书写工整的签字钢笔', subIcon: '📄', subTitle: '洁白信纸上写下优秀作业' },
        pencil: { mainIcon: '✏️', mainTitle: '六角木质适合初学握笔的铅笔', subIcon: '📝', subTitle: '田字格练习本一笔一划' },
        ruler: { mainIcon: '📏', mainTitle: '刻度清晰透明直直的绘图直尺', subIcon: '📐', subTitle: '数学课规范画出几何线段' },
        eraser: { mainIcon: '🧹', mainTitle: '擦除字迹不留痕迹的柔软橡皮', subIcon: '✏️', subTitle: '知错就改擦去涂改痕迹' },
        book: { mainIcon: '📖', mainTitle: '开启智慧之门散发油墨的课本', subIcon: '🔖', subTitle: '精致书签标记今天学到哪' },
        bag: { mainIcon: '🎒', mainTitle: '装满课本与文具的双肩大书包', subIcon: '🏫', subTitle: '清晨早早背着书包去学校' },
        desk: { mainIcon: '🪑', mainTitle: '摆放整齐干干净净的学生课桌', subIcon: '💡', subTitle: '台灯陪伴下专注读书做题' }
      };
      if (stationeryDict[w]) return stationeryDict[w];
      if (u.includes('文具') || u.includes('学习') || u.includes('学校')) {
        return { mainIcon: '✏️', mainTitle: `学习必备好帮手：${m}`, subIcon: '📝', subTitle: '课堂认真做笔记天天向上' };
      }

      // 5. 家庭与人际关系
      if (w === 'father' || w === 'dad' || m.includes('爸爸') || m.includes('父亲')) {
        return { mainIcon: '👨', mainTitle: '宽厚有力遮风挡雨的好爸爸', subIcon: '🏡', subTitle: '温馨家庭幸福依靠' };
      }
      if (w === 'mother' || w === 'mum' || w === 'mom' || m.includes('妈妈') || m.includes('母亲')) {
        return { mainIcon: '👩', mainTitle: '温柔慈爱关怀备至的亲爱妈妈', subIcon: '❤️', subTitle: '浓浓母爱与香甜饭菜' };
      }
      if (w === 'brother' || m.includes('兄弟') || m.includes('哥哥') || m.includes('弟弟')) {
        return { mainIcon: '👦', mainTitle: '一起踢球玩耍的手足兄弟', subIcon: '⚽', subTitle: '阳光下互相追逐成长' };
      }
      if (w === 'sister' || m.includes('姐妹') || m.includes('姐姐') || m.includes('妹妹')) {
        return { mainIcon: '👧', mainTitle: '贴心分享小秘密的手足姐妹', subIcon: '🎀', subTitle: '扎着可爱蝴蝶结辫子' };
      }
      if (w === 'grandpa' || w === 'grandfather' || m.includes('爷爷') || m.includes('外公')) {
        return { mainIcon: '👴', mainTitle: '白发和蔼讲故事的亲切爷爷', subIcon: '🍵', subTitle: '藤椅喝茶陪伴孙辈' };
      }
      if (w === 'grandma' || w === 'grandmother' || m.includes('奶奶') || m.includes('外婆')) {
        return { mainIcon: '👵', mainTitle: '笑容慈祥织毛衣的亲切奶奶', subIcon: '🧶', subTitle: '温暖怀抱与关切叮嘱' };
      }

      // 6. 自然天气与地理
      if (w === 'sun' || m.includes('太阳')) {
        return { mainIcon: '☀️', mainTitle: '金色灿烂普照大地的温暖太阳', subIcon: '🌻', subTitle: '向日葵迎着晨曦盛开' };
      }
      if (w === 'moon' || m.includes('月亮')) {
        return { mainIcon: '🌙', mainTitle: '夜空如钩皎洁宁静的银色月亮', subIcon: '⭐', subTitle: '满天繁星闪烁点缀夜空' };
      }
      if (w === 'rain' || m.includes('雨')) {
        return { mainIcon: '🌧️', mainTitle: '淅淅沥沥滋润大地的清新雨水', subIcon: '☂️', subTitle: '撑起彩色雨伞水坑踩水' };
      }
      if (w === 'snow' || m.includes('雪')) {
        return { mainIcon: '❄️', mainTitle: '漫天飞舞银装素裹的洁白雪花', subIcon: '⛄', subTitle: '戴着红围巾堆起胖雪人' };
      }
      if (w === 'wind' || m.includes('风')) {
        return { mainIcon: '💨', mainTitle: '穿过树梢吹拂脸颊的轻柔微风', subIcon: '🪁', subTitle: '旷野中随风高高飞舞的风筝' };
      }

      // 7. 颜色色彩
      if (u.includes('颜色') || ['red','blue','green','yellow','black','white','orange','purple','pink','brown'].includes(w)) {
        return { mainIcon: '🎨', mainTitle: `鲜艳纯正的色彩：${m}`, subIcon: '🖌️', subTitle: '调色盘上画出五彩斑斓世界' };
      }

      // 默认兜底
      return { mainIcon: '🌟', mainTitle: `形象生动的实物认知：${m}`, subIcon: '💡', subTitle: '情境联想加深长效记忆' };
    }


    // 获取场景说明文案
    getWordSceneCaption(wordObj) {
      if (!wordObj) return '💡 情境联想 · 加深词汇长效记忆';
      const w = (wordObj.word || '').toLowerCase();
      const m = wordObj.meaning || wordObj.chinese || '';
      const u = wordObj.unit || '';

      if (w.includes('review') || w.includes('study') || w.includes('read') || w.includes('write') || 
          w.includes('learn') || w.includes('homework') || m.includes('复习') || m.includes('温习') || m.includes('学') || m.includes('写') || m.includes('读')) {
        return '✏️ 专注学习 · 小学生在书桌前认真复习写字';
      }
      if (w.includes('driver') || w.includes('car') || w.includes('bus') || w.includes('drive') || m.includes('车') || m.includes('司机') || m.includes('驾')) {
        return '🚌 城市出行 · 公交车司机正在平稳驾驶校车';
      }
      if (w.includes('doctor') || w.includes('nurse') || w.includes('hospital') || m.includes('医') || m.includes('病')) {
        return '🩺 仁心医者 · 医生在门诊诊所细心看病检查';
      }
      if (u.includes('水果') || u.includes('食物') || w.includes('apple') || w.includes('fruit') || m.includes('果') || m.includes('吃')) {
        return '🍎 果园丰收 · 篮子里装满新鲜甜美的水果';
      }
      if (u.includes('动物') || w.includes('cat') || w.includes('dog') || w.includes('animal') || m.includes('猫') || m.includes('狗')) {
        return '🐱 萌趣自然 · 活泼可爱的小动物在阳光草地玩耍';
      }
      if (u.includes('文具') || u.includes('学校') || w.includes('pencil') || w.includes('book') || m.includes('笔') || m.includes('书')) {
        return '🎒 快乐校园 · 上课学习文具书包准备齐全';
      }
      return `🌟 情境记忆 · ${m} (图文并茂长效掌握)`;
    }

    // 纯矢量情境插画生成引擎 (纯图无文字，精准匹配词义)
    generateWordSceneSvg(wordObj) {
      if (!wordObj) return '';
      const w = (wordObj.word || '').toLowerCase();
      const m = wordObj.meaning || wordObj.chinese || '';
      const u = wordObj.unit || '';

      // 1. 颜色大类 (绚丽色彩: green, red, blue, yellow, orange, pink, purple, black, white, brown)
      if (w === 'green' || m.includes('绿')) {
        return `<svg viewBox="0 0 340 130" width="100%" height="130" xmlns="http://www.w3.org/2000/svg" style="border-radius: 12px; display: block;">
          <defs>
            <linearGradient id="g_grn" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#f0fdf4"/><stop offset="100%" stop-color="#dcfce7"/></linearGradient>
            <linearGradient id="g_leaf" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#4ade80"/><stop offset="100%" stop-color="#15803d"/></linearGradient>
          </defs>
          <rect width="340" height="130" fill="url(#g_grn)"/>
          <path d="M0,105 Q90,75 180,100 T340,95 L340,130 L0,130 Z" fill="#86efac" opacity="0.6"/>
          <path d="M0,115 Q100,90 200,112 T340,110 L340,130 L0,130 Z" fill="#22c55e"/>
          <rect x="72" y="70" width="16" height="50" rx="3" fill="#78350f"/>
          <circle cx="80" cy="52" r="32" fill="#16a34a"/>
          <circle cx="62" cy="46" r="22" fill="#22c55e"/>
          <circle cx="98" cy="46" r="24" fill="#15803d"/>
          <path d="M190,95 C175,55 215,20 260,25 C265,70 230,105 190,95 Z" fill="url(#g_leaf)" stroke="#166534" stroke-width="2"/>
          <path d="M190,95 Q220,60 260,25" fill="none" stroke="#bbf7d0" stroke-width="2.5" stroke-linecap="round"/>
          <path d="M210,75 Q218,65 230,68" fill="none" stroke="#bbf7d0" stroke-width="1.5" stroke-linecap="round"/>
          <path d="M225,58 Q235,50 245,52" fill="none" stroke="#bbf7d0" stroke-width="1.5" stroke-linecap="round"/>
          <ellipse cx="232" cy="42" rx="4.5" ry="3.5" fill="#ffffff" opacity="0.85"/>
          <path d="M125,120 L130,105 L135,120" stroke="#15803d" stroke-width="2.5" stroke-linecap="round" fill="none"/>
          <path d="M140,122 L146,108 L152,122" stroke="#15803d" stroke-width="2.5" stroke-linecap="round" fill="none"/>
          <path d="M290,120 L295,107 L300,120" stroke="#15803d" stroke-width="2.5" stroke-linecap="round" fill="none"/>
          <circle cx="160" cy="45" r="16" fill="#22c55e" stroke="#15803d" stroke-width="2"/>
          <circle cx="155" cy="40" r="4" fill="#ffffff" opacity="0.6"/>
        </svg>`;
      }

      if (w === 'red' || m.includes('红')) {
        return `<svg viewBox="0 0 340 130" width="100%" height="130" xmlns="http://www.w3.org/2000/svg" style="border-radius: 12px; display: block;">
          <defs><linearGradient id="g_red" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fef2f2"/><stop offset="100%" stop-color="#fee2e2"/></linearGradient></defs>
          <rect width="340" height="130" fill="url(#g_red)"/>
          <path d="M85,55 C85,25 125,25 125,55 C125,75 105,82 105,85 L101,85 C101,82 85,75 85,55 Z" fill="#ef4444" stroke="#b91c1c" stroke-width="2"/>
          <ellipse cx="98" cy="42" rx="4" ry="8" fill="#ffffff" opacity="0.5" transform="rotate(-25 98 42)"/>
          <path d="M103,85 Q115,105 105,125" fill="none" stroke="#ef4444" stroke-width="1.5"/>
          <path d="M190,68 C170,40 220,28 230,48 C240,28 290,40 270,68 C250,96 210,96 190,68 Z" fill="#dc2626" stroke="#991b1b" stroke-width="2"/>
          <ellipse cx="210" cy="52" rx="4" ry="7" fill="#ffffff" opacity="0.5" transform="rotate(-30 210 52)"/>
          <path d="M230,46 Q235,30 245,28" fill="none" stroke="#78350f" stroke-width="3" stroke-linecap="round"/>
          <path d="M235,32 Q255,26 250,38 Z" fill="#22c55e"/>
          <path d="M150,85 C140,75 165,65 170,75 C175,65 200,75 190,85 C180,105 160,105 150,85 Z" fill="#ef4444"/>
          <circle cx="160" cy="85" r="1.5" fill="#fef08a"/><circle cx="172" cy="83" r="1.5" fill="#fef08a"/><circle cx="168" cy="92" r="1.5" fill="#fef08a"/>
        </svg>`;
      }

      if (w === 'blue' || m.includes('蓝')) {
        return `<svg viewBox="0 0 340 130" width="100%" height="130" xmlns="http://www.w3.org/2000/svg" style="border-radius: 12px; display: block;">
          <defs><linearGradient id="g_blu" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#f0f9ff"/><stop offset="100%" stop-color="#bae6fd"/></linearGradient></defs>
          <rect width="340" height="130" fill="url(#g_blu)"/>
          <path d="M0,85 Q60,70 120,85 T240,85 T340,85 L340,130 L0,130 Z" fill="#38bdf8" opacity="0.6"/>
          <path d="M0,98 Q70,85 140,98 T280,98 T340,98 L340,130 L0,130 Z" fill="#0284c7"/>
          <path d="M120,70 C140,35 190,40 210,65 C180,68 150,85 120,70 Z" fill="#0369a1"/>
          <path d="M165,42 L172,28 L178,44 Z" fill="#0369a1"/>
          <path d="M125,70 L110,60 L115,75 Z" fill="#0369a1"/>
          <circle cx="60" cy="35" r="14" fill="#ffffff" opacity="0.9"/>
          <circle cx="75" cy="30" r="18" fill="#ffffff" opacity="0.9"/>
          <circle cx="92" cy="35" r="14" fill="#ffffff" opacity="0.9"/>
          <circle cx="260" cy="32" r="14" fill="#ffffff" opacity="0.9"/>
          <circle cx="275" cy="28" r="18" fill="#ffffff" opacity="0.9"/>
          <circle cx="290" cy="32" r="14" fill="#ffffff" opacity="0.9"/>
        </svg>`;
      }

      if (w === 'yellow' || m.includes('黄')) {
        return `<svg viewBox="0 0 340 130" width="100%" height="130" xmlns="http://www.w3.org/2000/svg" style="border-radius: 12px; display: block;">
          <defs><linearGradient id="g_yel" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fefce8"/><stop offset="100%" stop-color="#fef08a"/></linearGradient></defs>
          <rect width="340" height="130" fill="url(#g_yel)"/>
          <circle cx="70" cy="45" r="24" fill="#f59e0b"/>
          <circle cx="70" cy="45" r="20" fill="#facc15"/>
          <line x1="70" y1="12" x2="70" y2="20" stroke="#f59e0b" stroke-width="3" stroke-linecap="round"/>
          <line x1="70" y1="70" x2="70" y2="78" stroke="#f59e0b" stroke-width="3" stroke-linecap="round"/>
          <line x1="37" y1="45" x2="45" y2="45" stroke="#f59e0b" stroke-width="3" stroke-linecap="round"/>
          <line x1="95" y1="45" x2="103" y2="45" stroke="#f59e0b" stroke-width="3" stroke-linecap="round"/>
          <circle cx="240" cy="65" r="18" fill="#78350f"/>
          <ellipse cx="240" cy="38" rx="7" ry="12" fill="#facc15" stroke="#eab308" stroke-width="1.5"/>
          <ellipse cx="240" cy="92" rx="7" ry="12" fill="#facc15" stroke="#eab308" stroke-width="1.5"/>
          <ellipse cx="213" cy="65" rx="12" ry="7" fill="#facc15" stroke="#eab308" stroke-width="1.5"/>
          <ellipse cx="267" cy="65" rx="12" ry="7" fill="#facc15" stroke="#eab308" stroke-width="1.5"/>
          <circle cx="240" cy="65" r="16" fill="#854d0e"/>
          <path d="M240,92 Q242,120 238,130" fill="none" stroke="#16a34a" stroke-width="4"/>
        </svg>`;
      }

      if (u.includes('色彩') || w.includes('color') || w.includes('colour') || w.includes('purple') || w.includes('pink') || w.includes('orange') || w.includes('black') || w.includes('white')) {
        return `<svg viewBox="0 0 340 130" width="100%" height="130" xmlns="http://www.w3.org/2000/svg" style="border-radius: 12px; display: block;">
          <defs><linearGradient id="g_art" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#faf5ff"/><stop offset="100%" stop-color="#f3e8ff"/></linearGradient></defs>
          <rect width="340" height="130" fill="url(#g_art)"/>
          <path d="M70,80 C50,30 160,20 200,55 C220,70 205,105 160,110 C130,113 85,115 70,80 Z" fill="#fde68a" stroke="#d97706" stroke-width="2.5"/>
          <circle cx="165" cy="88" r="10" fill="#f3e8ff" stroke="#d97706" stroke-width="2"/>
          <circle cx="95" cy="55" r="9" fill="#ef4444"/>
          <circle cx="125" cy="45" r="9" fill="#3b82f6"/>
          <circle cx="155" cy="48" r="9" fill="#22c55e"/>
          <circle cx="180" cy="65" r="9" fill="#a855f7"/>
          <circle cx="120" cy="85" r="9" fill="#f97316"/>
          <path d="M225,35 L285,95 L275,103 L217,45 Z" fill="#b45309"/>
          <path d="M217,45 L205,32 L220,25 L225,35 Z" fill="#64748b"/>
          <path d="M205,32 L195,20 L212,20 Z" fill="#ef4444"/>
        </svg>`;
      }

      // 2. 学习复习与读写做作业场景 (review, study, read, write, learn, homework, test, exam) - 纯图形，无文字
      if (w.includes('review') || w.includes('study') || w.includes('read') || w.includes('write') || 
          w.includes('learn') || w.includes('homework') || w.includes('lesson') || w.includes('class') || 
          m.includes('复习') || m.includes('温习') || m.includes('学') || m.includes('写') || m.includes('读') || m.includes('作业')) {
        return `<svg viewBox="0 0 340 130" width="100%" height="130" xmlns="http://www.w3.org/2000/svg" style="border-radius: 12px; display: block;">
          <defs>
            <linearGradient id="g_study" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#eff6ff"/><stop offset="100%" stop-color="#dbeafe"/></linearGradient>
            <linearGradient id="g_desk" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fef3c7"/><stop offset="100%" stop-color="#fde68a"/></linearGradient>
          </defs>
          <rect width="340" height="130" fill="url(#g_study)"/>
          <circle cx="295" cy="30" r="15" fill="#ffffff" stroke="#94a3b8" stroke-width="2"/>
          <line x1="295" y1="30" x2="295" y2="20" stroke="#475569" stroke-width="2" stroke-linecap="round"/>
          <line x1="295" y1="30" x2="303" y2="30" stroke="#ef4444" stroke-width="1.5" stroke-linecap="round"/>
          <circle cx="295" cy="30" r="2" fill="#ef4444"/>
          <rect x="20" y="80" width="300" height="50" rx="6" fill="url(#g_desk)" stroke="#f59e0b" stroke-width="1.5"/>
          <path d="M48,80 L56,42 L76,46" fill="none" stroke="#64748b" stroke-width="3.5" stroke-linecap="round"/>
          <path d="M68,39 L92,47 L84,60 Z" fill="#f59e0b"/>
          <polygon points="82,60 155,105 50,105" fill="#fef08a" opacity="0.45"/>
          <path d="M120,86 C135,82 150,84 155,88 C160,84 175,82 190,86 L190,103 C175,99 160,101 155,105 C150,101 135,99 120,103 Z" fill="#ffffff" stroke="#94a3b8" stroke-width="1.5"/>
          <line x1="126" y1="91" x2="148" y2="89" stroke="#cbd5e1" stroke-width="1.2"/>
          <line x1="126" y1="96" x2="148" y2="94" stroke="#cbd5e1" stroke-width="1.2"/>
          <line x1="162" y1="89" x2="184" y2="91" stroke="#cbd5e1" stroke-width="1.2"/>
          <line x1="162" y1="94" x2="184" y2="96" stroke="#cbd5e1" stroke-width="1.2"/>
          <rect x="96" y="70" width="16" height="22" rx="3" fill="#60a5fa"/>
          <line x1="99" y1="62" x2="103" y2="72" stroke="#ef4444" stroke-width="2.5" stroke-linecap="round"/>
          <line x1="107" y1="58" x2="105" y2="72" stroke="#10b981" stroke-width="2" stroke-linecap="round"/>
          <path d="M215,115 C215,88 255,88 255,115 Z" fill="#3b82f6"/>
          <circle cx="235" cy="65" r="16" fill="#fed7aa"/>
          <path d="M219,63 C219,45 251,45 251,63 C245,58 226,58 219,63 Z" fill="#334155"/>
          <ellipse cx="229" cy="67" rx="2" ry="2.5" fill="#1e293b"/>
          <ellipse cx="239" cy="67" rx="2" ry="2.5" fill="#1e293b"/>
          <path d="M231,75 Q234,77 237,75" fill="none" stroke="#ea580c" stroke-width="1.5" stroke-linecap="round"/>
          <path d="M222,95 Q195,90 178,92" fill="none" stroke="#fed7aa" stroke-width="6" stroke-linecap="round"/>
          <line x1="178" y1="92" x2="171" y2="87" stroke="#ef4444" stroke-width="3" stroke-linecap="round"/>
        </svg>`;
      }

      // 3. 交通驾驶与司机车辆 (driver, car, bus, taxi, bike, drive, ride, truck) - 纯图形，无文字
      if (w.includes('driver') || w.includes('car') || w.includes('bus') || w.includes('taxi') || 
          w.includes('drive') || w.includes('ride') || w.includes('truck') || m.includes('车') || m.includes('司机') || m.includes('驾驶') || m.includes('开')) {
        return `<svg viewBox="0 0 340 130" width="100%" height="130" xmlns="http://www.w3.org/2000/svg" style="border-radius: 12px; display: block;">
          <defs><linearGradient id="g_road" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#e0f2fe"/><stop offset="100%" stop-color="#bae6fd"/></linearGradient></defs>
          <rect width="340" height="130" fill="url(#g_road)"/>
          <rect x="0" y="90" width="340" height="40" fill="#475569"/>
          <line x1="20" y1="110" x2="70" y2="110" stroke="#f1f5f9" stroke-width="3" stroke-dasharray="12,12"/>
          <line x1="120" y1="110" x2="170" y2="110" stroke="#f1f5f9" stroke-width="3" stroke-dasharray="12,12"/>
          <line x1="220" y1="110" x2="270" y2="110" stroke="#f1f5f9" stroke-width="3" stroke-dasharray="12,12"/>
          <rect x="290" y="25" width="16" height="38" rx="4" fill="#1e293b"/>
          <line x1="298" y1="63" x2="298" y2="90" stroke="#64748b" stroke-width="3"/>
          <circle cx="298" cy="33" r="4" fill="#ef4444"/>
          <circle cx="298" cy="44" r="4" fill="#eab308"/>
          <circle cx="298" cy="55" r="4" fill="#10b981"/>
          <rect x="45" y="38" width="195" height="58" rx="10" fill="#f59e0b" stroke="#b45309" stroke-width="2"/>
          <rect x="55" y="44" width="40" height="25" rx="4" fill="#e0f2fe" stroke="#0284c7" stroke-width="1.5"/>
          <rect x="105" y="44" width="40" height="25" rx="4" fill="#e0f2fe" stroke="#0284c7" stroke-width="1.5"/>
          <rect x="155" y="44" width="40" height="25" rx="4" fill="#e0f2fe" stroke="#0284c7" stroke-width="1.5"/>
          <circle cx="75" cy="54" r="8" fill="#fed7aa"/>
          <path d="M68,50 C68,44 82,44 82,50 Z" fill="#0284c7"/>
          <circle cx="85" cy="62" r="7" fill="none" stroke="#1e293b" stroke-width="2"/>
          <circle cx="85" cy="96" r="14" fill="#1e293b"/>
          <circle cx="85" cy="96" r="6" fill="#cbd5e1"/>
          <circle cx="185" cy="96" r="14" fill="#1e293b"/>
          <circle cx="185" cy="96" r="6" fill="#cbd5e1"/>
          <rect x="235" y="65" width="6" height="12" rx="2" fill="#fef08a"/>
        </svg>`;
      }

      // 4. 水果与自然食物 (apple, banana, fruit, tree, flower, food, orange, pear) - 纯图形，无文字
      if (u.includes('水果') || u.includes('食物') || w.includes('apple') || w.includes('banana') || 
          w.includes('fruit') || w.includes('tree') || w.includes('flower') || m.includes('果') || m.includes('吃') || m.includes('树') || m.includes('花')) {
        return `<svg viewBox="0 0 340 130" width="100%" height="130" xmlns="http://www.w3.org/2000/svg" style="border-radius: 12px; display: block;">
          <defs><linearGradient id="g_orchard" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#ecfdf5"/><stop offset="100%" stop-color="#a7f3d0"/></linearGradient></defs>
          <rect width="340" height="130" fill="url(#g_orchard)"/>
          <circle cx="80" cy="55" r="38" fill="#22c55e" opacity="0.85"/>
          <circle cx="110" cy="45" r="32" fill="#16a34a" opacity="0.85"/>
          <rect x="85" y="80" width="20" height="50" fill="#78350f" rx="3"/>
          <circle cx="75" cy="50" r="9" fill="#ef4444"/><circle cx="105" cy="42" r="8" fill="#ef4444"/>
          <path d="M175,85 L265,85 L255,122 L185,122 Z" fill="#d97706" stroke="#92400e" stroke-width="2"/>
          <path d="M180,85 Q220,50 260,85" fill="none" stroke="#92400e" stroke-width="3"/>
          <circle cx="200" cy="80" r="14" fill="#ef4444"/>
          <circle cx="235" cy="82" r="13" fill="#f59e0b"/>
          <circle cx="218" cy="74" r="12" fill="#84cc16"/>
        </svg>`;
      }

      // 5. 动物天地 (cat, dog, bird, duck, panda, rabbit, animal, tiger, lion) - 纯图形，无文字
      if (u.includes('动物') || w.includes('cat') || w.includes('dog') || w.includes('bird') || 
          w.includes('duck') || w.includes('panda') || w.includes('animal') || m.includes('猫') || m.includes('狗') || m.includes('鸟') || m.includes('兽')) {
        return `<svg viewBox="0 0 340 130" width="100%" height="130" xmlns="http://www.w3.org/2000/svg" style="border-radius: 12px; display: block;">
          <defs><linearGradient id="g_nature" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fefce8"/><stop offset="100%" stop-color="#fef08a"/></linearGradient></defs>
          <rect width="340" height="130" fill="url(#g_nature)"/>
          <path d="M0,110 Q80,85 170,110 T340,110 L340,130 L0,130 Z" fill="#86efac"/>
          <circle cx="150" cy="75" r="26" fill="#fb923c"/>
          <polygon points="132,56 128,36 142,48" fill="#ea580c"/>
          <polygon points="168,56 172,36 158,48" fill="#ea580c"/>
          <circle cx="140" cy="72" r="3" fill="#1e293b"/><circle cx="160" cy="72" r="3" fill="#1e293b"/>
          <polygon points="147,80 153,80 150,83" fill="#ea580c"/>
          <line x1="135" y1="80" x2="115" y2="78" stroke="#7c2d12" stroke-width="1.5"/>
          <line x1="165" y1="80" x2="185" y2="78" stroke="#7c2d12" stroke-width="1.5"/>
          <path d="M150,101 C120,101 110,125 110,125 L190,125 C190,125 180,101 150,101 Z" fill="#f97316"/>
        </svg>`;
      }

      // 6. 文具与课堂 (pencil, pen, ruler, eraser, book, desk, bag, school) - 纯图形，无文字
      if (u.includes('文具') || u.includes('学校') || w.includes('pencil') || w.includes('ruler') || 
          w.includes('eraser') || w.includes('book') || w.includes('school') || m.includes('铅笔') || m.includes('尺') || m.includes('书') || m.includes('校')) {
        return `<svg viewBox="0 0 340 130" width="100%" height="130" xmlns="http://www.w3.org/2000/svg" style="border-radius: 12px; display: block;">
          <defs><linearGradient id="g_sch" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fdf4ff"/><stop offset="100%" stop-color="#fae8ff"/></linearGradient></defs>
          <rect width="340" height="130" fill="url(#g_sch)"/>
          <rect x="30" y="25" width="140" height="65" rx="6" fill="#065f46" stroke="#047857" stroke-width="2"/>
          <line x1="45" y1="45" x2="155" y2="45" stroke="#34d399" stroke-width="2"/>
          <line x1="45" y1="60" x2="135" y2="60" stroke="#34d399" stroke-width="2"/>
          <rect x="200" y="45" width="85" height="65" rx="14" fill="#a855f7" stroke="#7e22ce" stroke-width="2"/>
          <rect x="215" y="65" width="55" height="30" rx="6" fill="#c084fc"/>
          <line x1="242" y1="45" x2="242" y2="28" stroke="#7e22ce" stroke-width="4" stroke-linecap="round"/>
          <line x1="160" y1="110" x2="195" y2="85" stroke="#ef4444" stroke-width="5" stroke-linecap="round"/>
          <polygon points="156,113 162,110 160,116" fill="#1e293b"/>
        </svg>`;
      }

      // 7. 天气与自然奇观 (sun, rain, snow, wind, cloud, rainbow) - 纯图形，无文字
      if (u.includes('自然') || u.includes('时节') || w.includes('sun') || w.includes('rain') || w.includes('cloud') || w.includes('rainbow')) {
        return `<svg viewBox="0 0 340 130" width="100%" height="130" xmlns="http://www.w3.org/2000/svg" style="border-radius: 12px; display: block;">
          <defs><linearGradient id="g_sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#e0f2fe"/><stop offset="100%" stop-color="#bae6fd"/></linearGradient></defs>
          <rect width="340" height="130" fill="url(#g_sky)"/>
          <circle cx="170" cy="130" r="100" fill="none" stroke="#ef4444" stroke-width="5" opacity="0.8"/>
          <circle cx="170" cy="130" r="95" fill="none" stroke="#f97316" stroke-width="5" opacity="0.8"/>
          <circle cx="170" cy="130" r="90" fill="none" stroke="#eab308" stroke-width="5" opacity="0.8"/>
          <circle cx="170" cy="130" r="85" fill="none" stroke="#22c55e" stroke-width="5" opacity="0.8"/>
          <circle cx="170" cy="130" r="80" fill="none" stroke="#3b82f6" stroke-width="5" opacity="0.8"/>
          <circle cx="170" cy="130" r="75" fill="none" stroke="#a855f7" stroke-width="5" opacity="0.8"/>
          <circle cx="65" cy="45" r="22" fill="#fbbf24"/>
          <circle cx="120" cy="75" r="22" fill="#ffffff"/>
          <circle cx="145" cy="65" r="26" fill="#ffffff"/>
          <circle cx="175" cy="75" r="22" fill="#ffffff"/>
        </svg>`;
      }

      // 8. 默认通用生动徽章兜底 (纯图形，无文字)
      return `<svg viewBox="0 0 340 130" width="100%" height="130" xmlns="http://www.w3.org/2000/svg" style="border-radius: 12px; display: block;">
        <defs>
          <linearGradient id="g_pure" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#f8fafc"/><stop offset="100%" stop-color="#e0f2fe"/></linearGradient>
        </defs>
        <rect width="340" height="130" fill="url(#g_pure)"/>
        <circle cx="170" cy="65" r="42" fill="#ffffff" stroke="#38bdf8" stroke-width="3"/>
        <polygon points="170,36 177,53 195,54 181,66 186,84 170,73 154,84 159,66 145,54 163,53" fill="#facc15" stroke="#eab308" stroke-width="1.5"/>
        <circle cx="110" cy="50" r="10" fill="#67e8f9" opacity="0.6"/>
        <circle cx="230" cy="80" r="12" fill="#818cf8" opacity="0.6"/>
        <circle cx="220" cy="45" r="8" fill="#f472b6" opacity="0.6"/>
      </svg>`;
    }

    // ---------------- 环节 1: 【读写学词】双栏协同 (左侧双图视听学词 + 右侧独立打字键盘) ----------------
    renderStage1ReadAndWrite(autoSpeak = false) {
      if (!this.currentWord) return;
      this.readStreak = 0;
      this.stage1Input = '';
      this.stage1TypingSuccess = false;
      this.updateReadingStars();

      // 1. 渲染具象情境矢量插画展示架 (纯图形，无文字)
      const svgContainer = document.getElementById('phonicsSceneSvgContainer');
      if (svgContainer) {
        svgContainer.innerHTML = this.generateWordSceneSvg(this.currentWord);
      }
// 2. 年级标签与词汇释义
      const gradeTag = document.getElementById('phonicsGradeTag');
      if (gradeTag) gradeTag.textContent = `${this.currentWord.grade || 1} 年级`;

      const wordDisplay = document.getElementById('phonicsWordDisplay');
      if (wordDisplay) wordDisplay.textContent = this.currentWord.word;

      const phoneticDisplay = document.getElementById('phonicsPhoneticDisplay');
      if (phoneticDisplay) phoneticDisplay.textContent = this.currentWord.phonetic || '';

      const meaningEl = document.getElementById('phonicsMeaning');
      if (meaningEl) {
        meaningEl.textContent = this.currentWord.meaning || this.currentWord.chinese || '';
        meaningEl.classList.remove('phonics-word-success');
      }

      const exampleEl = document.getElementById('phonicsExample');
      if (exampleEl) exampleEl.textContent = this.currentWord.example || '';

      const recBox = document.getElementById('recordingFeedbackBox');
      if (recBox) recBox.style.display = 'none';
      const myAudioBtn = document.getElementById('btnPlayMyRecording');
      if (myAudioBtn) myAudioBtn.style.display = 'none';

      // 3. 自然拼读音节拆解切块
      const syllablesBox = document.getElementById('syllablesContainer');
      if (syllablesBox) {
        syllablesBox.innerHTML = '';
        const syllables = this.currentWord.syllables || [this.currentWord.word];
        syllables.forEach(s => {
          const chip = document.createElement('div');
          chip.className = 'syllable-chip';
          chip.textContent = s;
          chip.title = '点击朗读音节';
          chip.onclick = () => {
            this.sound.speak(s, 0.75);
          };
          syllablesBox.appendChild(chip);
        });
      }

      // 4. 重置打字视窗与插槽
      const win = document.getElementById('phonicsTypeWindow');
      if (win) { win.classList.remove('correct'); win.classList.remove('wrong'); }
      const nextBtn = document.getElementById('btnPhonicsNextWord');
      if (nextBtn) nextBtn.style.display = 'none';

      this.renderStage1Slots();

      // 仅在明确指定时才自动朗读，严防初次进入画面未触发自动发音
      if (autoSpeak) {
        this.sound.speak(this.currentWord.word);
      }
    }

    renderStage1Slots() {
      const slotsContainer = document.getElementById('phonicsTypeSlots');
      if (!slotsContainer || !this.currentWord) return;
      slotsContainer.innerHTML = '';
      const len = this.currentWord.word.length;
      for (let i = 0; i < len; i++) {
        const slot = document.createElement('div');
        slot.className = 'stage1-underline-slot' + (i === 0 ? ' current' : '');
        slot.id = `p_slot_${i}`;
        slot.textContent = ''; // 默认为空，通过底边下划线呈现
        slotsContainer.appendChild(slot);
      }
    }

    handleStage1Typing(key) {
      if (!this.currentWord || this.stage1TypingSuccess) return;
      const targetWord = this.currentWord.word.toLowerCase();
      const win = document.getElementById('phonicsTypeWindow');

      // 屏幕虚拟键盘按键按下微反馈
      const pressedKey = document.querySelector(`.stage1-onscreen-keyboard .kb-key[data-key="${key}"]`);
      if (pressedKey) {
        pressedKey.classList.add('active-press');
        setTimeout(() => pressedKey.classList.remove('active-press'), 150);
      }

      if (key === 'BACKSPACE') {
        if (this.stage1Input.length > 0) {
          this.stage1Input = this.stage1Input.slice(0, -1);
          this.updateStage1SlotsDisplay();
          if (win) { win.classList.remove('wrong'); win.classList.remove('correct'); }
        }
        return;
      }

      if (key === 'CLEAR') {
        this.stage1Input = '';
        this.updateStage1SlotsDisplay();
        if (win) { win.classList.remove('wrong'); win.classList.remove('correct'); }
        return;
      }

      if (/^[a-zA-Z]$/.test(key)) {
        if (this.stage1Input.length < targetWord.length) {
          this.stage1Input += key.toLowerCase();
          this.updateStage1SlotsDisplay();

          if (this.stage1Input.length === targetWord.length) {
            if (this.stage1Input === targetWord) {
              this.stage1TypingSuccess = true;
              this.sound.playTone('correct');
              this.handleCombo(true);
              this.storage.state.todayProgress.step1 = true;
              this.storage.state.todayProgress.step1Count = (this.storage.state.todayProgress.step1Count || 0) + 1;
              this.storage.save();
              this.renderParentDailyReport();

              if (win) { win.classList.add('correct'); win.classList.remove('wrong'); }

              for (let i = 0; i < targetWord.length; i++) {
                const s = document.getElementById(`p_slot_${i}`);
                if (s) {
                  s.classList.add('correct');
                  s.classList.remove('current');
                }
              }

              const nextBtn = document.getElementById('btnPhonicsNextWord');
              if (nextBtn) nextBtn.style.display = 'inline-block';

              // 检查听读 3 遍与打字是否同时达成
              if (this.readStreak >= 3) {
                setTimeout(() => {
                  this.handleStage1NextWord();
                }, 750);
              }
            } else {
              this.sound.playTone('wrong');
              this.handleCombo(false);
              if (win) { win.classList.add('wrong'); win.classList.remove('correct'); }
              const slots = document.getElementById('phonicsTypeSlots');
              if (slots) {
                slots.style.animation = 'shake 0.3s ease';
                setTimeout(() => { slots.style.animation = ''; }, 300);
              }
            }
          }
        }
      }
    }

    updateStage1SlotsDisplay() {
      if (!this.currentWord) return;
      const originalWord = this.currentWord.word;
      const targetLen = originalWord.length;
      const curInputLen = this.stage1Input.length;
      for (let i = 0; i < targetLen; i++) {
        const slot = document.getElementById(`p_slot_${i}`);
        if (slot) {
          let char = '';
          if (this.stage1Input[i]) {
            // 按照目标词在该位置的真实大小写呈现：该大写大写、该小写小写！
            const targetChar = originalWord[i] || '';
            char = targetChar === targetChar.toUpperCase() && targetChar !== targetChar.toLowerCase()
              ? this.stage1Input[i].toUpperCase()
              : this.stage1Input[i].toLowerCase();
          }
          slot.textContent = char;
          slot.classList.toggle('filled', !!char);
          slot.classList.toggle('current', i === curInputLen && !this.stage1TypingSuccess);
          slot.classList.remove('correct');
        }
      }
    }

    handleStage1NextWord() {
      this.pickRandomWord();
      this.renderStage1ReadAndWrite();
    }

    // 处理朗读 3 遍打卡逻辑
    handleReadProgress() {
      this.readStreak += 1;
      this.updateReadingStars();

      if (this.readStreak >= 3) {
        const meaningEl = document.getElementById('phonicsMeaning');
        if (meaningEl) meaningEl.classList.add('phonics-word-success');
        this.sound.playTone('correct');

        this.storage.state.todayProgress.step1 = true;
        this.storage.state.todayProgress.step1Count = (this.storage.state.todayProgress.step1Count || 0) + 1;
        this.storage.save();
        this.renderParentDailyReport();

        if (this.stage1TypingSuccess) {
          setTimeout(() => {
            this.pickRandomWord();
            this.renderStage1ReadAndWrite();
          }, 800);
        }
      }
    }

    updateReadingStars() {
      for (let i = 1; i <= 3; i++) {
        const star = document.getElementById(`readStar${i}`);
        if (star) {
          star.classList.toggle('lit', i <= this.readStreak);
          star.textContent = i <= this.readStreak ? '⭐' : i;
        }
      }
      const recordBtn = document.getElementById('btnPhonicsRecord');
      if (recordBtn) {
        if (this.readStreak >= 3) {
          recordBtn.textContent = '✅ 大声朗读已达标 (3/3)';
          recordBtn.disabled = true;
          recordBtn.style.opacity = '0.85';
        } else {
          recordBtn.disabled = false;
          recordBtn.style.opacity = '1';
          recordBtn.textContent = `🎙️ 开启大声朗读 (第 ${this.readStreak + 1} 遍)`;
        }
      }
    }

    startVoiceRecording() {
      if (this.isRecording) return;
      const recordBtn = document.getElementById('btnPhonicsRecord');
      const feedbackBox = document.getElementById('recordingFeedbackBox');
      const statusText = document.getElementById('recordingStatusText');
      const btnPlay = document.getElementById('btnPlayMyRecording');

      this.isRecording = true;
      if (recordBtn) {
        recordBtn.disabled = true;
        recordBtn.style.opacity = '0.6';
      }
      if (feedbackBox) {
        feedbackBox.style.display = 'inline-flex';
      }

      let countdown = 3;
      const wordText = this.currentWord ? this.currentWord.word : '';
      if (statusText) statusText.textContent = `🎙️ 正在录音，请清晰朗读：${wordText} (${countdown}s)`;

      let audioChunks = [];
      let mediaRecorder = null;
      let stream = null;

      const finishRecording = () => {
        clearInterval(timer);
        this.isRecording = false;
        if (recordBtn) {
          recordBtn.disabled = false;
          recordBtn.style.opacity = '1';
        }
        if (feedbackBox) feedbackBox.style.display = 'none';

        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
          try { mediaRecorder.stop(); } catch(e){}
        }
        if (stream) {
          try { stream.getTracks().forEach(track => track.stop()); } catch(e){}
        }

        this.sound.playTone('correct');
        this.handleReadProgress();
      };

      const timer = setInterval(() => {
        countdown--;
        if (countdown > 0) {
          if (statusText) statusText.textContent = `🎙️ 正在录音，请清晰朗读：${wordText} (${countdown}s)`;
        } else {
          finishRecording();
        }
      }, 1000);

      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ audio: true })
          .then(s => {
            stream = s;
            try {
              mediaRecorder = new MediaRecorder(stream);
              mediaRecorder.ondataavailable = e => {
                if (e.data && e.data.size > 0) audioChunks.push(e.data);
              };
              mediaRecorder.onstop = () => {
                if (audioChunks.length > 0) {
                  const blob = new Blob(audioChunks, { type: 'audio/webm' });
                  if (this.lastUserAudioUrl) URL.revokeObjectURL(this.lastUserAudioUrl);
                  this.lastUserAudioUrl = URL.createObjectURL(blob);
                  if (btnPlay) {
                    btnPlay.style.display = 'inline-flex';
                    btnPlay.textContent = '▶️ 回听我的发音';
                  }
                }
              };
              mediaRecorder.start();
            } catch(err) {
              console.log('MediaRecorder fallback to timer', err);
            }
          })
          .catch(err => {
            console.log('Microphone permission or secure context not available, using timed feedback', err);
          });
      }
    }

    // ---------------- 环节 2: 【看图默写】实物具象大图 + 场景句子挖空 + 盲打决斗 ----------------
    // 环节 2 看答案提示开关
    toggleStage2Answer() {
      const box = document.getElementById('stage2AnswerRevealBox');
      const btn = document.getElementById('btnRevealStage2Answer');
      if (!box || !this.currentWord) return;
      const isHidden = box.style.display === 'none' || !box.style.display;
      box.style.display = isHidden ? 'inline-block' : 'none';
      if (btn) btn.textContent = isHidden ? '🙈 隐藏答案提示' : '👁️ 看答案提示';
      if (isHidden) {
        const wordEl = document.getElementById('stage2AnswerWord');
        const exEl = document.getElementById('stage2AnswerExample');
        if (wordEl) wordEl.textContent = this.currentWord.word;
        if (exEl) exEl.textContent = this.currentWord.example || '';
      }
    }

    renderStage2Writing() {
      if (!this.currentWord) return;
      this.stage2Input = '';

      // 更新右上角进度胶囊
      this.updateStageProgressBadges();

      const sceneIll = document.getElementById('battleSceneIllustration');
      if (sceneIll) sceneIll.textContent = this.currentWord.sceneImg || '🌟';

      // 动态真实例句挖空：杜绝千篇一律的 "The ___ is on the desk"
      const sentenceEn = document.getElementById('battleSentenceEn');
      const sentenceCn = document.getElementById('battleSentenceCn');
      const phoneticEl = document.getElementById('battlePhonetic');

      const word = this.currentWord.word;
      const example = this.currentWord.example || '';
      const meaning = this.currentWord.meaning || this.currentWord.chinese || '';

      if (sentenceEn) {
        if (example && new RegExp(`\\b${word}\\b`, 'i').test(example)) {
          // 使用单词自带的真实生动例句进行挖空
          sentenceEn.innerHTML = example.replace(
            new RegExp(`\\b${word}\\b`, 'i'),
            `<span id="battleSentenceBlank" style="display: inline-block; min-width: 90px; border-bottom: 3.5px solid #3b82f6; color: #1d4ed8; padding: 0 6px;">______</span>`
          );
        } else {
          // 自适应自然语境
          sentenceEn.innerHTML = `This is a/an <span id="battleSentenceBlank" style="display: inline-block; min-width: 90px; border-bottom: 3.5px solid #3b82f6; color: #1d4ed8; padding: 0 6px;">______</span>.`;
        }
      }

      // 仅显示中文释义，绝不提前透露例句与答案单词！
      if (sentenceCn) sentenceCn.textContent = meaning;
      if (phoneticEl) phoneticEl.textContent = this.currentWord.phonetic || '';

      // 重置看答案提示折叠框
      const answerBox = document.getElementById('stage2AnswerRevealBox');
      const revealBtn = document.getElementById('btnRevealStage2Answer');
      if (answerBox) answerBox.style.display = 'none';
      if (revealBtn) revealBtn.textContent = '👁️ 看答案提示';

      // 下划线槽位
      const slotsContainer = document.getElementById('letterSlots');
      if (slotsContainer) {
        slotsContainer.innerHTML = '';
        for (let i = 0; i < this.currentWord.word.length; i++) {
          const slot = document.createElement('div');
          slot.className = 'stage1-underline-slot' + (i === 0 ? ' current' : '');
          slot.id = `slot_${i}`;
          slot.textContent = '';
          slotsContainer.appendChild(slot);
        }
      }

      // 彩色微立体气泡字母候选区 (活力清爽，不与下方白键混淆)
      const bubblesRow = document.getElementById('battleLetterBubbles');
      if (bubblesRow) {
        bubblesRow.innerHTML = '';
        const chars = this.currentWord.word.split('').sort(() => Math.random() - 0.5);
        chars.forEach(ch => {
          const b = document.createElement('button');
          b.className = 'battle-letter-bubble';
          b.textContent = ch;
          b.onclick = () => this.handleStage2Typing(ch);
          bubblesRow.appendChild(b);
        });
      }

      const nextBtn = document.getElementById('btnStage2Next');
      if (nextBtn) nextBtn.style.display = 'none';
    }

    handleStage2Typing(key) {
      if (!this.currentWord) return;
      const targetWord = this.currentWord.word.toLowerCase();

      if (key === 'BACKSPACE') {
        if (this.stage2Input.length > 0) {
          this.stage2Input = this.stage2Input.slice(0, -1);
          this.updateStage2SlotsDisplay();
        }
        return;
      }

      if (key === 'CLEAR') {
        this.stage2Input = '';
        this.updateStage2SlotsDisplay();
        return;
      }

      if (/^[a-zA-Z]$/.test(key)) {
        if (this.stage2Input.length < targetWord.length) {
          this.stage2Input += key.toLowerCase();
          this.updateStage2SlotsDisplay();

          if (this.stage2Input.length === targetWord.length) {
            if (this.stage2Input === targetWord) {
              this.sound.playTone('correct');
              this.storage.markMastered(this.currentWord.id);
              this.handleCombo(true);

              this.storage.state.todayProgress.step2 = true;
              this.storage.state.todayProgress.step2Count = (this.storage.state.todayProgress.step2Count || 0) + 1;
              this.storage.save();
              this.renderParentDailyReport();

              const hpBar = document.getElementById('bossHpBar');
              if (hpBar) hpBar.style.width = '30%';

              const blank = document.getElementById('battleSentenceBlank');
              if (blank) blank.textContent = this.currentWord.word;

              setTimeout(() => {
                if (hpBar) hpBar.style.width = '100%';
                this.pickRandomWord();
                this.renderStage2Writing();
              }, 600);
            } else {
              this.sound.playTone('wrong');
              this.storage.recordMistake(this.currentWord);
              this.handleCombo(false);
              const slots = document.getElementById('letterSlots');
              if (slots) {
                slots.style.animation = 'shake 0.3s ease';
                setTimeout(() => { slots.style.animation = ''; }, 300);
              }
            }
          }
        }
      }
    }

    updateStage2SlotsDisplay() {
      if (!this.currentWord) return;
      const targetLen = this.currentWord.word.length;
      for (let i = 0; i < targetLen; i++) {
        const slot = document.getElementById(`slot_${i}`);
        if (slot) {
          slot.textContent = this.stage2Input[i] || '';
          slot.classList.toggle('filled', !!this.stage2Input[i]);
        }
      }
      const blank = document.getElementById('battleSentenceBlank');
      if (blank) {
        blank.textContent = this.stage2Input || '______';
      }
    }

    // ---------------- 环节 3: 【听音辨义】纯原生发音快速四选一 ----------------
    renderStage3Listening(autoSpeak = false) {
      if (!this.currentWord) return;
      if (autoSpeak) {
        this.sound.speak(this.currentWord.word);
      }

      this.updateStageProgressBadges();

      // 展示当前单词的国际音标 (音标加发音，英文单词保持隐藏)
      const phoneticEl = document.getElementById('flashPhoneticDisplay');
      if (phoneticEl) {
        phoneticEl.textContent = this.currentWord.phonetic || '';
      }

      const currentMeaning = this.currentWord.meaning || this.currentWord.chinese || '未知释义';
      const options = [currentMeaning];
      const others = RAW_VOCABULARY.filter(w => w.id !== this.currentWord.id);
      while (options.length < 4 && others.length > 0) {
        const randOpt = others[Math.floor(Math.random() * others.length)].meaning;
        if (randOpt && !options.includes(randOpt)) options.push(randOpt);
      }
      options.sort(() => Math.random() - 0.5);

      const grid = document.getElementById('flashOptionsGrid');
      if (!grid) return;
      grid.innerHTML = '';

      const nextBtn = document.getElementById('btnStage3Next');
      if (nextBtn) nextBtn.style.display = 'none';

      options.forEach(opt => {
        const btn = document.createElement('div');
        btn.className = 'quiz-option-card';
        btn.textContent = opt;
        btn.onclick = () => {
          if (opt === currentMeaning) {
            // 点中正确：翠绿高亮强反馈
            btn.classList.add('correct');
            btn.classList.remove('wrong');
            this.sound.playTone('correct');
            this.handleCombo(true);
            this.storage.state.todayProgress.step3 = true;
            this.storage.state.todayProgress.step3Count = (this.storage.state.todayProgress.step3Count || 0) + 1;
            this.storage.save();
            this.renderParentDailyReport();

            if (nextBtn) nextBtn.style.display = 'inline-block';

            setTimeout(() => {
              if (this.storage.state.todayProgress.step3Count >= 10 && this.storage.state.todayProgress.step3Count % 10 === 0) {
                this.showVictoryModal();
              } else {
                this.pickRandomWord();
                this.renderStage3Listening();
              }
            }, 600);
          } else {
            // 点中错误：警示红高亮强反馈
            btn.classList.add('wrong');
            this.sound.playTone('wrong');
            this.storage.recordMistake(this.currentWord);
            this.handleCombo(false);
          }
        };
        grid.appendChild(btn);
      });
    }

    // 统一各环节小巧进度胶囊
    updateStageProgressBadges() {
      const g = this.currentWord ? `${this.currentWord.grade || 1}年级` : '';
      const count1 = (this.storage.state.todayProgress.step1Count || 0) + 1;
      const count2 = (this.storage.state.todayProgress.step2Count || 0) + 1;
      const count3 = (this.storage.state.todayProgress.step3Count || 0) + 1;

      const b1 = document.getElementById('stage1ProgressBadge');
      if (b1) b1.textContent = `第 ${count1} 词 · ${g}`;
      const b2 = document.getElementById('stage2ProgressBadge');
      if (b2) b2.textContent = `第 ${count2} 词 · ${g}`;
      const b3 = document.getElementById('stage3ProgressBadge');
      if (b3) b3.textContent = `第 ${count3} 词 · ${g}`;
    }

    // ---------------- 🎉 今日挑战大捷结算弹窗控制 ----------------
    showVictoryModal() {
      const modal = document.getElementById('victorySummaryModal');
      if (modal) modal.style.display = 'flex';

      const p = this.storage.state.todayProgress;
      const summaryText = document.getElementById('feedSummaryText');
      const petExpFill = document.getElementById('petExpFill');
      const petExpText = document.getElementById('petExpText');
      const feedAvatar = document.getElementById('feedPetAvatar');

      const pet = this.storage.state.pet;
      if (feedAvatar) feedAvatar.textContent = pet === 'fox' ? '⚡' : (pet === 'drake' ? '🔥' : '🍃');

      const s1 = p.step1Count || 0;
      const s2 = p.step2Count || 0;
      const s3 = p.step3Count || 0;
      const totalWords = s1 + s2 + s3;

      let tip = `今日已读写学词 ${s1} 词 · 看图默写 ${s2} 词 · 听音辨义 ${s3} 词！(共攻克 ${totalWords} 词)`;
      if (summaryText) summaryText.textContent = tip;

      const currentExp = this.storage.state.petExp;
      const targetExp = this.storage.state.petLevel * 150;
      const pct = Math.min(100, Math.round((currentExp / targetExp) * 100));

      if (petExpFill) petExpFill.style.width = `${pct}%`;
      if (petExpText) {
        const petTitle = pet === 'fox' ? '电光灵狐' : (pet === 'drake' ? '烈焰幼龙' : '森之精灵');
        petExpText.textContent = `${petTitle} 当前等级 Lv.${this.storage.state.petLevel} (经验值 ${currentExp} / ${targetExp})`;
      }
    }

    closeVictoryModal() {
      const modal = document.getElementById('victorySummaryModal');
      if (modal) modal.style.display = 'none';
      this.exitFocusMode();
    }

    feedPet() {
      this.sound.playTone('combo');
      this.storage.state.petExp += 50;
      const targetExp = this.storage.state.petLevel * 150;
      if (this.storage.state.petExp >= targetExp) {
        this.storage.state.petLevel += 1;
        this.storage.state.petExp -= targetExp;
        alert(`🎉 恭喜！守护灵宠升级至 Lv.${this.storage.state.petLevel}！`);
      }
      this.storage.save();
      this.showVictoryModal();
      this.applyTheme(this.storage.state.pet);
    }

    handleCombo(isSuccess) {
      if (isSuccess) {
        this.storage.state.combo += 1;
        if (this.storage.state.combo % 3 === 0) this.sound.playTone('combo');
      } else {
        this.storage.state.combo = 0;
      }
      const comboEl = document.getElementById('hudCombo');
      if (comboEl) comboEl.textContent = this.storage.state.combo;
      this.storage.save();
    }


    // ---------------- 家长看板：今日学习进展全景汇报 ----------------
    renderParentDailyReport() {
      const p = this.storage.state.todayProgress;
      const setBox = (id, textId, isDone, countText) => {
        const box = document.getElementById(id);
        const text = document.getElementById(textId);
        if (box && text) {
          box.classList.toggle('completed', isDone);
          box.classList.toggle('skipped', !isDone);
          text.textContent = isDone ? `已通关 (${countText})` : '待开始';
          text.style.color = isDone ? '#059669' : '#64748b';
        }
      };

      setBox('stepReport1', 'stepReportText1', p.step1, `${p.step1Count || 0} 词`);
      setBox('stepReport2', 'stepReportText2', p.step2, `${p.step2Count || 0} 词`);
      setBox('stepReport3', 'stepReportText3', p.step3, `${p.step3Count || 0} 词`);

      const stepsDone = (p.step1 ? 1 : 0) + (p.step2 ? 1 : 0) + (p.step3 ? 1 : 0);
      const totalWords = (p.step1Count || 0) + (p.step2Count || 0) + (p.step3Count || 0);

      const overall = document.getElementById('reportOverallStatus');
      if (overall) {
        overall.textContent = stepsDone === 3 ? '🎉 今日三大环节全通关！' : (stepsDone > 0 ? `● 正在探索演练中 (${stepsDone}/3)` : '● 今日探索待开始');
        overall.style.color = stepsDone === 3 ? '#10b981' : '#0284c7';
      }

      const summarySteps = document.getElementById('summaryStepsDone');
      if (summarySteps) summarySteps.textContent = stepsDone;
      const summaryMastered = document.getElementById('summaryMasteredToday');
      if (summaryMastered) summaryMastered.textContent = totalWords;
      const summaryAcc = document.getElementById('summaryAccuracy');
      if (summaryAcc) {
        const mistakesToday = (this.storage.state.mistakes || []).filter(m => {
          const d = m.lastMistakeTime ? new Date(m.lastMistakeTime).toDateString() : '';
          return d === new Date().toDateString();
        }).length;
        const totalAnswers = totalWords + mistakesToday;
        const acc = totalAnswers > 0 ? Math.round((totalWords / totalAnswers) * 100) : 100;
        summaryAcc.textContent = acc + '%';
      }
    }

    // ================= 5. 3-in-1 游戏竞技场 =================

    switchGameTab(tabName) {
      this.activeGameTab = tabName;
      if (tabName !== 'meteor' && this.meteorInterval) clearInterval(this.meteorInterval);
      if (tabName !== 'igloo' && this.iglooInterval) clearInterval(this.iglooInterval);
      if (tabName !== 'match' && this.matchInterval) clearInterval(this.matchInterval);

      document.getElementById('tabGameIgloo').className = tabName === 'igloo' ? 'btn-clean primary' : 'btn-clean secondary';
      document.getElementById('tabGameMeteor').className = tabName === 'meteor' ? 'btn-clean primary' : 'btn-clean secondary';
      document.getElementById('tabGameMatch').className = tabName === 'match' ? 'btn-clean primary' : 'btn-clean secondary';

      document.getElementById('game-igloo-view').style.display = tabName === 'igloo' ? 'block' : 'none';
      document.getElementById('game-meteor-view').style.display = tabName === 'meteor' ? 'block' : 'none';
      document.getElementById('game-match-view').style.display = tabName === 'match' ? 'block' : 'none';

      if (tabName === 'igloo') this.initIglooBattle();
      else if (tabName === 'meteor') this.initMeteorBlaster();
      else if (tabName === 'match') this.startNewGame();
    }

    // 游戏 A: 冰原推兵
    initIglooBattle() {
      this.iglooPlayerHp = 100;
      this.iglooEnemyHp = 100;
      this.iglooEnergy = 0;
      this.iglooTimer = 120;
      this.updateIglooHud();
      this.nextIglooQuestion();

      if (this.iglooInterval) clearInterval(this.iglooInterval);
      this.iglooInterval = setInterval(() => {
        if (this.iglooTimer > 0) {
          this.iglooTimer -= 1;
          const mins = Math.floor(this.iglooTimer / 60).toString().padStart(2, '0');
          const secs = (this.iglooTimer % 60).toString().padStart(2, '0');
          const timerEl = document.getElementById('iglooBattleTimer');
          if (timerEl) timerEl.textContent = `${mins}:${secs}`;
        }
      }, 1000);
    }

    updateIglooHud() {
      const pFill = document.getElementById('iglooPlayerHp');
      const pText = document.getElementById('iglooPlayerHpText');
      const eFill = document.getElementById('iglooEnemyHp');
      const eText = document.getElementById('iglooEnemyHpText');
      const energyFill = document.getElementById('iglooEnergyFill');
      const energyCount = document.getElementById('iglooEnergyCount');
      const btnUlt = document.getElementById('btnIglooUltimate');

      if (pFill) pFill.style.width = `${this.iglooPlayerHp}%`;
      if (pText) pText.textContent = this.iglooPlayerHp;
      if (eFill) eFill.style.width = `${this.iglooEnemyHp}%`;
      if (eText) eText.textContent = this.iglooEnemyHp;

      if (energyFill) energyFill.style.width = `${(this.iglooEnergy / 5) * 100}%`;
      if (energyCount) energyCount.textContent = `${this.iglooEnergy} / 5`;
      if (btnUlt) btnUlt.disabled = this.iglooEnergy < 5;
    }

    nextIglooQuestion() {
      if (this.gamePool.length === 0) this.updateGamePool();
      const randWord = this.gamePool[Math.floor(Math.random() * this.gamePool.length)];

      const qWord = document.getElementById('iglooQuestionWord');
      if (qWord) qWord.textContent = randWord.meaning;

      const grid = document.getElementById('iglooOptionsGrid');
      if (!grid) return;
      grid.innerHTML = '';

      const opts = [randWord.word];
      const others = RAW_VOCABULARY.filter(w => w.id !== randWord.id);
      while (opts.length < 4 && others.length > 0) {
        const randW = others[Math.floor(Math.random() * others.length)].word;
        if (!opts.includes(randW)) opts.push(randW);
      }
      opts.sort(() => Math.random() - 0.5);

      opts.forEach(w => {
        const btn = document.createElement('div');
        btn.className = 'quiz-option-card';
        btn.textContent = w;
        btn.onclick = () => {
          if (w === randWord.word) {
            this.sound.playTone('troop');
            this.spawnTroop('penguin');
            this.iglooEnergy = Math.min(5, this.iglooEnergy + 1);
            this.iglooEnemyHp = Math.max(0, this.iglooEnemyHp - 10);
            this.updateIglooHud();

            if (this.iglooEnemyHp <= 0) {
              this.sound.playTone('combo');
              alert('🏆 胜利！海豹城堡已被我方攻破，获得能量水晶 +100！');
              this.initIglooBattle();
              return;
            }
            setTimeout(() => this.nextIglooQuestion(), 400);
          } else {
            this.sound.playTone('wrong');
            this.spawnTroop('seal');
            this.iglooPlayerHp = Math.max(0, this.iglooPlayerHp - 10);
            this.updateIglooHud();

            if (this.iglooPlayerHp <= 0) {
              alert('💔 我方冰屋生命耗尽，再接再厉，重新防守！');
              this.initIglooBattle();
              return;
            }
          }
        };
        grid.appendChild(btn);
      });
    }

    spawnTroop(type) {
      const lane = document.getElementById('marchingTroopContainer');
      if (!lane) return;
      const troop = document.createElement('div');
      troop.className = 'marching-troop';
      troop.textContent = type === 'penguin' ? '🐧' : '🦭';
      troop.style.top = '24px';

      if (type === 'penguin') {
        troop.style.left = '40px';
        lane.appendChild(troop);
        setTimeout(() => { troop.style.left = '85%'; }, 50);
        setTimeout(() => { troop.remove(); }, 600);
      } else {
        troop.style.left = '85%';
        lane.appendChild(troop);
        setTimeout(() => { troop.style.left = '40px'; }, 50);
        setTimeout(() => { troop.remove(); }, 600);
      }
    }

    castIglooUltimate() {
      if (this.iglooEnergy < 5) return;
      this.sound.playTone('ultimate');
      this.iglooEnergy = 0;
      this.iglooEnemyHp = Math.max(0, this.iglooEnemyHp - 15);
      this.updateIglooHud();

      const arena = document.querySelector('.igloo-battle-arena');
      if (arena) {
        arena.style.filter = 'brightness(1.5) hue-rotate(180deg)';
        setTimeout(() => { arena.style.filter = ''; }, 600);
      }

      if (this.iglooEnemyHp <= 0) {
        alert('🎉 暴风雪大招绝杀！海豹冰屋被彻底消灭，全场大胜！');
        this.initIglooBattle();
      } else {
        this.nextIglooQuestion();
      }
    }

    // 游戏 B: 星际消陨石 (完整动态激光拦截小游戏)
    initMeteorBlaster() {
      this.meteorScore = 0;
      this.meteorShield = 100;
      if (this.meteorInterval) clearInterval(this.meteorInterval);
      const shieldEl = document.getElementById('meteorShield');
      if (shieldEl) shieldEl.textContent = '100%';
      const scoreEl = document.getElementById('meteorScore');
      if (scoreEl) scoreEl.textContent = '0';
      this.nextMeteorWord();
    }

    nextMeteorWord() {
      if (this.gamePool.length === 0) this.updateGamePool();
      this.meteorWord = this.gamePool[Math.floor(Math.random() * this.gamePool.length)];

      const wordEl = document.getElementById('meteorWordText');
      if (wordEl) wordEl.textContent = this.meteorWord.word;

      const rock = document.getElementById('meteorRock');
      if (this.meteorInterval) clearInterval(this.meteorInterval);

      this.meteorTop = 60;
      if (rock) {
        rock.style.top = '60px';
        rock.style.opacity = '1';
        rock.style.transform = 'translateX(-50%) scale(1)';
        rock.style.filter = 'none';
      }

      // 陨石坠落循环 (每 100ms 坠落 1.5px，约 14 秒到达基地下方)
      this.meteorInterval = setInterval(() => {
        this.meteorTop += 1.5;
        if (rock) rock.style.top = `${this.meteorTop}px`;

        if (this.meteorTop >= 270) {
          // 陨石撞击基地！
          clearInterval(this.meteorInterval);
          this.sound.playTone('wrong');
          this.meteorShield = Math.max(0, this.meteorShield - 20);
          const shieldEl = document.getElementById('meteorShield');
          if (shieldEl) shieldEl.textContent = `${this.meteorShield}%`;

          if (rock) {
            rock.style.transform = 'translateX(-50%) scale(1.4)';
            rock.style.filter = 'drop-shadow(0 0 25px #ef4444)';
          }

          setTimeout(() => {
            if (this.meteorShield <= 0) {
              alert('💥 基地护盾被击穿！防空防御系统已重启！');
              this.initMeteorBlaster();
            } else {
              this.nextMeteorWord();
            }
          }, 450);
        }
      }, 100);

      const grid = document.getElementById('meteorOptionsGrid');
      if (!grid) return;
      grid.innerHTML = '';

      const opts = [this.meteorWord.meaning];
      const others = RAW_VOCABULARY.filter(w => w.id !== this.meteorWord.id);
      while (opts.length < 4 && others.length > 0) {
        const randM = others[Math.floor(Math.random() * others.length)].meaning;
        if (!opts.includes(randM)) opts.push(randM);
      }
      opts.sort(() => Math.random() - 0.5);

      opts.forEach(m => {
        const btn = document.createElement('button');
        btn.className = 'laser-option-btn';
        btn.textContent = m;
        btn.onclick = () => {
          if (m === this.meteorWord.meaning) {
            clearInterval(this.meteorInterval);
            this.sound.playTone('laser');
            this.meteorScore += 10;
            const scoreEl = document.getElementById('meteorScore');
            if (scoreEl) scoreEl.textContent = this.meteorScore;

            // 触发激光发射动画
            const beam = document.getElementById('meteorLaserBeam');
            if (beam) {
              beam.style.height = `${280 - this.meteorTop + 50}px`;
              beam.style.opacity = '1';
            }

            if (rock) {
              rock.style.transform = 'translateX(-50%) scale(1.4)';
              rock.style.opacity = '0';
              rock.style.filter = 'drop-shadow(0 0 30px #38bdf8)';
            }

            setTimeout(() => {
              if (beam) {
                beam.style.height = '0';
                beam.style.opacity = '0';
              }
              this.nextMeteorWord();
            }, 300);
          } else {
            this.sound.playTone('wrong');
            btn.style.borderColor = '#ef4444';
            btn.style.color = '#ef4444';
            this.meteorShield = Math.max(0, this.meteorShield - 10);
            const shieldEl = document.getElementById('meteorShield');
            if (shieldEl) shieldEl.textContent = `${this.meteorShield}%`;
            if (this.meteorShield <= 0) {
              clearInterval(this.meteorInterval);
              alert('💥 基地护盾耗尽！正在重新充能...');
              this.initMeteorBlaster();
            }
          }
        };
        grid.appendChild(btn);
      });
    }

    // 游戏 C: 单词连连看 (纯文字防作弊立体卡牌)
    startNewGame() {
      const arena = document.getElementById('gameGridArena');
      const winBanner = document.getElementById('gameWinBanner');
      if (winBanner) winBanner.style.display = 'none';
      if (!arena) return;

      this.matchSelected = null;
      this.matchPairsCount = 0;
      this.matchScore = 0;
      this.matchCountdown = 60;

      const countdownEl = document.getElementById('gameCountdown');
      const scoreEl = document.getElementById('gameScore');
      if (countdownEl) countdownEl.textContent = '60s';
      if (scoreEl) scoreEl.textContent = '0';

      if (this.gamePool.length === 0) this.updateGamePool();
      const shuffledPool = [...this.gamePool].sort(() => Math.random() - 0.5);
      const chosenWords = shuffledPool.slice(0, Math.min(6, shuffledPool.length));

      const cards = [];
      chosenWords.forEach(w => {
        cards.push({ id: w.id, text: w.word, type: 'en', pairId: w.id });
        cards.push({ id: w.id, text: w.meaning, type: 'cn', pairId: w.id });
      });
      cards.sort(() => Math.random() - 0.5);

      arena.innerHTML = '';
      cards.forEach(card => {
        const item = document.createElement('div');
        item.className = 'game-card-cell';
        item.textContent = card.text;
        item.onclick = () => this.handleMatchCardClick(item, card);
        arena.appendChild(item);
      });

      if (this.matchInterval) clearInterval(this.matchInterval);
      this.matchInterval = setInterval(() => {
        this.matchCountdown -= 1;
        if (countdownEl) countdownEl.textContent = `${this.matchCountdown}s`;
        if (this.matchCountdown <= 0) {
          clearInterval(this.matchInterval);
          alert('⏰ 时间到！本局连连看挑战结束！点击“换一局新词”开启新挑战！');
        }
      }, 1000);
    }

    handleMatchCardClick(dom, card) {
      if (dom.classList.contains('matched') || dom.classList.contains('selected')) return;

      if (!this.matchSelected) {
        this.matchSelected = { dom, card };
        dom.classList.add('selected');
      } else {
        const prev = this.matchSelected;
        if (prev.card.pairId === card.pairId && prev.card.type !== card.type) {
          this.sound.playTone('correct');
          dom.classList.remove('selected');
          prev.dom.classList.remove('selected');
          dom.classList.add('matched');
          prev.dom.classList.add('matched');

          this.matchScore += 10;
          this.matchPairsCount += 1;
          const scoreEl = document.getElementById('gameScore');
          if (scoreEl) scoreEl.textContent = this.matchScore;
          this.matchSelected = null;

          if (this.matchPairsCount >= 6) {
            clearInterval(this.matchInterval);
            this.sound.playTone('combo');
            const winBanner = document.getElementById('gameWinBanner');
            if (winBanner) winBanner.style.display = 'block';
          }
        } else {
          this.sound.playTone('wrong');
          dom.classList.add('wrong');
          setTimeout(() => {
            dom.classList.remove('wrong');
            prev.dom.classList.remove('selected');
            this.matchSelected = null;
          }, 350);
        }
      }
    }

    // ================= 6. 家长看板与智能错题库 =================

    renderGradeAnalytics() {
      const grid = document.getElementById('gradeAnalyticsGrid');
      if (!grid) return;
      grid.innerHTML = '';

      const totalMastered = this.storage.state.masteredIds ? this.storage.state.masteredIds.length : 0;
      const totalWords = (window.WORD_DATABASE || RAW_VOCABULARY).length;
      const overviewText = document.getElementById('gradesOverviewText');
      if (overviewText) overviewText.textContent = `全套 6 个年级累计已精通 ${totalMastered} / ${totalWords} 词`;

      for (let g = 1; g <= 6; g++) {
        const wordsInGrade = RAW_VOCABULARY.filter(w => w.grade === g);
        const masteredInGrade = wordsInGrade.filter(w => this.storage.state.masteredIds.includes(w.id)).length;
        const total = wordsInGrade.length;
        const pct = total > 0 ? Math.round((masteredInGrade / total) * 100) : 0;

        const card = document.createElement('div');
        card.className = 'grade-progress-card';
        card.innerHTML = `
          <div class="grade-title-row">
            <span class="grade-name-tag">${g} 年级核心</span>
            <span style="font-family: var(--font-mono); font-size: 13px; font-weight: 800; color: var(--theme-primary);">${pct}%</span>
          </div>
          <div class="grade-bar-track">
            <div class="grade-bar-fill" style="width: ${pct}%;"></div>
          </div>
          <div class="grade-stat-summary">
            <span>已精通: ${masteredInGrade} / ${total} 词</span>
            <span style="color: #94a3b8;">官方教纲</span>
          </div>
        `;
        grid.appendChild(card);
      }
    }

    renderMistakesTable() {
      const tbody = document.getElementById('mistakeTableBody');
      if (!tbody) return;
      tbody.innerHTML = '';

      const gradeFilter = (document.getElementById('mistakeFilterGrade') ? document.getElementById('mistakeFilterGrade').value : 'all');
      const dateFilter = (document.getElementById('mistakeFilterDate') ? document.getElementById('mistakeFilterDate').value : 'all');
      const searchInputEl = document.getElementById('mistakeSearchInput');
      const searchKey = ((searchInputEl && searchInputEl.value) || '').toLowerCase().trim();
      const clearBtn = document.getElementById('btnClearMistakeSearch');
      if (clearBtn) clearBtn.style.display = searchKey ? 'inline-block' : 'none';

      let list = this.storage.state.mistakes || [];

      // 1. 年级筛选
      if (gradeFilter !== 'all') {
        list = list.filter(m => m.grade === parseInt(gradeFilter, 10));
      }

      // 2. 时间维度筛选
      if (dateFilter === 'today') {
        const todayStr = new Date().toLocaleDateString('zh-CN');
        list = list.filter(m => m.lastTime === todayStr || m.lastTime === '今天');
      } else if (dateFilter === 'week') {
        const now = Date.now();
        const SEVEN_DAYS = 7 * 86400 * 1000;
        list = list.filter(m => {
          if (m.timestamp) return (now - m.timestamp) <= SEVEN_DAYS;
          return true;
        });
      }

      // 3. 智能搜索综合过滤 (支持年级词汇、单词、音标、释义、日期)
      if (searchKey) {
        const gradeMap = { '一年级': 1, '1年级': 1, '二年级': 2, '2年级': 2, '三年级': 3, '3年级': 3, '四年级': 4, '4年级': 4, '五年级': 5, '5年级': 5, '六年级': 6, '6年级': 6 };
        const targetGrade = gradeMap[searchKey];

        list = list.filter(m => {
          if (targetGrade !== undefined && m.grade === targetGrade) return true;
          const word = (m.word || '').toLowerCase();
          const meaning = (m.meaning || m.chinese || '').toLowerCase();
          const phonetic = (m.phonetic || '').toLowerCase();
          const lastTime = (m.lastTime || '').toLowerCase();
          const gradeStr = `${m.grade}年级`;
          return word.includes(searchKey) || meaning.includes(searchKey) || phonetic.includes(searchKey) || lastTime.includes(searchKey) || gradeStr.includes(searchKey);
        });
      }

      // 动态更新看板总数徽标
      const badge = document.getElementById('mistakeTotalCountBadge');
      if (badge) {
        badge.textContent = `${list.length} 词待攻坚`;
      }

      if (list.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" class="align-center" style="padding: 32px; color: var(--text-muted); font-size: 14px;">暂无符合筛选条件的错题记录，保持优秀！</td></tr>`;
        return;
      }

      list.forEach((m, idx) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td class="align-center" style="white-space: nowrap; font-weight: 700; color: #64748b;">${idx + 1}</td>
          <td class="align-left" style="white-space: nowrap;"><strong style="font-size: 14px; color: #0f172a;">${m.word}</strong></td>
          <td class="align-left" style="font-family: var(--font-mono); color: var(--sky-blue); white-space: nowrap;">${m.phonetic || ''}</td>
          <td class="align-left" style="font-weight: 500; color: #334155;">${m.meaning || m.chinese || ''}</td>
          <td class="align-center" style="white-space: nowrap;"><span class="quest-number-tag" style="background: #e0f2fe; color: #0369a1; padding: 2px 8px; border-radius: 4px; font-weight: 700;">${m.grade ? m.grade + ' 年级' : '通用'}</span></td>
          <td class="align-center" style="white-space: nowrap;"><strong style="color: var(--coral-red); font-size: 13px;">${m.count} 次</strong></td>
          <td class="align-center" style="font-size: 12px; color: #64748b; white-space: nowrap;">${m.lastTime || '今天'}</td>
          <td class="align-center" style="white-space: nowrap;"><button class="timer-btn" title="播放读音" style="width: 28px; height: 28px; border-radius: 6px; border: 1px solid #cbd5e1; background: #ffffff; cursor: pointer; display: inline-flex; align-items: center; justify-content: center;" onclick="window.app.sound.speak('${m.word}')">🔊</button></td>
        `;
        tbody.appendChild(tr);
      });
    }

    renderFullWordList() {
      const tbody = document.getElementById('fullWordTableBody');
      if (!tbody) return;
      tbody.innerHTML = '';

      const gradeFilter = (document.getElementById('fullListGradeFilter') ? document.getElementById('fullListGradeFilter').value : 'all');
      const searchInputEl = document.getElementById('fullListSearchInput');
      const searchKey = ((searchInputEl && searchInputEl.value) || '').toLowerCase().trim();
      const clearBtn = document.getElementById('btnClearFullSearch');
      if (clearBtn) clearBtn.style.display = searchKey ? 'inline-block' : 'none';

      let list = RAW_VOCABULARY || [];
      if (gradeFilter !== 'all') {
        const targetG = parseInt(gradeFilter, 10);
        list = list.filter(w => w.grade === targetG || w.gradeName === `${targetG}年级`);
      }
      if (searchKey) {
        list = list.filter(w => 
          (w.word && w.word.toLowerCase().includes(searchKey)) || 
          ((w.meaning || w.chinese) && (w.meaning || w.chinese).toLowerCase().includes(searchKey)) ||
          (w.phonetic && w.phonetic.toLowerCase().includes(searchKey))
        );
      }

      list.forEach((w, idx) => {
        const isMastered = this.storage.state.masteredIds.includes(w.id);
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td class="align-center">${idx + 1}</td>
          <td class="align-left"><strong style="color: #0f172a; cursor: pointer;" onclick="window.app.sound.speak('${w.word}')">${w.word}</strong></td>
          <td class="align-left" style="font-family: var(--font-mono); color: var(--sky-blue);">${w.phonetic}</td>
          <td class="align-center">${w.pos}</td>
          <td class="align-left">${w.meaning}</td>
          <td class="align-center"><span class="quest-number-tag">${w.grade} 年级</span></td>
          <td class="align-center">${isMastered ? '<span style="color: #10b981; font-weight: 800;">✓ 已精通</span>' : '<span style="color: #94a3b8;">攻坚中</span>'}</td>
          <td class="align-right">0</td>
          <td class="align-center"><button class="timer-btn" title="发音" onclick="window.app.sound.speak('${w.word}')">🔊</button></td>
        `;
        tbody.appendChild(tr);
      });
    }

    updateHudStats() {
      const hudMastered = document.getElementById('hudMasteredCount');
      if (hudMastered) {
        hudMastered.textContent = `${this.storage.state.masteredIds.length} / ${RAW_VOCABULARY.length}`;
      }
    }

    // ================= 7. 全局事件绑定 =================
    bindEvents() {
      const btnEnter = document.getElementById('btnEnterApp');
      if (btnEnter) {
        btnEnter.addEventListener('click', () => {
          const splash = document.getElementById('splashScreen');
          if (splash) splash.style.display = 'none';
          document.body.classList.add('app-entered'); // 标记已进入，彻底停用粒子
          if (window.neonParticles) {
            window.neonParticles.particles = [];
            window.neonParticles.rings = [];
          }
          this.sound.resumeCtx();
        });
      }

      const btnExitToSplash = document.getElementById('btnExitToSplash');
      if (btnExitToSplash) {
        btnExitToSplash.addEventListener('click', () => {
          const splash = document.getElementById('splashScreen');
          if (splash) splash.style.display = 'flex';
          document.body.classList.remove('app-entered');
        });
      }

      const btnChangePet = document.getElementById('btnChangePet');
      if (btnChangePet) {
        btnChangePet.addEventListener('click', () => {
          const splash = document.getElementById('splashScreen');
          if (splash) splash.style.display = 'flex';
          document.body.classList.remove('app-entered'); // 重新激活欢迎页粒子
          this.pickDailyQuote();
        });
      }

      document.querySelectorAll('.sub-nav-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const viewName = btn.getAttribute('data-view');
          this.switchView(viewName);
        });
      });

      document.querySelectorAll('.quest-card-item').forEach(card => {
        card.addEventListener('click', () => {
          const step = parseInt(card.getAttribute('data-step'), 10);
          this.setStep(step, false);
        });
      });

      const btnToggleFullscreen = document.getElementById('btnToggleTodayFullscreen');
      if (btnToggleFullscreen) {
        btnToggleFullscreen.addEventListener('click', () => {
          if (document.body.classList.contains('focus-mode')) {
            this.exitFocusMode();
          } else {
            this.enterFocusMode();
          }
        });
      }

      const btnExitFocus = document.getElementById('btnExitFocusMode');
      if (btnExitFocus) {
        btnExitFocus.addEventListener('click', () => {
          this.exitFocusMode();
        });
      }

      // 键盘监听 (Enter/空格 启动；ESC 退出专注态)
      window.addEventListener('keydown', (e) => {
        const splash = document.getElementById('splashScreen');
        if (splash && splash.style.display !== 'none') {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            splash.style.display = 'none';
            document.body.classList.add('app-entered');
            if (window.neonParticles) {
              window.neonParticles.particles = [];
              window.neonParticles.rings = [];
            }
            this.sound.resumeCtx();
            return;
          }
        }

        if (e.key === 'Escape') {
          this.exitFocusMode();
          if (document.body.classList.contains('game-fullscreen-mode')) {
            this.toggleGameFullscreen();
          }
        } else if (e.key === ' ') {
          e.preventDefault();
          if (this.currentWord) {
            // 空格键仅播放原声单词，绝不记入大声朗读次数！
            this.sound.speak(this.currentWord.word);
          }
        } else if (this.currentStep === 1) {
          if (e.key === 'Backspace') {
            this.handleStage1Typing('BACKSPACE');
          } else if (e.key === 'Enter') {
            this.handleStage1NextWord();
          } else if (/^[a-zA-Z]$/.test(e.key)) {
            this.handleStage1Typing(e.key.toUpperCase());
          }
        } else if (this.currentStep === 2) {
          if (e.key === 'Backspace') {
            this.handleStage2Typing('BACKSPACE');
          } else if (/^[a-zA-Z]$/.test(e.key)) {
            this.handleStage2Typing(e.key.toUpperCase());
          }
        } else if (this.currentStep === 3) {
          if (['1', '2', '3', '4'].includes(e.key)) {
            const idx = parseInt(e.key, 10) - 1;
            const cards = document.querySelectorAll('#flashOptionsGrid .quiz-option-card');
            if (cards && cards[idx]) cards[idx].click();
          }
        }
      });

      document.querySelectorAll('.stage1-onscreen-keyboard .kb-key, .onscreen-keyboard .kb-key').forEach(k => {
        k.addEventListener('click', () => {
          const key = k.getAttribute('data-key');
          if (key) {
            if (this.currentStep === 1) this.handleStage1Typing(key);
            else if (this.currentStep === 2) this.handleStage2Typing(key);
          }
        });
      });

      const btnFlashReplay = document.getElementById('btnFlashReplay');
      if (btnFlashReplay) {
        btnFlashReplay.addEventListener('click', () => {
          if (this.currentWord) this.sound.speak(this.currentWord.word);
        });
      }

      // 环节 2 大声朗读与试听 (真实录音反馈机制)
      const btnPhonicsWord = document.getElementById('btnPhonicsSpeakWord');
      if (btnPhonicsWord) {
        btnPhonicsWord.addEventListener('click', () => {
          if (this.currentWord) {
            // 点击【听原声单词】仅播放发音，绝不记入大声朗读次数！
            this.sound.speak(this.currentWord.word);
          }
        });
      }

      // 再试一次按钮
      const btnRetry = document.getElementById('btnPhonicsRetry');
      if (btnRetry) {
        btnRetry.addEventListener('click', () => {
          this.stage1Input = '';
          this.stage1TypingSuccess = false;
          this.updateStage1SlotsDisplay();
          const win = document.getElementById('phonicsTypeWindow');
          if (win) { win.classList.remove('wrong'); win.classList.remove('correct'); }
          const badge = document.getElementById('phonicsTypeStatusBadge');
          if (badge) {
            badge.textContent = '等待键盘敲入';
            badge.style.color = '#64748b';
            badge.style.background = '#f1f5f9';
          }
          if (this.currentWord) this.sound.speak(this.currentWord.word);
        });
      }

      // 跳过本词 (记入错题本) 按钮
      const btnSkipMistake = document.getElementById('btnPhonicsSkipMistake');
      if (btnSkipMistake) {
        btnSkipMistake.addEventListener('click', () => {
          if (this.currentWord) {
            this.storage.recordMistake(this.currentWord);
            this.handleStage1NextWord();
          }
        });
      }

      const btnPhonicsRecord = document.getElementById('btnPhonicsRecord');
      if (btnPhonicsRecord) {
        btnPhonicsRecord.addEventListener('click', () => {
          this.startVoiceRecording();
        });
      }

      const btnPlayMyRecording = document.getElementById('btnPlayMyRecording');
      if (btnPlayMyRecording) {
        btnPlayMyRecording.addEventListener('click', () => {
          if (this.lastUserAudioUrl) {
            const audio = new Audio(this.lastUserAudioUrl);
            audio.play().catch(() => {
              if (this.currentWord) this.sound.speak(this.currentWord.word);
            });
          } else if (this.currentWord) {
            this.sound.speak(this.currentWord.word);
          }
        });
      }

      const btnBattleAudio = document.getElementById('btnBattleAudio');
      if (btnBattleAudio) {
        btnBattleAudio.addEventListener('click', () => {
          if (this.currentWord) this.sound.speak(this.currentWord.word);
        });
      }
      const btnBattleSkip = document.getElementById('btnBattleSkip');
      if (btnBattleSkip) {
        btnBattleSkip.addEventListener('click', () => {
          if (this.currentWord) {
            this.storage.recordMistake(this.currentWord);
            alert(`📝 该词已记入错题本！正确拼写是：${this.currentWord.word} (${this.currentWord.meaning})`);
            this.pickRandomWord();
            this.renderStage2Writing();
          }
        });
      }

      // 环节 1: 键盘清空与下一个词按钮
      const btnPhonicsClear = document.getElementById('btnPhonicsClearType');
      if (btnPhonicsClear) {
        btnPhonicsClear.addEventListener('click', () => {
          this.stage1Input = '';
          this.updateStage1SlotsDisplay();
        });
      }

      const btnPhonicsNext = document.getElementById('btnPhonicsNextWord');
      if (btnPhonicsNext) {
        btnPhonicsNext.addEventListener('click', () => {
          this.handleStage1NextWord();
        });
      }

      // 今日挑战大厅：开始挑战与战报弹窗按钮
      const btnStartToday = document.getElementById('btnStartTodayChallenge');
      if (btnStartToday) {
        btnStartToday.addEventListener('click', () => {
          this.setStep(1, false);
          this.enterFocusMode();
        });
      }

      const btnLobbySummary = document.getElementById('btnLobbyViewSummary');
      if (btnLobbySummary) {
        btnLobbySummary.addEventListener('click', () => {
          this.showVictoryModal();
        });
      }

      const btnFocusSummary = document.getElementById('btnFocusVictorySummary');
      if (btnFocusSummary) {
        btnFocusSummary.addEventListener('click', () => {
          this.showVictoryModal();
        });
      }

      const btnFinishChallenge = document.getElementById('btnFinishTodayChallenge');
      if (btnFinishChallenge) {
        btnFinishChallenge.addEventListener('click', () => {
          this.showVictoryModal();
        });
      }

      const btnCloseVictory = document.getElementById('btnCloseVictoryModal');
      if (btnCloseVictory) {
        btnCloseVictory.addEventListener('click', () => {
          this.closeVictoryModal();
        });
      }

      const btnRestartRound = document.getElementById('btnRestartNextRound');
      if (btnRestartRound) {
        btnRestartRound.addEventListener('click', () => {
          this.closeVictoryModal();
          this.setStep(1, false);
          this.enterFocusMode();
        });
      }

      const btnFeed = document.getElementById('btnFeedPet');
      if (btnFeed) {
        btnFeed.addEventListener('click', () => this.feedPet());
      }

      // 家长抽词年级池勾选
      document.querySelectorAll('input[name="parentGradeCombo"]').forEach(cb => {
        cb.addEventListener('change', () => {
          const checked = Array.from(document.querySelectorAll('input[name="parentGradeCombo"]:checked'))
            .map(el => parseInt(el.value, 10));
          if (checked.length === 0) {
            alert('请至少保留一个年级作为抽取词库！');
            cb.checked = true;
            return;
          }
          this.storage.state.parentSettings.grades = checked;
          this.storage.save();
          this.refreshChallengePool();
          this.updateGamePool();
        });
      });

      // 错题库筛选与现代胶囊检索
      const filterGrade = document.getElementById('mistakeFilterGrade');
      if (filterGrade) filterGrade.addEventListener('change', () => this.renderMistakesTable());
      const filterDate = document.getElementById('mistakeFilterDate');
      if (filterDate) filterDate.addEventListener('change', () => this.renderMistakesTable());

      // 错题清单手风琴折叠展开
      const btnToggleMistake = document.getElementById('btnToggleMistakeAccordion');
      const mistakeBody = document.getElementById('mistakeAccordionBody');
      const mistakeToggleText = document.getElementById('mistakeAccordionToggleText');
      if (btnToggleMistake && mistakeBody) {
        btnToggleMistake.addEventListener('click', () => {
          const isHidden = mistakeBody.style.display === 'none';
          mistakeBody.style.display = isHidden ? 'block' : 'none';
          if (mistakeToggleText) {
            mistakeToggleText.textContent = isHidden ? '收起清单 ▴' : '展开清单 ▾';
          }
        });
      }

      const filterSearch = document.getElementById('mistakeSearchInput');
      const btnClearMistakeSearch = document.getElementById('btnClearMistakeSearch');
      if (filterSearch) {
        filterSearch.addEventListener('input', () => {
          if (btnClearMistakeSearch) {
            btnClearMistakeSearch.style.display = filterSearch.value.trim() ? 'block' : 'none';
          }
          this.renderMistakesTable();
        });
      }
      if (btnClearMistakeSearch) {
        btnClearMistakeSearch.addEventListener('click', () => {
          if (filterSearch) {
            filterSearch.value = '';
            filterSearch.focus();
          }
          btnClearMistakeSearch.style.display = 'none';
          this.renderMistakesTable();
        });
      }

      // 一键消灭当前错题
      const btnDrillMistakes = document.getElementById('btnDrillMistakes');
      if (btnDrillMistakes) {
        btnDrillMistakes.addEventListener('click', () => {
          const mistakeWords = Object.keys(this.storage.state.mistakes || {});
          if (mistakeWords.length === 0) {
            alert('🎉 太棒了！当前没有任何错题记录，所有单词已全部掌握！');
            return;
          }
          const mistakePool = window.WORD_DATABASE.filter(w => mistakeWords.includes(w.word));
          if (mistakePool.length > 0) {
            this.challengePool = mistakePool;
            this.switchView('training');
            this.setStep(1, false);
          }
        });
      }

      // 词库全量清单：手风琴展开与收起
      const btnToggleWordList = document.getElementById('btnToggleWordList');
      const wordListBody = document.getElementById('wordListAccordionBody');
      const wordListToggleText = document.getElementById('wordListToggleText');
      if (btnToggleWordList && wordListBody) {
        btnToggleWordList.addEventListener('click', () => {
          const isHidden = wordListBody.style.display === 'none' || wordListBody.style.display === '';
          wordListBody.style.display = isHidden ? 'block' : 'none';
          if (wordListToggleText) {
            wordListToggleText.textContent = isHidden ? '(点击折叠 ▴)' : '(点击展开 ▾)';
          }
        });
      }

      // 词库全量清单检索与年级筛选
      const fullGradeFilter = document.getElementById('fullListGradeFilter');
      if (fullGradeFilter) fullGradeFilter.addEventListener('change', () => this.renderFullWordList());

      const fullListSearch = document.getElementById('fullListSearchInput');
      const btnClearFullSearch = document.getElementById('btnClearFullSearch');
      if (fullListSearch) {
        fullListSearch.addEventListener('input', () => {
          if (btnClearFullSearch) {
            btnClearFullSearch.style.display = fullListSearch.value.trim() ? 'block' : 'none';
          }
          this.renderFullWordList();
        });
      }
      if (btnClearFullSearch) {
        btnClearFullSearch.addEventListener('click', () => {
          if (fullListSearch) {
            fullListSearch.value = '';
            fullListSearch.focus();
          }
          btnClearFullSearch.style.display = 'none';
          this.renderFullWordList();
        });
      }

      const btnReset = document.getElementById('btnForceReset');
      if (btnReset) {
        btnReset.addEventListener('click', () => {
          if (confirm('⚠️ 警告：该操作将彻底清空保存在本设备中的所有已记录熟练度、错题本及灵宠经验，确定要重置吗？')) {
            this.storage.clearAllData();
            location.reload();
          }
        });
      }

      // 学习档案导出与导入备份
      const btnExport = document.getElementById('btnExportProgress');
      if (btnExport) {
        btnExport.addEventListener('click', () => {
          const stateData = this.storage.state;
          const jsonString = JSON.stringify(stateData, null, 2);
          const blob = new Blob([jsonString], { type: 'application/json' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          const dateStr = new Date().toISOString().slice(0, 10);
          a.download = `词域探险家_学习档案_${dateStr}.json`;
          document.body.appendChild(a);
          a.click();
          a.remove();
          setTimeout(() => URL.revokeObjectURL(url), 1000);
          alert('✅ 学习档案导出成功！已将包含错题本、星星与进度的备份文件下载到您的设备。');
        });
      }

      const btnImport = document.getElementById('btnImportProgress');
      const importInput = document.getElementById('importFileInput');
      if (btnImport && importInput) {
        btnImport.addEventListener('click', () => {
          importInput.click();
        });
        importInput.addEventListener('change', (e) => {
          const file = e.target.files[0];
          if (!file) return;
          const reader = new FileReader();
          reader.onload = (event) => {
            try {
              const imported = JSON.parse(event.target.result);
              if (imported && typeof imported === 'object') {
                this.storage.state = Object.assign(this.storage.getDefaultState(), imported);
                this.storage.save();
                alert('🎉 学习档案恢复成功！页面即将刷新加载最新进度。');
                location.reload();
              } else {
                alert('⚠️ 导入失败：备份文件格式不正确！');
              }
            } catch (err) {
              alert('⚠️ 导入失败：无法读取备份文件内容。');
            }
          };
          reader.readAsText(file);
        });
      }

      // 词库配置与出词大盘专属事件
      const selVersion = document.getElementById('settingTextbookVersion');
      const savedInd = document.getElementById('versionSavedIndicator');
      if (selVersion) {
        selVersion.addEventListener('change', (e) => {
          const ver = e.target.value;
          this.switchTextbookVersion(ver, false);
          if (savedInd) {
            savedInd.textContent = '● 已选择待应用';
            savedInd.style.color = '#d97706';
          }
        });
      }

      const btnApplyVersion = document.getElementById('btnApplyVersion');
      if (btnApplyVersion && selVersion) {
        btnApplyVersion.addEventListener('click', () => {
          const ver = selVersion.value;
          this.switchTextbookVersion(ver, true);
          if (savedInd) {
            savedInd.textContent = '● 当前生效中 (已保存)';
            savedInd.style.color = '#059669';
          }
          alert(`✅ 教材词库切换成功！\n当前已应用【${selVersion.options[selVersion.selectedIndex].text}】\n本设备已即时永久保存该设置！`);
        });
      }

      const btnExportVocab = document.getElementById('btnExportCurrentVocab');
      if (btnExportVocab) {
        btnExportVocab.addEventListener('click', () => {
          this.exportCurrentVocab();
        });
      }

      const btnDownloadTemplate = document.getElementById('btnDownloadExcelTemplate');
      if (btnDownloadTemplate) {
        btnDownloadTemplate.addEventListener('click', () => {
          this.downloadExcelTemplate();
        });
      }

      const btnCustomVocab = document.getElementById('btnImportCustomVocab');
      const customVocabInput = document.getElementById('customVocabFileInput');
      if (btnCustomVocab && customVocabInput) {
        btnCustomVocab.addEventListener('click', () => customVocabInput.click());
        customVocabInput.addEventListener('change', (e) => {
          const file = e.target.files[0];
          if (!file) return;

          const isExcel = /\.(xlsx|xls|csv)$/i.test(file.name);
          const reader = new FileReader();

          reader.onload = (evt) => {
            try {
              let list = [];
              if (isExcel) {
                if (!window.XLSX) {
                  alert('⚠️ 正在初始化 Excel 引擎，请稍候重试。');
                  return;
                }
                const data = new Uint8Array(evt.target.result);
                const wb = XLSX.read(data, { type: 'array' });
                const firstSheet = wb.Sheets[wb.SheetNames[0]];
                const rawRows = XLSX.utils.sheet_to_json(firstSheet);
                list = rawRows.map((r, i) => {
                  const word = r['英文单词'] || r['单词'] || r['word'] || r['Word'] || '';
                  if (!word) return null;
                  const phonetic = r['国际音标'] || r['音标'] || r['phonetic'] || '';
                  const rawSyl = r['音节切分'] || r['音节拆解'] || r['音节'] || r['syllables'] || '';
                  const syllables = rawSyl.toString().split(/[·\-,\s]+/).filter(Boolean);
                  const chinese = r['规范中文释义'] || r['中文释义'] || r['中文'] || r['释义'] || r['meaning'] || r['chinese'] || '';
                  const grade = r['适用年级'] || r['年级'] || r['grade'] || '自定义';
                  const unit = r['单元/主题'] || r['单元'] || r['unit'] || '专项特训';
                  const example = r['核心例句'] || r['经典例句'] || r['例句'] || r['example'] || '';
                  return {
                    id: 'custom_w_' + (i + 1),
                    word: String(word).trim(),
                    phonetic: String(phonetic).trim(),
                    syllables: syllables.length > 0 ? syllables : [String(word).trim()],
                    chinese: String(chinese).trim(),
                    grade: String(grade).trim(),
                    unit: String(unit).trim(),
                    example: String(example).trim()
                  };
                }).filter(Boolean);
              } else {
                list = JSON.parse(evt.target.result);
              }

              if (Array.isArray(list) && list.length > 0) {
                const defaultName = file.name.replace(/\.(xlsx|xls|csv|json)$/i, '');
                const vocabName = prompt('请输入该自定义词库的显示名称：', defaultName) || defaultName;
                const vocabId = 'custom_' + Date.now();
                if (!this.storage.state.customVocabs) this.storage.state.customVocabs = {};
                this.storage.state.customVocabs[vocabId] = {
                  id: vocabId,
                  name: vocabName,
                  words: list,
                  createdAt: new Date().toLocaleDateString('zh-CN')
                };
                if (!this.storage.state.parentSettings.customVocabIds) this.storage.state.parentSettings.customVocabIds = [];
                this.storage.state.parentSettings.customVocabIds.push(vocabId);
                this.storage.save();

                this.renderCustomVocabManager();
                this.renderParentCustomPools();
                this.refreshChallengePool();
                this.updateGamePool();
                alert(`🎉 成功导入专属词库【${vocabName}】！\n格式：${isExcel ? 'Excel 表格' : 'JSON 格式'}\n共载入 ${list.length} 个单词，并已自动加入家长出题候选池！`);
              } else {
                alert('⚠️ 导入失败：表格中未检测到有效单词，请检查列名是否包含“英文单词”或“中文释义”。');
              }
            } catch (err) {
              console.error(err);
              alert('⚠️ 解析文件失败，请确保格式正确！');
            }
          };

          if (isExcel) {
            reader.readAsArrayBuffer(file);
          } else {
            reader.readAsText(file);
          }
        });
      }

      // 家长出词控制开关绑定
      const cbMistakes = document.getElementById('cbIncludeMistakes');
      if (cbMistakes) {
        cbMistakes.addEventListener('change', (e) => {
          this.storage.state.parentSettings.includeMistakes = e.target.checked;
          this.storage.save();
          this.refreshChallengePool();
          this.updateGamePool();
        });
      }

      const selWordCount = document.getElementById('parentTargetWordCount');
      if (selWordCount) {
        selWordCount.addEventListener('change', (e) => {
          this.storage.state.parentSettings.targetWordCount = e.target.value;
          this.storage.save();
          this.refreshChallengePool();
          this.updateGamePool();
        });
      }

      // 目标时长绑定 (支持 5~60 分钟动态联动顶栏目标显示)
      const selTargetDuration = document.getElementById('parentTargetDuration');
      if (selTargetDuration) {
        if (this.storage.state.parentSettings.targetDuration) {
          selTargetDuration.value = this.storage.state.parentSettings.targetDuration;
        }
        const updateHudTarget = (val) => {
          const m = parseInt(val) || 60;
          const hudTarget = document.getElementById('hudTargetDisplay');
          if (hudTarget) hudTarget.textContent = `/ ${String(m).padStart(2, '0')}:00`;
        };
        updateHudTarget(selTargetDuration.value);
        selTargetDuration.addEventListener('change', (e) => {
          this.storage.state.parentSettings.targetDuration = e.target.value;
          updateHudTarget(e.target.value);
          this.storage.save();
        });
      }

      const cb7Days = document.getElementById('cbPreventRepeat7Days');
      if (cb7Days) {
        cb7Days.addEventListener('change', (e) => {
          this.storage.state.parentSettings.preventRepeat7Days = e.target.checked;
          this.storage.save();
          this.refreshChallengePool();
          this.updateGamePool();
        });
      }

      const btnToggleCandidate = document.getElementById('btnToggleCandidateAccordion');
      const candidateBody = document.getElementById('candidateAccordionBody');
      const candidateArrow = document.getElementById('candidateAccordionToggleArrow');
      if (btnToggleCandidate && candidateBody) {
        btnToggleCandidate.addEventListener('click', () => {
          const isHidden = candidateBody.style.display === 'none' || candidateBody.style.display === '';
          candidateBody.style.display = isHidden ? 'block' : 'none';
          if (candidateArrow) candidateArrow.textContent = isHidden ? '▴' : '▾';
        });
      }

      // 候选池分类筛选与搜索联动
      const candidateCatSel = document.getElementById('candidateFilterCategory');
      if (candidateCatSel) {
        candidateCatSel.addEventListener('change', () => this.filterCandidateList());
      }
      const candidateSearch = document.getElementById('candidateListSearchInput');
      if (candidateSearch) {
        candidateSearch.addEventListener('input', () => this.filterCandidateList());
      }

      // 全选当前筛选单词
      const cbSelectAllFiltered = document.getElementById('cbSelectAllFiltered');
      if (cbSelectAllFiltered) {
        cbSelectAllFiltered.addEventListener('change', (e) => {
          const check = e.target.checked;
          const chips = document.querySelectorAll('#candidateWordListGrid .candidate-chip');
          chips.forEach(chip => {
            if (chip.style.display !== 'none') {
              const cb = chip.querySelector('.word-select-cb');
              if (cb) {
                cb.checked = check;
                chip.classList.toggle('selected', check);
              }
            }
          });
          this.updateCandidateSelectedToolbar();
        });
      }

      // 导出当前筛选词单为 Excel
      const btnExportFiltered = document.getElementById('btnExportFilteredCandidate');
      if (btnExportFiltered) {
        btnExportFiltered.addEventListener('click', () => {
          const visibleWords = [];
          const chips = document.querySelectorAll('#candidateWordListGrid .candidate-chip');
          chips.forEach(chip => {
            if (chip.style.display !== 'none') {
              const wStr = chip.getAttribute('data-word');
              const found = (this.currentCandidateList || []).find(w => w.word === wStr);
              if (found) visibleWords.push(found);
            }
          });
          const cat = candidateCatSel ? candidateCatSel.value : 'all';
          const catName = cat === 'all' ? '出词候选' : (cat === 'mistake' ? '错题专项' : (cat + '年级'));
          this.exportWordsToExcel(visibleWords, `词域探险家_${catName}核心词表_${new Date().toISOString().slice(0, 10)}.xlsx`);
        });
      }

      // 导出已手动打勾选中的单词
      const btnExportSelected = document.getElementById('btnExportSelectedWords');
      if (btnExportSelected) {
        btnExportSelected.addEventListener('click', () => {
          const selectedWords = [];
          const checkedCbs = document.querySelectorAll('#candidateWordListGrid .word-select-cb:checked');
          checkedCbs.forEach(cb => {
            const wStr = cb.getAttribute('data-word');
            const found = (this.currentCandidateList || []).find(w => w.word === wStr);
            if (found) selectedWords.push(found);
          });
          this.exportWordsToExcel(selectedWords, `词域探险家_自选勾选词表_${new Date().toISOString().slice(0, 10)}.xlsx`);
        });
      }

      // 保存已勾选单词为专属新词单并联动回词源范围
      const btnSaveSelected = document.getElementById('btnSaveSelectedAsCustomVocab');
      if (btnSaveSelected) {
        btnSaveSelected.addEventListener('click', () => {
          const selectedWords = [];
          const checkedCbs = document.querySelectorAll('#candidateWordListGrid .word-select-cb:checked');
          checkedCbs.forEach(cb => {
            const wStr = cb.getAttribute('data-word');
            const found = (this.currentCandidateList || []).find(w => w.word === wStr);
            if (found) selectedWords.push(found);
          });
          if (selectedWords.length === 0) {
            alert('⚠️ 请先在词签前打勾勾选至少 1 个单词！');
            return;
          }
          const defaultName = `自选特训包 (${selectedWords.length}词)`;
          const vocabName = prompt('请输入新专属特训词单的名称：', defaultName);
          if (!vocabName || !vocabName.trim()) return;

          const vocabId = 'custom_' + Date.now();
          if (!this.storage.state.customVocabs) this.storage.state.customVocabs = {};
          this.storage.state.customVocabs[vocabId] = {
            id: vocabId,
            name: vocabName.trim(),
            words: selectedWords,
            createdAt: new Date().toLocaleDateString('zh-CN')
          };
          if (!this.storage.state.parentSettings.customVocabIds) this.storage.state.parentSettings.customVocabIds = [];
          if (!this.storage.state.parentSettings.customVocabIds.includes(vocabId)) {
            this.storage.state.parentSettings.customVocabIds.push(vocabId);
          }
          this.storage.save();

          this.renderParentCustomPools();
          this.refreshChallengePool();
          this.updateGamePool();
          if (typeof this.renderCustomVocabManager === 'function') {
            this.renderCustomVocabManager();
          }

          alert(`🎉 成功创建专属特训词单【${vocabName.trim()}】！
共收录 ${selectedWords.length} 个单词，已自动加入上方“词源范围”中，您可以随时单独勾选或混合练习！`);
        });
      }

      // 清空勾选
      const btnClearSelected = document.getElementById('btnClearSelectedWords');
      if (btnClearSelected) {
        btnClearSelected.addEventListener('click', () => {
          document.querySelectorAll('#candidateWordListGrid .word-select-cb').forEach(cb => {
            cb.checked = false;
            cb.closest('.candidate-chip').classList.remove('selected');
          });
          if (cbSelectAllFiltered) cbSelectAllFiltered.checked = false;
          this.updateCandidateSelectedToolbar();
        });
      }

      // 年级快捷全选 / 清空
      const btnSelAllGrades = document.getElementById('btnSelectAllGrades');
      if (btnSelAllGrades) {
        btnSelAllGrades.addEventListener('click', () => {
          document.querySelectorAll('input[name="parentGradeCombo"]').forEach(cb => cb.checked = true);
          this.storage.state.parentSettings.grades = [1, 2, 3, 4, 5, 6];
          this.storage.save();
          this.refreshChallengePool();
          this.updateGamePool();
        });
      }
      const btnClrAllGrades = document.getElementById('btnClearAllGrades');
      if (btnClrAllGrades) {
        btnClrAllGrades.addEventListener('click', () => {
          document.querySelectorAll('input[name="parentGradeCombo"]').forEach(cb => cb.checked = false);
          this.storage.state.parentSettings.grades = [];
          this.storage.save();
          this.refreshChallengePool();
          this.updateGamePool();
        });
      }

      // 家长看板直接上传特训清单
      const btnParentUpload = document.getElementById('btnParentDirectUpload');
      const parentUploadInput = document.getElementById('parentDirectUploadInput');
      if (btnParentUpload && parentUploadInput) {
        btnParentUpload.addEventListener('click', () => parentUploadInput.click());
        parentUploadInput.addEventListener('change', (e) => {
          const file = e.target.files[0];
          if (!file) return;

          const isExcel = /\.(xlsx|xls|csv)$/i.test(file.name);
          const reader = new FileReader();

          reader.onload = (evt) => {
            try {
              let list = [];
              if (isExcel) {
                if (!window.XLSX) {
                  alert('⚠️ 正在初始化 Excel 引擎，请稍候重试。');
                  return;
                }
                const data = new Uint8Array(evt.target.result);
                const wb = XLSX.read(data, { type: 'array' });
                const firstSheet = wb.Sheets[wb.SheetNames[0]];
                const rawRows = XLSX.utils.sheet_to_json(firstSheet);
                list = rawRows.map((r, i) => {
                  const word = r['英文单词'] || r['单词'] || r['word'] || r['Word'] || '';
                  if (!word) return null;
                  const phonetic = r['国际音标'] || r['音标'] || r['phonetic'] || '';
                  const rawSyl = r['音节切分'] || r['音节拆解'] || r['音节'] || r['syllables'] || '';
                  const syllables = rawSyl.toString().split(/[·\-,\s]+/).filter(Boolean);
                  const chinese = r['规范中文释义'] || r['中文释义'] || r['中文'] || r['释义'] || r['meaning'] || r['chinese'] || '';
                  const grade = r['适用年级'] || r['年级'] || r['grade'] || '特训清单';
                  const unit = r['单元/主题'] || r['单元'] || r['unit'] || '专属特训';
                  const example = r['核心例句'] || r['经典例句'] || r['例句'] || r['example'] || '';
                  return {
                    id: 'custom_w_' + (i + 1),
                    word: String(word).trim(),
                    phonetic: String(phonetic).trim(),
                    syllables: syllables.length > 0 ? syllables : [String(word).trim()],
                    chinese: String(chinese).trim(),
                    grade: String(grade).trim(),
                    unit: String(unit).trim(),
                    example: String(example).trim()
                  };
                }).filter(Boolean);
              } else {
                list = JSON.parse(evt.target.result);
              }

              if (Array.isArray(list) && list.length > 0) {
                const defaultName = file.name.replace(/\.(xlsx|xls|csv|json)$/i, '');
                const vocabName = prompt('请输入该特训词单的名称：', defaultName) || defaultName;
                const vocabId = 'custom_' + Date.now();
                if (!this.storage.state.customVocabs) this.storage.state.customVocabs = {};
                this.storage.state.customVocabs[vocabId] = {
                  id: vocabId,
                  name: vocabName,
                  words: list,
                  createdAt: new Date().toLocaleDateString('zh-CN')
                };
                if (!this.storage.state.parentSettings.customVocabIds) this.storage.state.parentSettings.customVocabIds = [];
                this.storage.state.parentSettings.customVocabIds.push(vocabId);
                this.storage.save();

                this.renderParentCustomPools();
                this.refreshChallengePool();
                this.updateGamePool();
                if (typeof this.renderCustomVocabManager === 'function') {
                  this.renderCustomVocabManager();
                }

                alert(`🎉 成功上传专属特训词单【${vocabName}】！\n共载入 ${list.length} 个单词，已自动加入上方“词源范围”中并已勾选！`);
              } else {
                alert('⚠️ 导入失败：表格中未检测到有效单词，请检查列名是否包含“英文单词”或“中文释义”。');
              }
            } catch (err) {
              console.error(err);
              alert('⚠️ 解析文件出错，请确保是标准的 Excel (.xlsx/.csv) 或 JSON 格式文件。');
            } finally {
              parentUploadInput.value = '';
            }
          };

          if (isExcel) {
            reader.readAsArrayBuffer(file);
          } else {
            reader.readAsText(file, 'utf-8');
          }
        });
      }

      // 适用场景联动
      const cbTraining = document.getElementById('cbApplyToTraining');
      if (cbTraining) {
        cbTraining.addEventListener('change', () => {
          this.refreshChallengePool();
        });
      }
      const cbGames = document.getElementById('cbApplyToGames');
      if (cbGames) {
        cbGames.addEventListener('change', () => {
          this.updateGamePool();
        });
      }

      const btnUpgradeJunior = document.getElementById('btnUpgradeJunior');
      if (btnUpgradeJunior) {
        btnUpgradeJunior.addEventListener('click', () => {
          alert('🎉 初中 7~9 年级扩展词库接口激活成功！已准备好 1600 考纲标准核心词汇。由于当前是小学阶段挑战，初中拓展词已加入扩展备选题库中！');
        });
      }

      const btnUpgradeSenior = document.getElementById('btnUpgradeSenior');
      if (btnUpgradeSenior) {
        btnUpgradeSenior.addEventListener('click', () => {
          alert('🎉 高中 1~3 年级扩展词库接口激活成功！高考 3500 核心词库与语法搭配模块已就绪。');
        });
      }

      const btnExportSettings = document.getElementById('btnExportSettings');
      if (btnExportSettings && btnExport) {
        btnExportSettings.addEventListener('click', () => btnExport.click());
      }
      const btnImportSettings = document.getElementById('btnImportSettings');
      if (btnImportSettings && btnImport) {
        btnImportSettings.addEventListener('click', () => btnImport.click());
      }
    }

    switchView(viewName) {
      this.currentView = viewName;
      document.querySelectorAll('.sub-nav-btn').forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-view') === viewName);
      });
      document.querySelectorAll('.view-panel').forEach(panel => {
        panel.classList.toggle('active', panel.id === `view-${viewName}`);
      });

      if (viewName === 'training') {
        if (this.currentStep) this.setStep(this.currentStep, false);
        else this.setStep(1, false);
      } else if (viewName === 'games') {
        this.updateGamePool();
        this.switchGameTab(this.activeGameTab);
      } else if (viewName === 'mistakes') {
        this.renderMistakesTable();
      } else if (viewName === 'analytics') {
        this.renderParentDailyReport();
        this.renderGradeAnalytics();
        this.renderFullWordList();
      }
    }
  }


  // ================= 8. 全局荧光粒子与爆裂物理引擎 (Global Neon Particle Engine) =================
  class GlobalNeonParticleEngine {
    constructor() {
      this.canvas = document.getElementById('globalParticleCanvas');
      if (!this.canvas) return;
      this.ctx = this.canvas.getContext('2d');
      this.particles = [];
      this.rings = [];
      this.resize();
      window.addEventListener('resize', () => this.resize());
      this.bindEvents();
      this.animate();
    }

    resize() {
      this.canvas.width = window.innerWidth;
      this.canvas.height = window.innerHeight;
    }

    getPalette() {
      const pet = (window.app && window.app.storage) ? window.app.storage.state.pet : 'sprite';
      if (pet === 'drake') {
        return ['#ef4444', '#f59e0b', '#fbbf24', '#f97316', '#ffedd5'];
      } else if (pet === 'fox') {
        return ['#38bdf8', '#818cf8', '#a855f7', '#60a5fa', '#e0e7ff'];
      }
      return ['#10b981', '#34d399', '#6ee7b7', '#fde047', '#a7f3d0'];
    }

    spawnBurst(x, y) {
      const colors = this.getPalette();
      this.rings.push({ x, y, r: 8, maxR: 70, opacity: 0.85, color: colors[0] });

      const count = 22;
      for (let i = 0; i < count; i++) {
        const angle = (Math.PI * 2 / count) * i + (Math.random() - 0.5) * 0.4;
        const speed = Math.random() * 5 + 3;
        this.particles.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          r: Math.random() * 3 + 2,
          life: 1,
          decay: Math.random() * 0.025 + 0.02,
          color: colors[Math.floor(Math.random() * colors.length)]
        });
      }
    }

    spawnTrail(x, y) {
      const colors = this.getPalette();
      this.particles.push({
        x: x + (Math.random() - 0.5) * 6,
        y: y + (Math.random() - 0.5) * 6,
        vx: (Math.random() - 0.5) * 0.8,
        vy: (Math.random() - 0.5) * 0.8 - 0.5,
        r: Math.random() * 2 + 1,
        life: 0.8,
        decay: 0.04,
        color: colors[Math.floor(Math.random() * colors.length)]
      });
    }

    bindEvents() {
      window.addEventListener('pointerdown', (e) => {
        // 关键改动：仅当欢迎启程幕处于显示状态时才触发荧光粒子，进入主系统后彻底静默！
        const splash = document.getElementById('splashScreen');
        if (splash && splash.style.display !== 'none' && !splash.classList.contains('hidden')) {
          this.spawnBurst(e.clientX, e.clientY);
        }
      });

      let lastMove = 0;
      window.addEventListener('pointermove', (e) => {
        const splash = document.getElementById('splashScreen');
        if (splash && splash.style.display !== 'none' && !splash.classList.contains('hidden')) {
          const now = Date.now();
          if (now - lastMove > 35) {
            this.spawnTrail(e.clientX, e.clientY);
            lastMove = now;
          }
        }
      });
    }

    animate() {
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

      for (let i = this.rings.length - 1; i >= 0; i--) {
        const ring = this.rings[i];
        ring.r += 3.5;
        ring.opacity -= 0.04;
        if (ring.opacity <= 0) {
          this.rings.splice(i, 1);
          continue;
        }
        this.ctx.save();
        this.ctx.beginPath();
        this.ctx.arc(ring.x, ring.y, ring.r, 0, Math.PI * 2);
        this.ctx.strokeStyle = ring.color;
        this.ctx.globalAlpha = ring.opacity;
        this.ctx.lineWidth = 2.5;
        this.ctx.shadowBlur = 12;
        this.ctx.shadowColor = ring.color;
        this.ctx.stroke();
        this.ctx.restore();
      }

      for (let i = this.particles.length - 1; i >= 0; i--) {
        const p = this.particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.vx *= 0.96;
        p.vy *= 0.96;
        p.life -= p.decay;

        if (p.life <= 0) {
          this.particles.splice(i, 1);
          continue;
        }

        this.ctx.save();
        this.ctx.beginPath();
        this.ctx.arc(p.x, p.y, p.r * p.life, 0, Math.PI * 2);
        this.ctx.fillStyle = p.color;
        this.ctx.globalAlpha = p.life * 0.9;
        this.ctx.shadowBlur = 8;
        this.ctx.shadowColor = p.color;
        this.ctx.fill();
        this.ctx.restore();
      }

      requestAnimationFrame(() => this.animate());
    }
  }

  window.addEventListener('DOMContentLoaded', () => {
    window.neonParticles = new GlobalNeonParticleEngine();

    window.app = new WordExplorerApp();
  });
})();
