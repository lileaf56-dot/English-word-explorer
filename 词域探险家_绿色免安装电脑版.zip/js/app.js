import { RAW_VOCABULARY, DEFAULT_TEXTBOOK_INFO } from './data/pep_words.js';
import { sound } from './audio.js';
import { storage } from './storage.js';

class WordExplorerApp {
  constructor() {
    this.words = [...RAW_VOCABULARY];
    this.currentView = 'training'; // 'training' | 'analytics' | 'mistakes' | 'settings'
    this.currentStep = 1; // 1: 複習喚醒, 2: 核心攻堅, 3: 拼寫對決, 4: 戰報結算
    
    // 當前學習佇列與題目
    this.trainingQueue = [];
    this.currentIndex = 0;
    this.currentWord = null;
    this.typedLetters = [];
    this.combo = 0;
    this.sessionCorrect = 0;
    this.sessionErrors = 0;

    // 定時器
    this.timerInterval = null;

    this.initElements();
    this.bindEvents();
    this.startStudyTimer();
    this.refreshTopBar();
    this.renderCurrentView();
  }

  initElements() {
    // 頂部導航
    this.navBtns = document.querySelectorAll('.nav-tab-btn');
    this.views = document.querySelectorAll('.view-panel');
    
    // HUD 狀態
    this.elTimeSpent = document.getElementById('hudTimeSpent');
    this.elCombo = document.getElementById('hudCombo');
    this.elMasteredCount = document.getElementById('hudMasteredCount');

    // 業務向導
    this.stepNodes = document.querySelectorAll('.step-node');

    // 戰鬥訓練元素
    this.elGradeTag = document.getElementById('battleGradeTag');
    this.elUnitTag = document.getElementById('battleUnitTag');
    this.elPhonetic = document.getElementById('battlePhonetic');
    this.elMeaning = document.getElementById('battleMeaning');
    this.elExample = document.getElementById('battleExample');
    this.elSlots = document.getElementById('letterSlots');
    this.elAudioBtn = document.getElementById('btnPlayAudio');
    this.elAudioSlowBtn = document.getElementById('btnPlaySlowAudio');
    this.elSkipBtn = document.getElementById('btnSkipWord');
    this.elArena = document.querySelector('.battle-arena');

    // 鍵盤
    this.kbContainer = document.getElementById('onScreenKeyboard');

    // 看板元素
    this.elGradeGrid = document.getElementById('gradeAnalyticsGrid');
    this.elWordTableBody = document.getElementById('wordTableBody');
    this.elFilterGrade = document.getElementById('filterGradeSelect');
    this.elFilterSearch = document.getElementById('filterSearchInput');

    // 錯題本元素
    this.elMistakeTableBody = document.getElementById('mistakeTableBody');
    this.elMistakeCount = document.getElementById('mistakeCountBadge');
  }

  bindEvents() {
    // 頂部標籤頁切換
    this.navBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const targetView = btn.dataset.view;
        this.switchView(targetView);
      });
    });

    // 業務向導節點點擊
    this.stepNodes.forEach(node => {
      node.addEventListener('click', () => {
        const step = parseInt(node.dataset.step, 10);
        this.setStep(step);
      });
    });

    // 朗讀按鈕
    if (this.elAudioBtn) {
      this.elAudioBtn.addEventListener('click', () => {
        if (this.currentWord) sound.speak(this.currentWord.word, 0.9);
      });
    }
    if (this.elAudioSlowBtn) {
      this.elAudioSlowBtn.addEventListener('click', () => {
        if (this.currentWord) sound.speak(this.currentWord.word, 0.6);
      });
    }

    // 跳過 / 提示
    if (this.elSkipBtn) {
      this.elSkipBtn.addEventListener('click', () => {
        this.handleSkip();
      });
    }

    // 軟鍵盤點擊代理
    if (this.kbContainer) {
      this.kbContainer.addEventListener('click', (e) => {
        const keyEl = e.target.closest('.kb-key');
        if (!keyEl) return;
        const letter = keyEl.dataset.key;
        if (letter === 'BACKSPACE') {
          this.popLetter();
        } else if (letter === 'CLEAR') {
          this.clearLetters();
        } else if (letter) {
          this.pushLetter(letter.toLowerCase());
        }
      });
    }

    // 實體鍵盤監聽
    window.addEventListener('keydown', (e) => {
      if (this.currentView !== 'training') return;
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

      if (e.key === 'Backspace') {
        this.popLetter();
      } else if (e.key === 'Escape') {
        this.clearLetters();
      } else if (e.key === ' ' || e.key === 'Enter') {
        if (this.currentWord) sound.speak(this.currentWord.word);
      } else if (/^[a-zA-Z]$/.test(e.key)) {
        this.pushLetter(e.key.toLowerCase());
      }
    });

    // 表格篩選交互
    if (this.elFilterGrade) {
      this.elFilterGrade.addEventListener('change', () => this.renderWordTable());
    }
    if (this.elFilterSearch) {
      this.elFilterSearch.addEventListener('input', () => this.renderWordTable());
    }

    // 家長年級多選監聽
    const parentCheckboxes = document.querySelectorAll('input[name="parentGradeFilter"]');
    parentCheckboxes.forEach(cb => {
      cb.addEventListener('change', () => {
        const selected = Array.from(parentCheckboxes)
          .filter(c => c.checked)
          .map(c => parseInt(c.value, 10));
        if (selected.length === 0) {
          cb.checked = true; // 至少保留一個年級
          return;
        }
        storage.setActiveGrades(selected);
        this.buildTrainingQueue();
        this.renderGradeAnalytics();
      });
    });

    // 打印與導出清單
    const btnPrint = document.getElementById('btnPrintWordList');
    if (btnPrint) {
      btnPrint.addEventListener('click', () => window.print());
    }

    // 重置學習數據 (危險操作強警示)
    const btnReset = document.getElementById('btnResetData');
    if (btnReset) {
      btnReset.addEventListener('click', () => {
        if (confirm('確定要清空所有已記錄的背詞熟練度與錯題本嗎？此操作不可逆。')) {
          localStorage.clear();
          location.reload();
        }
      });
    }
  }

  // ================= 視圖路由 =================
  switchView(viewName) {
    this.currentView = viewName;
    this.navBtns.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.view === viewName);
    });
    this.views.forEach(view => {
      view.classList.toggle('active', view.id === `view-${viewName}`);
    });
    this.renderCurrentView();
  }

  renderCurrentView() {
    if (this.currentView === 'training') {
      if (this.trainingQueue.length === 0) {
        this.buildTrainingQueue();
      }
      this.renderCurrentWord();
    } else if (this.currentView === 'analytics') {
      this.renderGradeAnalytics();
      this.renderWordTable();
    } else if (this.currentView === 'mistakes') {
      this.renderMistakeList();
    }
    this.refreshTopBar();
  }

  // ================= 訓練流程控制 =================
  setStep(step) {
    this.currentStep = step;
    this.stepNodes.forEach(node => {
      const s = parseInt(node.dataset.step, 10);
      node.classList.toggle('active', s === step);
      node.classList.toggle('done', s < step);
    });
    this.buildTrainingQueue();
    this.renderCurrentWord();
  }

  buildTrainingQueue() {
    const activeGrades = storage.getActiveGrades();
    const candidateWords = this.words.filter(w => activeGrades.includes(w.grade));

    if (this.currentStep === 1) {
      // 階段一: 昨日回顧 + 錯題優先
      const mistakes = storage.getAllMistakes(candidateWords);
      this.trainingQueue = mistakes.length >= 6 ? mistakes.slice(0, 10) : candidateWords.slice(0, 10);
    } else if (this.currentStep === 2) {
      // 階段二: 核心攻堅 (抽取當前年級未精通詞)
      const needLearn = candidateWords.filter(w => {
        const rec = storage.getWordRecord(w.id);
        return rec.status !== 'mastered';
      });
      this.trainingQueue = (needLearn.length > 0 ? needLearn : candidateWords).slice(0, 12);
    } else if (this.currentStep === 3) {
      // 階段三: 試煉首領戰 (隨機混戰抽查)
      this.trainingQueue = [...candidateWords].sort(() => Math.random() - 0.5).slice(0, 15);
    } else {
      // 階段四: 結算
      this.trainingQueue = [];
    }

    this.currentIndex = 0;
    this.combo = 0;
  }

  renderCurrentWord() {
    if (this.currentStep === 4 || this.currentIndex >= this.trainingQueue.length) {
      this.renderSessionReport();
      return;
    }

    this.currentWord = this.trainingQueue[this.currentIndex];
    this.typedLetters = [];

    // 元數據展示
    this.elGradeTag.textContent = `${this.currentWord.grade} 年級`;
    this.elUnitTag.textContent = this.currentWord.unit || '核心模組';
    this.elPhonetic.textContent = this.currentWord.phonetic;
    this.elMeaning.textContent = this.currentWord.meaning;
    this.elExample.textContent = this.currentWord.example || '';

    // 生成字母插槽
    this.renderLetterSlots();

    // 自動播放發音一次加深印象
    sound.speak(this.currentWord.word, 0.9);
  }

  renderLetterSlots() {
    this.elSlots.innerHTML = '';
    const target = this.currentWord.word.toLowerCase();
    
    for (let i = 0; i < target.length; i++) {
      const slot = document.createElement('div');
      slot.className = 'letter-slot';
      if (i < this.typedLetters.length) {
        slot.textContent = this.typedLetters[i];
        slot.classList.add('filled');
      } else if (i === this.typedLetters.length) {
        slot.classList.add('current');
      }
      this.elSlots.appendChild(slot);
    }
  }

  pushLetter(char) {
    if (!this.currentWord) return;
    const target = this.currentWord.word.toLowerCase();
    const curIdx = this.typedLetters.length;

    if (curIdx >= target.length) return;

    const expectedChar = target[curIdx];

    if (char === expectedChar) {
      // 輸入正確
      this.typedLetters.push(char);
      sound.playLaser();
      this.renderLetterSlots();

      // 檢查是否完整拼完
      if (this.typedLetters.length === target.length) {
        this.handleWordSuccess();
      }
    } else {
      // 輸入錯誤
      sound.playError();
      this.handleWordError();
    }
  }

  popLetter() {
    if (this.typedLetters.length > 0) {
      this.typedLetters.pop();
      this.renderLetterSlots();
    }
  }

  clearLetters() {
    this.typedLetters = [];
    this.renderLetterSlots();
  }

  handleWordSuccess() {
    this.combo += 1;
    this.sessionCorrect += 1;
    sound.playCorrect();
    if (this.combo > 1 && this.combo % 3 === 0) {
      sound.playCombo();
    }

    // 寫入記憶存檔
    storage.recordAttempt(this.currentWord.id, true);
    this.refreshTopBar();

    // 閃綠反饋並下一題
    this.elArena.style.borderColor = 'var(--emerald-green)';
    setTimeout(() => {
      this.elArena.style.borderColor = 'var(--border-color)';
      this.currentIndex += 1;
      this.renderCurrentWord();
    }, 600);
  }

  handleWordError() {
    this.combo = 0;
    this.sessionErrors += 1;
    storage.recordAttempt(this.currentWord.id, false);
    this.refreshTopBar();

    // 標紅槽位震動反饋
    const slots = this.elSlots.querySelectorAll('.letter-slot');
    if (slots[this.typedLetters.length]) {
      slots[this.typedLetters.length].classList.add('error');
    }
    this.elArena.style.borderColor = 'var(--crimson-red)';
    setTimeout(() => {
      this.elArena.style.borderColor = 'var(--border-color)';
      this.renderLetterSlots();
    }, 400);
  }

  handleSkip() {
    if (!this.currentWord) return;
    // 提示完整單詞並計為失誤
    this.typedLetters = this.currentWord.word.toLowerCase().split('');
    this.renderLetterSlots();
    sound.speak(this.currentWord.word);
    storage.recordAttempt(this.currentWord.id, false);
    setTimeout(() => {
      this.currentIndex += 1;
      this.renderCurrentWord();
    }, 1200);
  }

  renderSessionReport() {
    this.elGradeTag.textContent = '今日結算';
    this.elUnitTag.textContent = '戰報總結';
    this.elPhonetic.textContent = 'ALL MISSIONS CLEARED';
    this.elMeaning.textContent = `恭喜完成！正確 ${this.sessionCorrect} 詞 · 需複習 ${this.sessionErrors} 詞`;
    this.elExample.textContent = '連續攻克單詞可大幅提升記憶保持率，請繼續保持！';
    this.elSlots.innerHTML = `
      <div style="text-align: center; margin: 16px 0;">
        <button class="btn-tactical primary" id="btnRestartSession">開啟下一輪挑戰</button>
      </div>
    `;
    const btnRestart = document.getElementById('btnRestartSession');
    if (btnRestart) {
      btnRestart.addEventListener('click', () => {
        this.setStep(1);
      });
    }
    sound.playLevelUp();
  }

  // ================= 看板與年級掌握度渲染 =================
  renderGradeAnalytics() {
    const analytics = storage.getGradeAnalytics(this.words);
    const activeGrades = storage.getActiveGrades();

    // 渲染家長年級卡片
    this.elGradeGrid.innerHTML = analytics.map(item => {
      const isSelected = activeGrades.includes(item.grade);
      const rateClass = item.masteryRate >= 70 ? 'high' : item.masteryRate >= 40 ? 'mid' : 'low';
      return `
        <div class="grade-card" style="opacity: ${isSelected ? '1' : '0.45'}">
          <div class="grade-card-header">
            <span class="grade-title">${item.grade} 年級詞彙庫</span>
            <span class="grade-rate-badge ${rateClass}">${item.masteryRate}% 掌握</span>
          </div>
          <div class="progress-track-outer">
            <div class="progress-fill ${rateClass}" style="width: ${item.masteryRate}%"></div>
          </div>
          <div class="grade-stats-breakdown">
            <span>總詞數: <strong>${item.total}</strong></span>
            <span style="color: var(--emerald-green)">精通: ${item.mastered}</span>
            <span style="color: var(--energy-orange)">薄弱: ${item.weakList.length}</span>
            <span style="color: var(--text-muted)">未測: ${item.unlearned}</span>
          </div>
          <div class="grade-card-footer">
            <span style="font-size: 12px; color: var(--text-secondary)">
              ${item.weakList.length > 0 ? `需消滅錯題 ${item.weakList.length} 個` : '狀態良好'}
            </span>
            <button class="btn-tactical secondary" style="padding: 4px 10px; font-size: 12px;" onclick="window.app.startGradeDrill(${item.grade})">
              專項突擊
            </button>
          </div>
        </div>
      `;
    }).join('');

    // 同步勾選狀態
    const parentCheckboxes = document.querySelectorAll('input[name="parentGradeFilter"]');
    parentCheckboxes.forEach(cb => {
      cb.checked = activeGrades.includes(parseInt(cb.value, 10));
    });
  }

  startGradeDrill(grade) {
    storage.setActiveGrades([grade]);
    this.switchView('training');
    this.setStep(2);
  }

  renderWordTable() {
    const gradeFilter = this.elFilterGrade.value;
    const searchFilter = (this.elFilterSearch.value || '').trim().toLowerCase();

    let list = this.words;
    if (gradeFilter !== 'all') {
      list = list.filter(w => w.grade === parseInt(gradeFilter, 10));
    }
    if (searchFilter) {
      list = list.filter(w => 
        w.word.toLowerCase().includes(searchFilter) ||
        w.meaning.includes(searchFilter)
      );
    }

    this.elWordTableBody.innerHTML = list.map((w, index) => {
      const rec = storage.getWordRecord(w.id);
      let statusHtml = '<span class="status-pill unlearned">未學習</span>';
      if (rec.status === 'mastered') {
        statusHtml = '<span class="status-pill mastered">已精通</span>';
      } else if (rec.status === 'familiar') {
        statusHtml = '<span class="status-pill familiar">熟練</span>';
      } else if (rec.status === 'learning') {
        statusHtml = '<span class="status-pill learning">學習中</span>';
      }

      return `
        <tr>
          <td class="align-center" style="font-family: var(--font-code); color: var(--text-muted);">${index + 1}</td>
          <td class="align-left">
            <span class="word-link" onclick="window.app.speakWord('${w.word}')">${w.word}</span>
          </td>
          <td class="align-left" style="font-family: var(--font-code); color: var(--neon-cyan);">${w.phonetic}</td>
          <td class="align-center" style="color: var(--text-secondary); font-size: 12px;">${w.pos}</td>
          <td class="align-left">${w.meaning}</td>
          <td class="align-center">${w.grade} 年級</td>
          <td class="align-center">${statusHtml}</td>
          <td class="align-right" style="font-family: var(--font-code);">${rec.errorCount}</td>
          <td class="align-center">
            <div class="action-icon-group">
              <button class="icon-btn" title="朗讀單詞" aria-label="朗讀單詞" onclick="window.app.speakWord('${w.word}')">
                🔊
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  renderMistakeList() {
    const mistakes = storage.getAllMistakes(this.words);
    if (this.elMistakeCount) {
      this.elMistakeCount.textContent = `${mistakes.length} 個待消滅`;
    }

    if (mistakes.length === 0) {
      this.elMistakeTableBody.innerHTML = `
        <tr>
          <td colspan="8" class="align-center" style="padding: 32px; color: var(--text-secondary);">
            太棒了！當前沒有任何錯題記錄，所有年級表現優異。
          </td>
        </tr>
      `;
      return;
    }

    this.elMistakeTableBody.innerHTML = mistakes.map((w, index) => {
      return `
        <tr>
          <td class="align-center" style="font-family: var(--font-code); color: var(--text-muted);">${index + 1}</td>
          <td class="align-left">
            <span class="word-link" onclick="window.app.speakWord('${w.word}')">${w.word}</span>
          </td>
          <td class="align-left" style="font-family: var(--font-code); color: var(--neon-cyan);">${w.phonetic}</td>
          <td class="align-left">${w.meaning}</td>
          <td class="align-center">${w.grade} 年級</td>
          <td class="align-right" style="color: var(--crimson-red); font-weight: 700; font-family: var(--font-code);">${w.record.errorCount} 次</td>
          <td class="align-center" style="color: var(--text-muted); font-size: 12px;">
            ${new Date(w.record.lastSeen).toLocaleDateString()}
          </td>
          <td class="align-center">
            <div class="action-icon-group">
              <button class="icon-btn" title="發音" aria-label="發音" onclick="window.app.speakWord('${w.word}')">🔊</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  speakWord(text) {
    sound.speak(text);
  }

  // ================= 頂部狀態與學習計時器 =================
  startStudyTimer() {
    this.timerInterval = setInterval(() => {
      storage.addStudySeconds(1);
      this.refreshTopBar();
    }, 1000);
  }

  refreshTopBar() {
    const minutes = Math.floor(storage.dailyLog.studiedSeconds / 60);
    const secs = storage.dailyLog.studiedSeconds % 60;
    const timeStr = `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    
    if (this.elTimeSpent) {
      this.elTimeSpent.textContent = `${timeStr} / 60:00`;
    }
    if (this.elCombo) {
      this.elCombo.textContent = `${this.combo} 階`;
    }

    // 計算精通總詞數
    const analytics = storage.getGradeAnalytics(this.words);
    const totalMastered = analytics.reduce((acc, cur) => acc + cur.mastered, 0);
    if (this.elMasteredCount) {
      this.elMasteredCount.textContent = `${totalMastered} / ${this.words.length}`;
    }
  }
}

// 掛載全域以便按鈕內聯回調
window.addEventListener('DOMContentLoaded', () => {
  window.app = new WordExplorerApp();
});
