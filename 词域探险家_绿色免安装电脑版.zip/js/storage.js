/**
 * 本地數據持久化與艾賓浩斯記憶引擎 (Storage & Spaced Repetition Engine)
 * 100% 離線，純本地儲存 (LocalStorage)，支持導出備份與跨設備轉移
 */

const STORAGE_KEYS = {
  WORD_STATS: 'word_explorer_stats_v1',
  SETTINGS: 'word_explorer_settings_v1',
  DAILY_LOG: 'word_explorer_daily_v1',
  MISTAKE_VAULT: 'word_explorer_mistakes_v1',
};

// 艾賓浩斯複習間隔 (小時)
const EBBINGHAUS_INTERVALS_HOURS = [4, 24, 72, 168, 360];

export class StorageEngine {
  constructor() {
    this.stats = this.load(STORAGE_KEYS.WORD_STATS, {});
    this.settings = this.load(STORAGE_KEYS.SETTINGS, {
      activeGrades: [1, 2, 3, 4, 5, 6], // 默認開放全部 1~6 年級
      dailyTargetMinutes: 60, // 每日目標 60 分鐘
      speechRate: 0.85,
      soundEffect: true,
      keyboardMode: 'auto', // auto / on-screen / physical
      playerName: '探險先鋒',
    });
    this.dailyLog = this.load(STORAGE_KEYS.DAILY_LOG, {
      date: new Date().toISOString().slice(0, 10),
      studiedSeconds: 0,
      wordsPracticed: 0,
      combosMax: 0,
    });
    this.checkDayRoll();
  }

  load(key, fallback) {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : fallback;
    } catch (e) {
      console.error('讀取本地資料失敗:', e);
      return fallback;
    }
  }

  save(key, data) {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.error('寫入本地資料失敗:', e);
    }
  }

  checkDayRoll() {
    const today = new Date().toISOString().slice(0, 10);
    if (this.dailyLog.date !== today) {
      this.dailyLog = {
        date: today,
        studiedSeconds: 0,
        wordsPracticed: 0,
        combosMax: 0,
      };
      this.save(STORAGE_KEYS.DAILY_LOG, this.dailyLog);
    }
  }

  /**
   * 獲取單詞的學習狀態
   * @param {string} wordId 
   */
  getWordRecord(wordId) {
    if (!this.stats[wordId]) {
      this.stats[wordId] = {
        status: 'unlearned', // 'unlearned' | 'learning' | 'familiar' | 'mastered'
        streak: 0,           // 連續答對次數
        correctCount: 0,
        errorCount: 0,
        stage: 0,            // 艾賓浩斯階梯 0~5
        nextReview: 0,       // 下次複習時間戳
        lastSeen: 0,
      };
    }
    return this.stats[wordId];
  }

  /**
   * 記錄單詞答題結果 (核心演算法)
   * @param {string} wordId 
   * @param {boolean} isCorrect 
   */
  recordAttempt(wordId, isCorrect) {
    const record = this.getWordRecord(wordId);
    const now = Date.now();
    record.lastSeen = now;

    if (isCorrect) {
      record.correctCount += 1;
      record.streak += 1;
      // 升級記憶階梯
      if (record.stage < EBBINGHAUS_INTERVALS_HOURS.length) {
        record.stage += 1;
      }
      const intervalHours = EBBINGHAUS_INTERVALS_HOURS[Math.min(record.stage - 1, EBBINGHAUS_INTERVALS_HOURS.length - 1)];
      record.nextReview = now + intervalHours * 3600 * 1000;

      if (record.streak >= 4) {
        record.status = 'mastered'; // 徹底精通
      } else if (record.streak >= 2) {
        record.status = 'familiar'; // 熟練
      } else {
        record.status = 'learning'; // 學習中
      }
    } else {
      record.errorCount += 1;
      record.streak = 0;
      record.stage = 0; // 重置記憶曲線
      record.nextReview = now + 4 * 3600 * 1000; // 4小時後優先再測
      record.status = 'learning';
    }

    this.save(STORAGE_KEYS.WORD_STATS, this.stats);
    this.dailyLog.wordsPracticed += 1;
    this.save(STORAGE_KEYS.DAILY_LOG, this.dailyLog);
    return record;
  }

  /**
   * 累加今日學習秒數
   * @param {number} seconds 
   */
  addStudySeconds(seconds = 1) {
    this.dailyLog.studiedSeconds += seconds;
    this.save(STORAGE_KEYS.DAILY_LOG, this.dailyLog);
  }

  /**
   * 獲取年級維度的掌握度統計
   * @param {Array} words - 全量單詞表
   */
  getGradeAnalytics(words) {
    const grades = [1, 2, 3, 4, 5, 6].map(g => ({
      grade: g,
      total: 0,
      mastered: 0,
      familiar: 0,
      learning: 0,
      unlearned: 0,
      weakList: [], // 錯題/薄弱詞
    }));

    words.forEach(w => {
      const gItem = grades.find(item => item.grade === w.grade);
      if (!gItem) return;
      gItem.total += 1;
      const rec = this.stats[w.id];
      if (!rec || rec.status === 'unlearned' || rec.lastSeen === 0) {
        gItem.unlearned += 1;
      } else if (rec.status === 'mastered') {
        gItem.mastered += 1;
      } else if (rec.status === 'familiar') {
        gItem.familiar += 1;
      } else {
        gItem.learning += 1;
      }

      // 如果有錯誤歷史或連續未通過
      if (rec && (rec.errorCount > 0 || (rec.streak === 0 && rec.lastSeen > 0))) {
        gItem.weakList.push({
          ...w,
          record: rec
        });
      }
    });

    return grades.map(g => {
      const activeCount = g.total - g.unlearned;
      const masteryRate = g.total > 0 ? Math.round((g.mastered * 1.0 + g.familiar * 0.6) / g.total * 100) : 0;
      return {
        ...g,
        masteryRate: Math.min(100, masteryRate),
      };
    });
  }

  /**
   * 獲取所有錯題/薄弱詞
   * @param {Array} words 
   */
  getAllMistakes(words) {
    const list = [];
    words.forEach(w => {
      const rec = this.stats[w.id];
      if (rec && rec.errorCount > 0) {
        list.push({
          ...w,
          record: rec
        });
      }
    });
    // 按錯誤次數降序排列
    return list.sort((a, b) => b.record.errorCount - a.record.errorCount);
  }

  /**
   * 獲取家長設置的有效年級
   */
  getActiveGrades() {
    return this.settings.activeGrades || [1, 2, 3, 4, 5, 6];
  }

  /**
   * 更新家長年級管控設置
   * @param {Array<number>} grades 
   */
  setActiveGrades(grades) {
    this.settings.activeGrades = grades;
    this.save(STORAGE_KEYS.SETTINGS, this.settings);
  }
}

export const storage = new StorageEngine();
