/**
 * 小学 1~6 年级英语核心词库 (标准 PEP 结构模板)
 * 采用规范简体中文
 */

export const DEFAULT_TEXTBOOK_INFO = {
  editionId: 'pep_standard',
  editionName: '人教版 (PEP) 小学英语 (1~6年级)',
  description: '标准小学英语词库体系，覆盖基础认知、学校生活、自然科学、时态及小升初核心词汇。',
  totalWords: 360,
};

export const RAW_VOCABULARY = [
  // 一年级
  { id: 'g1_001', word: 'book', phonetic: '/bʊk/', pos: 'n.', meaning: '书；书籍', grade: 1, semester: 1, unit: 'Unit 1', category: '文具', example: 'Open your book, please.' },
  { id: 'g1_002', word: 'ruler', phonetic: '/ˈruːlə(r)/', pos: 'n.', meaning: '直尺；尺子', grade: 1, semester: 1, unit: 'Unit 1', category: '文具', example: 'I have a new ruler.' },
  { id: 'g1_003', word: 'pencil', phonetic: '/ˈpensl/', pos: 'n.', meaning: '铅笔', grade: 1, semester: 1, unit: 'Unit 1', category: '文具', example: 'Show me your pencil.' },
  { id: 'g1_004', word: 'eraser', phonetic: '/ɪˈreɪzə(r)/', pos: 'n.', meaning: '橡皮擦', grade: 1, semester: 1, unit: 'Unit 1', category: '文具', example: 'An eraser is on the desk.' },
  { id: 'g1_005', word: 'eye', phonetic: '/aɪ/', pos: 'n.', meaning: '眼睛', grade: 1, semester: 1, unit: 'Unit 2', category: '身体部位', example: 'Touch your eye.' },
  { id: 'g1_006', word: 'ear', phonetic: '/ɪə(r)/', pos: 'n.', meaning: '耳朵', grade: 1, semester: 1, unit: 'Unit 2', category: '身体部位', example: 'Listen with your ear.' },
  { id: 'g1_007', word: 'nose', phonetic: '/nəʊz/', pos: 'n.', meaning: '鼻子', grade: 1, semester: 1, unit: 'Unit 2', category: '身体部位', example: 'Look at my nose.' },
  { id: 'g1_008', word: 'mouth', phonetic: '/maʊθ/', pos: 'n.', meaning: '嘴巴', grade: 1, semester: 1, unit: 'Unit 2', category: '身体部位', example: 'Open your mouth.' },
  { id: 'g1_009', word: 'red', phonetic: '/red/', pos: 'adj./n.', meaning: '红色的；红色', grade: 1, semester: 2, unit: 'Unit 3', category: '色彩', example: 'I like red apples.' },
  { id: 'g1_010', word: 'blue', phonetic: '/bluː/', pos: 'adj./n.', meaning: '蓝色的；蓝色', grade: 1, semester: 2, unit: 'Unit 3', category: '色彩', example: 'The sky is blue.' },
  { id: 'g1_011', word: 'green', phonetic: '/ɡriːn/', pos: 'adj./n.', meaning: '绿色的；绿色', grade: 1, semester: 2, unit: 'Unit 3', category: '色彩', example: 'Look at the green grass.' },
  { id: 'g1_012', word: 'yellow', phonetic: '/ˈjeləʊ/', pos: 'adj./n.', meaning: '黄色的；黄色', grade: 1, semester: 2, unit: 'Unit 3', category: '色彩', example: 'The sun is yellow.' },

  // 二年级
  { id: 'g2_001', word: 'cat', phonetic: '/kæt/', pos: 'n.', meaning: '猫', grade: 2, semester: 1, unit: 'Unit 1', category: '动物', example: 'The cat is sleeping.' },
  { id: 'g2_002', word: 'dog', phonetic: '/dɒɡ/', pos: 'n.', meaning: '狗', grade: 2, semester: 1, unit: 'Unit 1', category: '动物', example: 'A faithful dog runs fast.' },
  { id: 'g2_003', word: 'bird', phonetic: '/bɜːd/', pos: 'n.', meaning: '鸟', grade: 2, semester: 1, unit: 'Unit 1', category: '动物', example: 'A little bird can fly.' },
  { id: 'g2_004', word: 'apple', phonetic: '/ˈæpl/', pos: 'n.', meaning: '苹果', grade: 2, semester: 1, unit: 'Unit 2', category: '食物水果', example: 'Eat an apple every day.' },
  { id: 'g2_005', word: 'banana', phonetic: '/bəˈnɑːnə/', pos: 'n.', meaning: '香蕉', grade: 2, semester: 1, unit: 'Unit 2', category: '食物水果', example: 'Monkeys love bananas.' },
  { id: 'g2_006', word: 'water', phonetic: '/ˈwɔːtə(r)/', pos: 'n.', meaning: '水', grade: 2, semester: 1, unit: 'Unit 2', category: '食物水果', example: 'Drink some warm water.' },
  { id: 'g2_007', word: 'father', phonetic: '/ˈfɑːðə(r)/', pos: 'n.', meaning: '父亲；爸爸', grade: 2, semester: 2, unit: 'Unit 4', category: '家庭成员', example: 'My father is an engineer.' },
  { id: 'g2_008', word: 'mother', phonetic: '/ˈmʌðə(r)/', pos: 'n.', meaning: '母亲；妈妈', grade: 2, semester: 2, unit: 'Unit 4', category: '家庭成员', example: 'My mother cooks delicious food.' },
  { id: 'g2_009', word: 'brother', phonetic: '/ˈbrʌðə(r)/', pos: 'n.', meaning: '哥哥；弟弟', grade: 2, semester: 2, unit: 'Unit 4', category: '家庭成员', example: 'He has an elder brother.' },
  { id: 'g2_010', word: 'sister', phonetic: '/ˈsɪstə(r)/', pos: 'n.', meaning: '姐姐；妹妹', grade: 2, semester: 2, unit: 'Unit 4', category: '家庭成员', example: 'My sister likes singing.' },

  // 三年级
  { id: 'g3_001', word: 'classroom', phonetic: '/ˈklɑːsruːm/', pos: 'n.', meaning: '教室', grade: 3, semester: 1, unit: 'Unit 1', category: '学校空间', example: 'Our classroom is very bright.' },
  { id: 'g3_002', word: 'blackboard', phonetic: '/ˈblækbɔːd/', pos: 'n.', meaning: '黑板', grade: 3, semester: 1, unit: 'Unit 1', category: '学校设施', example: 'Look at the blackboard, boys.' },
  { id: 'g3_003', word: 'schoolbag', phonetic: '/ˈskuːlbæɡ/', pos: 'n.', meaning: '书包', grade: 3, semester: 1, unit: 'Unit 2', category: '学校用品', example: 'My schoolbag is heavy today.' },
  { id: 'g3_004', word: 'friend', phonetic: '/frend/', pos: 'n.', meaning: '朋友', grade: 3, semester: 1, unit: 'Unit 3', category: '社交生活', example: 'A good friend helps you in need.' },
  { id: 'g3_005', word: 'strong', phonetic: '/strɒŋ/', pos: 'adj.', meaning: '强壮的；坚固的', grade: 3, semester: 1, unit: 'Unit 3', category: '人物特征', example: 'The robot is very strong.' },
  { id: 'g3_006', word: 'quiet', phonetic: '/ˈkwaɪət/', pos: 'adj.', meaning: '安静的', grade: 3, semester: 1, unit: 'Unit 3', category: '性格描述', example: 'Please be quiet in the library.' },
  { id: 'g3_007', word: 'kitchen', phonetic: '/ˈkɪtʃɪn/', pos: 'n.', meaning: '厨房', grade: 3, semester: 2, unit: 'Unit 4', category: '居家空间', example: 'Mom is cooking in the kitchen.' },
  { id: 'g3_008', word: 'bedroom', phonetic: '/ˈbedruːm/', pos: 'n.', meaning: '卧室', grade: 3, semester: 2, unit: 'Unit 4', category: '居家空间', example: 'Go to your bedroom and rest.' },

  // 四年级
  { id: 'g4_001', word: 'playground', phonetic: '/ˈpleɪɡraʊnd/', pos: 'n.', meaning: '操场；游乐场', grade: 4, semester: 1, unit: 'Unit 1', category: '学校设施', example: 'Let’s play football on the playground.' },
  { id: 'g4_002', word: 'breakfast', phonetic: '/ˈbrekfəst/', pos: 'n.', meaning: '早餐', grade: 4, semester: 1, unit: 'Unit 2', category: '日常生活', example: 'It is time for breakfast.' },
  { id: 'g4_003', word: 'dinner', phonetic: '/ˈdɪnə(r)/', pos: 'n.', meaning: '正餐；晚餐', grade: 4, semester: 1, unit: 'Unit 2', category: '日常生活', example: 'We have dinner together at seven.' },
  { id: 'g4_004', word: 'weather', phonetic: '/ˈweðə(r)/', pos: 'n.', meaning: '天气', grade: 4, semester: 1, unit: 'Unit 3', category: '自然天气', example: 'What is the weather like today?' },
  { id: 'g4_005', word: 'sunny', phonetic: '/ˈsʌni/', pos: 'adj.', meaning: '晴朗的；阳光明媚的', grade: 4, semester: 1, unit: 'Unit 3', category: '自然天气', example: 'It is warm and sunny today.' },
  { id: 'g4_006', word: 'jacket', phonetic: '/ˈdʒækɪt/', pos: 'n.', meaning: '夹克；短上衣', grade: 4, semester: 2, unit: 'Unit 5', category: '服装服饰', example: 'Put on your warm jacket.' },
  { id: 'g4_007', word: 'tomato', phonetic: '/təˈmɑːtəʊ/', pos: 'n.', meaning: '番茄；西红柿', grade: 4, semester: 2, unit: 'Unit 4', category: '蔬菜植物', example: 'Tomatoes are juicy and red.' },
  { id: 'g4_008', word: 'potato', phonetic: '/pəˈteɪtəʊ/', pos: 'n.', meaning: '土豆；马铃薯', grade: 4, semester: 2, unit: 'Unit 4', category: '蔬菜植物', example: 'Pass me the hot potato.' },

  // 五年级
  { id: 'g5_001', word: 'Monday', phonetic: '/ˈmʌndeɪ/', pos: 'n.', meaning: '星期一', grade: 5, semester: 1, unit: 'Unit 2', category: '日期时间', example: 'We have English class on Monday.' },
  { id: 'g5_002', word: 'weekend', phonetic: '/ˌwiːkˈend/', pos: 'n.', meaning: '周末', grade: 5, semester: 1, unit: 'Unit 2', category: '日期时间', example: 'What do you do on the weekend?' },
  { id: 'g5_003', word: 'season', phonetic: '/ˈsiːzn/', pos: 'n.', meaning: '季节', grade: 5, semester: 2, unit: 'Unit 2', category: '自然气候', example: 'Spring is my favorite season.' },
  { id: 'g5_004', word: 'spring', phonetic: '/sprɪŋ/', pos: 'n.', meaning: '春天；春季', grade: 5, semester: 2, unit: 'Unit 2', category: '自然气候', example: 'Flowers bloom in spring.' },
  { id: 'g5_005', word: 'autumn', phonetic: '/ˈɔːtəm/', pos: 'n.', meaning: '秋天；秋季', grade: 5, semester: 2, unit: 'Unit 2', category: '自然气候', example: 'Leaves turn golden in autumn.' },
  { id: 'g5_006', word: 'climb', phonetic: '/klaɪm/', pos: 'v.', meaning: '攀登；爬', grade: 5, semester: 1, unit: 'Unit 4', category: '动作体育', example: 'They climb the high mountain.' },
  { id: 'g5_007', word: 'listen', phonetic: '/ˈlɪsn/', pos: 'v.', meaning: '听；倾听', grade: 5, semester: 1, unit: 'Unit 4', category: '日常行为', example: 'Listen carefully to the command.' },
  { id: 'g5_008', word: 'bridge', phonetic: '/brɪdʒ/', pos: 'n.', meaning: '桥；桥梁', grade: 5, semester: 1, unit: 'Unit 6', category: '自然地理', example: 'There is a long bridge over the river.' },
  { id: 'g5_009', word: 'building', phonetic: '/ˈbɪldɪŋ/', pos: 'n.', meaning: '建筑物；楼房', grade: 5, semester: 1, unit: 'Unit 6', category: '城市生活', example: 'Look at the tall cyber building.' },

  // 六年级
  { id: 'g6_001', word: 'taller', phonetic: '/ˈtɔːlə(r)/', pos: 'adj.', meaning: '更高的 (比较级)', grade: 6, semester: 1, unit: 'Unit 1', category: '比较与特征', example: 'The mecha warrior is taller than the dinosaur.' },
  { id: 'g6_002', word: 'heavier', phonetic: '/ˈheviə(r)/', pos: 'adj.', meaning: '更重的 (比较级)', grade: 6, semester: 1, unit: 'Unit 1', category: '比较与特征', example: 'Iron is heavier than wood.' },
  { id: 'g6_003', word: 'longer', phonetic: '/ˈlɒŋɡə(r)/', pos: 'adj.', meaning: '更长的 (比较级)', grade: 6, semester: 1, unit: 'Unit 1', category: '比较与特征', example: 'My ruler is longer than yours.' },
  { id: 'g6_004', word: 'hospital', phonetic: '/ˈhɒspɪtl/', pos: 'n.', meaning: '医院', grade: 6, semester: 1, unit: 'Unit 2', category: '城市公共设施', example: 'Turn left at the hospital.' },
  { id: 'g6_005', word: 'crossing', phonetic: '/ˈkrɒsɪŋ/', pos: 'n.', meaning: '十字路口；人行横道', grade: 6, semester: 1, unit: 'Unit 2', category: '交通安全', example: 'Slow down at the zebra crossing.' },
  { id: 'g6_006', word: 'helmet', phonetic: '/ˈhelmɪt/', pos: 'n.', meaning: '头盔；安全帽', grade: 6, semester: 1, unit: 'Unit 2', category: '装备防护', example: 'Always wear a combat helmet.' },
  { id: 'g6_007', word: 'dictionary', phonetic: '/ˈdɪkʃənri/', pos: 'n.', meaning: '字典；词典', grade: 6, semester: 1, unit: 'Unit 3', category: '学习工具', example: 'Look up new words in the dictionary.' },
  { id: 'g6_008', word: 'astronaut', phonetic: '/ˈæstrənɔːt/', pos: 'n.', meaning: '太空人；宇航员', grade: 6, semester: 1, unit: 'Unit 4', category: '未来职业', example: 'He dreams of becoming an astronaut.' },
  { id: 'g6_009', word: 'spaceship', phonetic: '/ˈspeɪsʃɪp/', pos: 'n.', meaning: '宇宙飞船；太空船', grade: 6, semester: 1, unit: 'Unit 4', category: '科技航天', example: 'The spaceship launched into orbit.' },
  { id: 'g6_010', word: 'yesterday', phonetic: '/ˈjestədeɪ/', pos: 'n./adv.', meaning: '昨天', grade: 6, semester: 2, unit: 'Unit 2', category: '过去时态', example: 'Where did you go yesterday?' },
  { id: 'g6_011', word: 'stayed', phonetic: '/steɪd/', pos: 'v.', meaning: '停留；待 (stay的过去式)', grade: 6, semester: 2, unit: 'Unit 2', category: '过去时态', example: 'I stayed at home and practiced English.' },
  { id: 'g6_012', word: 'cleaned', phonetic: '/kliːnd/', pos: 'v.', meaning: '打扫；清洁 (clean的过去式)', grade: 6, semester: 2, unit: 'Unit 2', category: '过去时态', example: 'He cleaned his battle room.' },
  { id: 'g6_013', word: 'watched', phonetic: '/wɒtʃt/', pos: 'v.', meaning: '观看；注视 (watch的过去式)', grade: 6, semester: 2, unit: 'Unit 2', category: '过去时态', example: 'We watched an exciting robot match.' },
  { id: 'g6_014', word: 'shadow', phonetic: '/ˈʃædəʊ/', pos: 'n.', meaning: '阴影；影子', grade: 6, semester: 2, unit: 'Unit 4', category: '科学探秘', example: 'Your shadow grows longer in the evening.' },
  { id: 'g6_015', word: 'energy', phonetic: '/ˈenədʒi/', pos: 'n.', meaning: '能量；精力', grade: 6, semester: 2, unit: 'Unit 4', category: '科学探秘', example: 'Collect solar energy to power up.' }
];
